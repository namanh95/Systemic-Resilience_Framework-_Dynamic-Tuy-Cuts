# Fresh closed-loop evaluation of the sampling ablation

3 November 2026. Declared before evaluating these models on new paths.

Freeze all six existing targeted_sampling models (baseline/targeted, seeds
63,64,65) using their pretest_freeze.json hashes. No retraining or model selection.
Evaluate all six plus the same frozen numerical reference from high_x, target,
saddle and mixed. Use 256 fresh paths per start, seeds 20265000..20265003,
shared Brownian increments across all seven policies within each start.

Keep horizon 50, sigma=.05, decision interval .1, simulation step .025,
61 control candidates, original running and terminal cost, and Bellman lookahead.
Use the original neural zero-control fallback outside [0,1.2]^2. Reference
feedback retains its original domain/exit handling. Record branch extrapolation
as a known limitation, not a certified extension of the learned domain.

For every model/start pair, report cost, integral z^2, final normalized target
distance, fraction within .05 of target, fallback paths/decisions, runtime and
raw pathwise outcomes. Report paired differences versus reference and paired
targeted-minus-matched-baseline differences. Approximate intervals use mean
+/-1.96*sample SD/sqrt(256), with no multiplicity correction; no superiority
claim will be based on selective significant pairs.

Prespecified reference-cost screen: upper paired 95% endpoint <=
.01+.05*reference mean cost. All 12 targeted start/seed cases must pass for
stage reference-screen success. Also report the same screen for all baselines.
This permits small losses; it is not equivalence or proof of optimality.
There is no prespecified claim of universal improvement over matched baselines.
Report wins, losses and intervals spanning zero, without averaging away failures.

Check the shared rollout implementation against the existing reference simulator
on a short exact matched-path configuration before production. All numerical
state and action guards remain enabled. Preserve models, previous outputs and
the published repository archive. New evidence is delivered separately until
the author updates the repository. Update manuscript claims only to the extent
supported by these results. No epidemic or biological efficacy claim follows.
