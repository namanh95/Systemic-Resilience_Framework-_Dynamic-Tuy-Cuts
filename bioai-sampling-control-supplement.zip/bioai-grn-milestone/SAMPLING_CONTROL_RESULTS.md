# Fresh closed-loop evaluation of targeted sampling

3 November 2026

Experiment complete. All twelve targeted-model reference-cost screens: **PASS**.

Failed targeted cases: none.

Against matched baselines, approximate paired cost intervals were entirely below zero in 0 cases, entirely above zero in 9 cases, and included zero in 3 cases. These are unadjusted descriptive comparisons, not twelve independent superiority tests.

Targeted-minus-baseline mean costs were positive in 12 of twelve cases. The targeted value-fit gain therefore did not demonstrate a control-cost benefit in this test suite.

## Protocol and integrity

All six sampling-ablation checkpoints were hash-verified and frozen; no retraining, best-seed selection or policy changes occurred. Each of four starts uses 256 fresh paths, with seeds 20265000 through 20265003. All seven policies share Brownian increments within a start. Shared paths do not make the policies equivalent.

The horizon is 50, noise .05, decision interval .1, simulation step .025 and action grid 61 controls in [0,10]. The existing Bellman lookahead, running/terminal objective and zero-control fallback are unchanged. Neural fallback starts outside [0,1.2]^2; reference fallback uses its original domain 1.5. Lookahead can extrapolate outside the learned box. There is no continuous Hamiltonian or learned-gradient certificate.

A short matched-path reference check had maximum cost discrepancy 0 against the earlier simulator. State finiteness/nonnegativity and action bounds were checked throughout. Statistics below were independently recomputed from raw path arrays when generating this report.

## Costs against the reference

The screen requires the upper paired 95% endpoint of model-minus-reference cost to be <= .01+.05*reference mean cost. Passing allows small losses and does not establish equal cost or optimality.

| Start | Model | Mean cost | Difference vs reference | Approximate paired 95% interval | Screen |
|---|---|---:|---:|---|---|
| high_x | reference | 2.5097857 | - | - | - |
| high_x | baseline_63 | 2.5198482 | 0.0100625 | [0.0092639, 0.0108611] | PASS |
| high_x | targeted_63 | 2.5202086 | 0.0104229 | [0.0094326, 0.0114132] | PASS |
| high_x | baseline_64 | 2.5145813 | 0.0047956 | [0.0042198, 0.0053714] | PASS |
| high_x | targeted_64 | 2.5233380 | 0.0135523 | [0.0129009, 0.0142037] | PASS |
| high_x | baseline_65 | 2.5169454 | 0.0071597 | [0.0065793, 0.0077402] | PASS |
| high_x | targeted_65 | 2.5171034 | 0.0073177 | [0.0067054, 0.0079300] | PASS |
| target | reference | 0.0550359 | - | - | - |
| target | baseline_63 | 0.0606775 | 0.0056415 | [0.0048484, 0.0064347] | PASS |
| target | targeted_63 | 0.0622481 | 0.0072122 | [0.0062059, 0.0082185] | PASS |
| target | baseline_64 | 0.0576005 | 0.0025645 | [0.0020052, 0.0031238] | PASS |
| target | targeted_64 | 0.0586533 | 0.0036174 | [0.0030336, 0.0042011] | PASS |
| target | baseline_65 | 0.0588672 | 0.0038312 | [0.0032363, 0.0044262] | PASS |
| target | targeted_65 | 0.0590011 | 0.0039651 | [0.0033752, 0.0045550] | PASS |
| saddle | reference | 0.1083673 | - | - | - |
| saddle | baseline_63 | 0.1136360 | 0.0052687 | [0.0044968, 0.0060406] | PASS |
| saddle | targeted_63 | 0.1160609 | 0.0076936 | [0.0067250, 0.0086622] | PASS |
| saddle | baseline_64 | 0.1105560 | 0.0021887 | [0.0016459, 0.0027315] | PASS |
| saddle | targeted_64 | 0.1136115 | 0.0052442 | [0.0045871, 0.0059013] | PASS |
| saddle | baseline_65 | 0.1115324 | 0.0031651 | [0.0026184, 0.0037117] | PASS |
| saddle | targeted_65 | 0.1131980 | 0.0048307 | [0.0042071, 0.0054543] | PASS |
| mixed | reference | 0.6470650 | - | - | - |
| mixed | baseline_63 | 0.6550063 | 0.0079413 | [0.0071255, 0.0087572] | PASS |
| mixed | targeted_63 | 0.6574594 | 0.0103944 | [0.0093578, 0.0114310] | PASS |
| mixed | baseline_64 | 0.6503591 | 0.0032942 | [0.0027432, 0.0038452] | PASS |
| mixed | targeted_64 | 0.6530502 | 0.0059852 | [0.0053207, 0.0066497] | PASS |
| mixed | baseline_65 | 0.6515854 | 0.0045205 | [0.0039394, 0.0051015] | PASS |
| mixed | targeted_65 | 0.6539192 | 0.0068542 | [0.0062742, 0.0074342] | PASS |

## Matched targeted-minus-baseline comparisons

| Start | Seed | Mean cost difference | Approximate paired 95% interval | Dose difference | Terminal-distance difference |
|---|---|---:|---|---:|---:|
| high_x | 63 | 0.0003604 | [-0.0000269, 0.0007477] | 6.3398438 | -0.0006314 |
| high_x | 64 | 0.0087567 | [0.0082780, 0.0092354] | 2.3865994 | 0.0002880 |
| high_x | 65 | 0.0001580 | [-0.0005554, 0.0008713] | 4.3586263 | 0.0026143 |
| target | 63 | 0.0015706 | [0.0011899, 0.0019514] | -0.0141168 | -0.0007224 |
| target | 64 | 0.0010528 | [0.0006134, 0.0014922] | -0.0121745 | 0.0001494 |
| target | 65 | 0.0001339 | [-0.0006525, 0.0009203] | 0.0564345 | 0.0020457 |
| saddle | 63 | 0.0024249 | [0.0020789, 0.0027709] | -0.0690104 | -0.0004603 |
| saddle | 64 | 0.0030555 | [0.0025222, 0.0035887] | -0.1493164 | 0.0004082 |
| saddle | 65 | 0.0016656 | [0.0009490, 0.0023823] | 0.0265842 | 0.0025435 |
| mixed | 63 | 0.0024531 | [0.0021220, 0.0027843] | 2.1548286 | -0.0004620 |
| mixed | 64 | 0.0026911 | [0.0022064, 0.0031757] | -1.1381402 | 0.0001313 |
| mixed | 65 | 0.0023338 | [0.0016518, 0.0030158] | 1.4208550 | 0.0019582 |

## Intervention, terminal outcomes and runtime

| Start | Model | Mean integral z² | Mean final distance | Fraction within .05 | Fallback paths | Fallback decisions | Seconds |
|---|---|---:|---:|---:|---:|---:|---:|
| high_x | reference | 86.893793 | 0.019849 | 92.58% | 0/256 | 0 | 7.05 |
| high_x | baseline_63 | 83.119444 | 0.019440 | 92.58% | 0/256 | 0 | 34.10 |
| high_x | targeted_63 | 89.459288 | 0.018808 | 92.97% | 0/256 | 0 | 34.68 |
| high_x | baseline_64 | 90.291895 | 0.018864 | 92.97% | 0/256 | 0 | 34.80 |
| high_x | targeted_64 | 92.678494 | 0.019152 | 92.97% | 0/256 | 0 | 35.20 |
| high_x | baseline_65 | 84.592220 | 0.019693 | 92.19% | 0/256 | 0 | 35.35 |
| high_x | targeted_65 | 88.950846 | 0.022307 | 90.23% | 0/256 | 0 | 38.07 |
| target | reference | 0.136892 | 0.019938 | 90.62% | 0/256 | 0 | 6.80 |
| target | baseline_63 | 0.088715 | 0.020078 | 92.19% | 0/256 | 0 | 38.24 |
| target | targeted_63 | 0.074599 | 0.019356 | 92.19% | 0/256 | 0 | 38.05 |
| target | baseline_64 | 0.118457 | 0.019684 | 92.58% | 0/256 | 0 | 36.07 |
| target | targeted_64 | 0.106283 | 0.019834 | 92.58% | 0/256 | 0 | 38.16 |
| target | baseline_65 | 0.100011 | 0.020336 | 91.41% | 0/256 | 0 | 37.98 |
| target | targeted_65 | 0.156445 | 0.022381 | 88.67% | 0/256 | 0 | 37.63 |
| saddle | reference | 1.896007 | 0.019943 | 91.80% | 0/256 | 0 | 6.74 |
| saddle | baseline_63 | 1.928136 | 0.019271 | 92.58% | 0/256 | 0 | 34.09 |
| saddle | targeted_63 | 1.859125 | 0.018810 | 92.58% | 0/256 | 0 | 34.20 |
| saddle | baseline_64 | 1.914529 | 0.018499 | 92.58% | 0/256 | 0 | 34.32 |
| saddle | targeted_64 | 1.765213 | 0.018907 | 92.58% | 0/256 | 0 | 37.04 |
| saddle | baseline_65 | 2.039214 | 0.019599 | 92.19% | 0/256 | 0 | 33.77 |
| saddle | targeted_65 | 2.065799 | 0.022143 | 88.28% | 0/256 | 0 | 37.64 |
| mixed | reference | 26.179091 | 0.018631 | 93.75% | 0/256 | 0 | 6.66 |
| mixed | baseline_63 | 25.741895 | 0.018435 | 93.75% | 0/256 | 0 | 36.23 |
| mixed | targeted_63 | 27.896723 | 0.017973 | 93.75% | 0/256 | 0 | 33.36 |
| mixed | baseline_64 | 26.688487 | 0.018127 | 94.14% | 0/256 | 0 | 34.80 |
| mixed | targeted_64 | 25.550347 | 0.018258 | 93.75% | 0/256 | 0 | 36.92 |
| mixed | baseline_65 | 26.076248 | 0.018829 | 93.75% | 0/256 | 0 | 38.47 |
| mixed | targeted_65 | 27.497103 | 0.020787 | 92.19% | 0/256 | 0 | 37.68 |

Dose is integral z², not a physical clinical dose. Terminal distance uses normalized coordinates; the .05 criterion is a computational threshold. Runtime is full rollout wall time excluding loading, with BLAS/OMP threads fixed to one. Execution order and host load can affect timings; this is not a speed benchmark.

Intervals quantify path-sampling variability conditional on models and initial states. They omit discretization, model and training-data uncertainty, and are not adjusted for multiplicity. All twelve targeted comparisons are retained; three seeds on one training dataset do not establish broad robustness.

The previous near-zero-time accuracy weakness and long-time value errors remain. These rollouts test only the four starts, nominal noise and specified objective. No biological efficacy, continuous optimality, certified neural control or epidemic-control result follows.

## Reproduction and repository status

With the earlier source/model package and frozen teacher in place:

    python sampling_control.py
    python write_sampling_control_report.py

Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1. The supplement contains every raw path outcome and frozen hashes. These new files are additional to the previously verified public GitHub archive; they have not been uploaded by this process. Keep the public archive version and new evidence distinct.
