"""Retain all closed-loop outcomes and verify statistics from raw paths."""
import json,zipfile
import numpy as np
from sampling_control import ROOT,OUT,SEEDS,sha
from stochastic_reference import summary

def main():
    results=json.loads((OUT/'results.json').read_text());frozen=json.loads((OUT/'frozen_inputs.json').read_text())
    assert set(results)=={'high_x','target','saddle','mixed'}
    assert frozen['source_sha256']==sha(ROOT/'sampling_control.py')
    assert frozen['protocol_sha256']==sha(ROOT/'SAMPLING_CONTROL_PROTOCOL.md')
    names={'reference',*[f'{a}_{s}' for s in SEEDS for a in ('baseline','targeted')]}
    classifications={'lower':0,'higher':0,'spans_zero':0};failures=[]
    for label,r in results.items():
        assert set(r['models'])==names
        for name,m in r['models'].items():
            a=np.load(OUT/f'{label}_{name}.npz')
            assert len(a['cost'])==256
            assert abs(a['cost'].mean()-m['cost']['mean'])<1e-12
            assert abs(a['dose'].mean()-m['integral_z_squared']['mean'])<1e-12
            assert abs(a['distance'].mean()-m['final_target_distance']['mean'])<1e-12
            if name=='reference':continue
            ref=np.load(OUT/f'{label}_reference.npz')
            d=summary(a['cost']-ref['cost'])
            assert np.allclose(d['approx_95ci'],m['minus_reference']['approx_95ci'],rtol=0,atol=1e-12)
            if name.startswith('targeted'):
                b=np.load(OUT/f'{label}_{name.replace("targeted","baseline")}.npz')
                d=summary(a['cost']-b['cost']);lo,hi=d['approx_95ci']
                assert np.allclose(d['approx_95ci'],m['minus_baseline']['cost']['approx_95ci'],rtol=0,atol=1e-12)
                classifications['lower' if hi<0 else ('higher' if lo>0 else 'spans_zero')]+=1
                if not m['reference_screen_passed']:failures.append(f'{label}/{name}')
    positive_means=sum(r['models'][f'targeted_{s}']['minus_baseline']['cost']['mean']>0 for r in results.values() for s in SEEDS)
    lines=['# Fresh closed-loop evaluation of targeted sampling','','3 November 2026','',
        f"Experiment complete. All twelve targeted-model reference-cost screens: **{'PASS' if not failures else 'FAIL'}**.",'',
        'Failed targeted cases: '+(', '.join(failures) or 'none')+'.','',
        f"Against matched baselines, approximate paired cost intervals were entirely below zero in {classifications['lower']} cases, "
        f"entirely above zero in {classifications['higher']} cases, and included zero in {classifications['spans_zero']} cases. "
        'These are unadjusted descriptive comparisons, not twelve independent superiority tests.','',
        f'Targeted-minus-baseline mean costs were positive in {positive_means} of twelve cases. '
        'The targeted value-fit gain therefore did not demonstrate a control-cost benefit in this test suite.','',
        '## Protocol and integrity','',
        'All six sampling-ablation checkpoints were hash-verified and frozen; no retraining, '
        'best-seed selection or policy changes occurred. Each of four starts uses 256 fresh '
        'paths, with seeds 20265000 through 20265003. All seven policies share Brownian '
        'increments within a start. Shared paths do not make the policies equivalent.','',
        'The horizon is 50, noise .05, decision interval .1, simulation step .025 and action '
        'grid 61 controls in [0,10]. The existing Bellman lookahead, running/terminal objective '
        'and zero-control fallback are unchanged. Neural fallback starts outside [0,1.2]^2; '
        'reference fallback uses its original domain 1.5. Lookahead can extrapolate outside '
        'the learned box. There is no continuous Hamiltonian or learned-gradient certificate.','',
        f"A short matched-path reference check had maximum cost discrepancy {frozen['reference_simulation_equivalence_max_error']:.3g} "
        'against the earlier simulator. State finiteness/nonnegativity and action bounds '
        'were checked throughout. Statistics below were independently recomputed from raw '
        'path arrays when generating this report.','',
        '## Costs against the reference','',
        'The screen requires the upper paired 95% endpoint of model-minus-reference cost '
        'to be <= .01+.05*reference mean cost. Passing allows small losses and does not '
        'establish equal cost or optimality.','',
        '| Start | Model | Mean cost | Difference vs reference | Approximate paired 95% interval | Screen |',
        '|---|---|---:|---:|---|---|']
    for label,r in results.items():
        for name,m in r['models'].items():
            if name=='reference':lines.append(f"| {label} | reference | {m['cost']['mean']:.7f} | - | - | - |");continue
            d=m['minus_reference'];lo,hi=d['approx_95ci']
            lines.append(f"| {label} | {name} | {m['cost']['mean']:.7f} | {d['mean']:.7f} | [{lo:.7f}, {hi:.7f}] | {'PASS' if m['reference_screen_passed'] else 'FAIL'} |")
    lines+=['','## Matched targeted-minus-baseline comparisons','',
        '| Start | Seed | Mean cost difference | Approximate paired 95% interval | Dose difference | Terminal-distance difference |',
        '|---|---|---:|---|---:|---:|']
    latexrows=[]
    for label,r in results.items():
        for seed in SEEDS:
            m=r['models'][f'targeted_{seed}'];b=r['models'][f'baseline_{seed}'];d=m['minus_baseline']['cost'];lo,hi=d['approx_95ci']
            lines.append(f"| {label} | {seed} | {d['mean']:.7f} | [{lo:.7f}, {hi:.7f}] | {m['minus_baseline']['dose']['mean']:.7f} | {m['minus_baseline']['distance']['mean']:.7f} |")
            latexrows.append(f"{label.replace('_',r'\_')} & {seed} & {b['cost']['mean']:.6f} & {m['cost']['mean']:.6f} & {d['mean']:.6f} & [{lo:.6f}, {hi:.6f}]"+r'\\')
    lines+=['','## Intervention, terminal outcomes and runtime','',
        '| Start | Model | Mean integral z² | Mean final distance | Fraction within .05 | Fallback paths | Fallback decisions | Seconds |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for label,r in results.items():
        for name,m in r['models'].items():
            lines.append(f"| {label} | {name} | {m['integral_z_squared']['mean']:.6f} | {m['final_target_distance']['mean']:.6f} | {m['fraction_within_005']:.2%} | {m['fallback_paths']}/256 | {m['fallback_decisions']} | {m['seconds']:.2f} |")
    lines+=['','Dose is integral z², not a physical clinical dose. Terminal distance uses '
        'normalized coordinates; the .05 criterion is a computational threshold. Runtime '
        'is full rollout wall time excluding loading, with BLAS/OMP threads fixed to one. '
        'Execution order and host load can affect timings; this is not a speed benchmark.','',
        'Intervals quantify path-sampling variability conditional on models and initial '
        'states. They omit discretization, model and training-data uncertainty, and are '
        'not adjusted for multiplicity. All twelve targeted comparisons are retained; '
        'three seeds on one training dataset do not establish broad robustness.','',
        'The previous near-zero-time accuracy weakness and long-time value errors remain. '
        'These rollouts test only the four starts, nominal noise and specified objective. '
        'No biological efficacy, continuous optimality, certified neural control or '
        'epidemic-control result follows.','',
        '## Reproduction and repository status','',
        'With the earlier source/model package and frozen teacher in place:', '',
        '    python sampling_control.py',
        '    python write_sampling_control_report.py','',
        'Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1. The supplement contains '
        'every raw path outcome and frozen hashes. These new files are additional to '
        'the previously verified public GitHub archive; they have not been uploaded '
        'by this process. Keep the public archive version and new evidence distinct.','']
    (ROOT/'SAMPLING_CONTROL_RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    section=r'''\subsection{Fresh closed-loop evaluation of the sampling ablation}
All six models from the sampling ablation were frozen and evaluated against the numerical reference from high-$X$, target, saddle and mixed initial states. Each start uses 256 fresh shared Brownian paths (seeds 20265000--20265003), with unchanged horizon, noise, objective, decision interval, 61-control lookahead and simulation step. No retraining or best-seed selection was performed. All models retain their existing fallback rules.
'''
    section+=f"All twelve targeted-model reference-cost screens {'passed' if not failures else 'did not pass'}. "
    section+=f"Relative to matched baselines, paired cost intervals lay below zero in {classifications['lower']} cases, above zero in {classifications['higher']} cases and included zero in {classifications['spans_zero']} cases. "
    section+=f"Targeted mean cost was higher in {positive_means} of twelve cases; the value-fit gain did not demonstrate a control-cost benefit in this suite. "
    section+=r'''These unadjusted comparisons are conditional on the four starts and sampled paths; they do not establish uniform superiority, continuous optimality or biological effectiveness. Table~\ref{tab:newcontrol} retains every paired seed/start outcome. Full dose, terminal-distance, fallback and runtime results accompany the supplement.
\begin{table}[!htbp]\centering\small
\caption{Fresh control evaluation: paired targeted-minus-baseline cost differences for every sampling-ablation model. Intervals reflect path sampling only.}\label{tab:newcontrol}
\begin{tabular}{llrrrr}\toprule
Start & Seed & Baseline & Targeted & Difference & 95\% interval\\\midrule
'''+ '\n'.join(latexrows)+r'''
\bottomrule\end{tabular}\end{table}
'''
    (OUT/'manuscript_section.tex').write_text(section)
    manifest=dict(experiment_complete=True,targeted_reference_screens_all_passed=not failures,
        failed_cases=failures,paired_interval_classifications=classifications,
        raw_statistics_verified=True,files={str(p.relative_to(ROOT)):sha(p) for p in sorted(OUT.glob('*')) if p.is_file()},
        source_sha256={n:sha(ROOT/n) for n in ['sampling_control.py','write_sampling_control_report.py','SAMPLING_CONTROL_PROTOCOL.md']})
    (ROOT/'SAMPLING_CONTROL_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    package=ROOT.parent/'bioai-sampling-control-supplement.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for name in ['sampling_control.py','write_sampling_control_report.py','SAMPLING_CONTROL_PROTOCOL.md','SAMPLING_CONTROL_RESULTS.md','SAMPLING_CONTROL_MANIFEST.json']:
            z.write(ROOT/name,'bioai-grn-milestone/'+name)
        for p in sorted(OUT.glob('*')):
            if p.is_file():z.write(p,'bioai-grn-milestone/sampling_control/'+p.name)
        z.writestr('README.txt','Additional evidence for the existing RICO reproducibility package. Extract beside the existing bioai-grn-milestone files. Requires the six frozen models, earlier source dependencies and reference-data archive. Start with SAMPLING_CONTROL_RESULTS.md. This new evidence has not been published to GitHub by this process.\n')
    with zipfile.ZipFile(package) as z:assert z.testzip() is None
    print(json.dumps({k:v for k,v in manifest.items() if k not in ['files','source_sha256']},indent=2))

if __name__=='__main__':main()
