"""Fresh paired closed-loop test of every frozen sampling-ablation model."""
import json,time
import numpy as np
from neural_pilot import Network,teacher,choose_neural
from stochastic_reference import ROOT,STATES,terminal,summary,simulate,choose
from refined_control import flow
from targeted_sampling import SEEDS,modelpath,sha

OUT=ROOT/'sampling_control'
def save(name,data):(OUT/name).write_text(json.dumps(data,indent=2))

def rollout(model,grid,u,v,p,initial,seed,paths=256):
    state=np.tile(initial,(paths,1));cost=np.zeros(paths);dose=np.zeros(paths)
    rng=np.random.default_rng(seed);fallback=np.zeros(paths,bool);decisions=0
    start=time.perf_counter()
    for k in range(len(v)-1):
        if model is None:
            z=choose(grid,u,v[k+1],state,p)
            outside=np.any(state>p['domain'],axis=1)
        else:z,outside=choose_neural(model,u,state,50-k*p['dt'],p)
        assert np.all(np.isfinite(z)) and np.all((z>=0)&(z<=10))
        fallback|=outside;decisions+=int(outside.sum());dose+=p['dt']*z*z
        for _ in range(4):
            x,y,ca=flow(state[:,0],state[:,1],z,.0125)
            normal=rng.standard_normal((1,paths,2)).sum(axis=0)
            fac=np.exp(-.5*p['sigma']**2*.025+p['sigma']*np.sqrt(.025)*normal)
            x,y,cb=flow(x*fac[:,0],y*fac[:,1],z,.0125)
            state=np.column_stack([x,y]);cost+=ca+cb
            assert np.all(np.isfinite(state)) and np.all(state>=0)
    cost+=terminal(*state.T);distance=np.linalg.norm(state-STATES['target'],axis=1)
    arrays=dict(cost=cost,dose=dose,distance=distance,final_state=state,fallback=fallback)
    result=dict(cost=summary(cost),integral_z_squared=summary(dose),final_target_distance=summary(distance),
        fraction_within_005=float(np.mean(distance<=.05)),fallback_paths=int(fallback.sum()),
        fallback_decisions=decisions,seconds=time.perf_counter()-start,paths=paths)
    return result,arrays

def main():
    OUT.mkdir(exist_ok=True);grid,u,v,p=teacher()
    freeze=json.loads((ROOT/'targeted_sampling/pretest_freeze.json').read_text())
    models={'reference':None}
    for seed in SEEDS:
        for arm in ('baseline','targeted'):
            name=f'{arm}_{seed}';path=modelpath(arm,seed)
            assert sha(path)==freeze['models'][name]
            models[name]=Network.load(path)
    # Same numerical transitions and RNG layout as the earlier reference code.
    small=v[-3:];ref,rc=simulate(grid,u,small,p,STATES['mixed'],paths=7,seed=20264999,h=.025)
    ours,raw=rollout(None,grid,u,small,p,STATES['mixed'],20264999,paths=7)
    assert np.max(np.abs(rc-raw['cost']))<1e-12
    assert abs(ref['integral_z_squared']['mean']-ours['integral_z_squared']['mean'])<1e-12
    save('frozen_inputs.json',dict(models=freeze['models'],reference_sha256=sha(ROOT/'pretraining_control_policy.npz'),
        protocol_sha256=sha(ROOT/'SAMPLING_CONTROL_PROTOCOL.md'),source_sha256=sha(ROOT/'sampling_control.py'),
        reference_simulation_equivalence_max_error=float(np.max(np.abs(rc-raw['cost'])))))
    results={}
    for i,label in enumerate(('high_x','target','saddle','mixed')):
        seed=20265000+i;runs={};raws={}
        for name,model in models.items():
            r,a=rollout(model,grid,u,v,p,STATES[label],seed)
            raws[name]=a
            if name!='reference':
                r['minus_reference']=summary(a['cost']-raws['reference']['cost'])
                r['tolerance']=.01+.05*runs['reference']['cost']['mean']
                r['reference_screen_passed']=r['minus_reference']['approx_95ci'][1]<=r['tolerance']
            if name.startswith('targeted'):
                b=raws[name.replace('targeted','baseline')]
                r['minus_baseline']={key:summary(a[key]-b[key]) for key in ('cost','dose','distance')}
            runs[name]=r
            np.savez_compressed(OUT/f'{label}_{name}.npz',**a)
            results[label]=dict(path_seed=seed,models=runs)
            save('results.json',results)
            print(label,name,json.dumps(dict(cost=r['cost']['mean'],seconds=r['seconds'],
                passed=r.get('reference_screen_passed'),paired=r.get('minus_baseline',{}).get('cost'))),flush=True)
    for name,h in freeze['models'].items():
        arm,seed=name.split('_');assert sha(modelpath(arm,int(seed)))==h
    print('COMPLETE: all 28 policy/start evaluations retained.',flush=True)

if __name__=='__main__':main()
