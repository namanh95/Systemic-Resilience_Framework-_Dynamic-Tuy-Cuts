# BioAI control-selection baseline — milestone 1

Date: 2 November 2026

## Outcome

Implemented a one-dimensional certified interval branch-and-bound prototype.
All eight verification landscapes passed with objective tolerance 0.0001.
Original research files were left unchanged. This package is a new standalone
baseline, not a modification of the earlier heuristic.

## Source audit

Inspected the supplied nine-page manuscript, the submission-package file list,
work/reviewed_experiment.py and work/source-audit/model.py in the earlier my-x20
research folder. The first numerical script uses grid-assisted candidate search
and geometric cuts without continuous-domain lower-bound certificates. The
separate routing model also selects grid candidates before constructing cuts.
Neither provides the certified continuous optimizer needed here. This was a
targeted audit, not an exhaustive review of every historical file.

Reusable foundation: manuscript Section 3.3, strict lower-bound exclusion;
Section 2.2, SIS analytical objective; Section 4, distinction between selection
and stability. The earlier neural/GRN proposal remains a future extension.

## Method and guarantee

The retained domain is a finite union of closed intervals. Evaluate feasible
points to obtain incumbent B. For every interval R compute a valid lower bound
L(R). Discard R only when L(R) > B, preserving all tied minimizers. Split the
remaining interval with smallest lower bound into two closed halves.

Every discarded interval has all values strictly above a feasible value, so
cannot contain any global minimizer. Closed child intervals cover their parent.
Inductively at least one retained interval covers each global minimizer.
Consequently min_R L(R) <= global minimum <= B. Stop when B-min_R L(R) <= epsilon.
This is an objective certificate, not a bound on distance to the optimizer.
The generic solver relies on the caller supplying a valid lower-bound function.

All objective values, endpoints, and bound comparisons use Python Fraction
arithmetic. Certificates describe the exact rational parameter values supplied.
Decimal strings or explicit fractions should be used for intended decimal inputs;
passing a float instead certifies its exact binary representation. CSV decimals
are display approximations; certificates.json preserves rational quantities.

For SIS, write s=a*i*p and f(u)=c*u^2-s*u^2/(K^2+u^2). On [l,h] with l>=0,
u^2/(K^2+u^2) is increasing. A lower bound is
c*l^2-s*h^2/(K^2+h^2) when s>=0, and f(l) when s<0.
These bounds tighten to the point value as interval width vanishes.

For (u^2-1)^2, propagate the exact range of squaring twice, with subtraction of
one between operations. This provides an independent tied-minimum test at +/-1.

## Reproduction

Requires Python 3, standard library only. From this folder run:

    python run_verification.py

The script regenerates results.csv and certificates.json. Each certificate
records the returned control, exact bounds, final retained cells, and every
excluded cell with the lower bound and incumbent at exclusion. Shared endpoints
can occur in adjacent closed cells. Budget exhaustion returns certified=False.

## Verification evidence

Eight cases: negative sensitivity, zero sensitivity, below activation threshold,
exact activation threshold, interior optimum, upper-boundary optimum, two tied
minima, and a constant objective with every control optimal.

Checks include analytical SIS objective agreement (floating-point reference),
exact strict inequalities for exclusions, retention of both known tied minima,
resource-exhaustion behavior, and exact sampled lower-bound checks on 32 cells
per landscape. The analytic derivation above, rather than sampled checks alone,
justifies the lower bounds. This is not a formal proof-assistant verification.

For the interior SIS example, returned control = 1.11181640625; analytical
control approximately 1.11178594050. Certified objective gap = 0.0000991031,
using 435 point evaluations. Retained cells: 142 with elimination versus 217
without elimination at the same evaluation budget.

For the double well, both global minimizers remain covered; 2 cells remain,
versus 8 without elimination. Objective gap = 0.0000607970.

The comparison uses the same best-lower-bound splitting search without pruning,
at matched point-evaluation budgets. All reported objective gaps match between
variants. Thus this study shows reduced stored regions, not fewer objective
evaluations or a wall-clock speedup. Runtime and bound-evaluation costs have not
been benchmarked. Exact rational arithmetic is chosen for auditability, not speed.

## Scope and next milestone

This verifies fixed-landscape selection, not an HJB PDE solution, a learned
policy, stochastic stability, disease extinction, or biological effectiveness.
No gene-regulatory transfer or neural training has yet been performed.

Next: select one published gene-regulatory model and define a biologically
interpretable intervention and objective. Check state admissibility and whether
control minimization actually requires global search. Obtain a conventional
reference solution before adding neural approximation. A later epidemic-control
demonstration must solve and simulate the closed-loop control problem; the
present SIS landscapes use specified sensitivities, not computed value derivatives.
