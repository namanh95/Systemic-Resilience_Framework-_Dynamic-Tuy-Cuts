"""Run verification and write auditable exact certificates beside this script."""
from fractions import Fraction as Q
from pathlib import Path
import csv
import json
import math
from certified_selection import solve, sis, double_well

ROOT = Path(__file__).resolve().parent


def main():
    cases = []
    for label, p, umax in [('negative_sensitivity', -1, 2),
                           ('zero_sensitivity', 0, 2),
                           ('below_threshold', Q(1,10), 2),
                           ('threshold', Q(1,5), 2),
                           ('interior', 1, 2),
                           ('upper_boundary', 20, 1)]:
        value, lower = sis(p=p)
        s = float(Q(1,2)*p)
        optimum = 0.0 if s <= .1 else min(float(umax), math.sqrt(math.sqrt(s/.1)-1))
        exact_value = .1*optimum**2-s*optimum**2/(1+optimum**2)
        cases.append((label, value, lower, Q(0), Q(umax), optimum, exact_value))
    value, lower = double_well()
    cases.append(('tied_minima', value, lower, Q(-3,2), Q(3,2), None, 0.0))
    cases.append(('flat_all_tied', lambda u: Q(0), lambda a,b: Q(0), Q(0), Q(1), None, 0.0))
    rows, certificates = [], {}
    for name, value, lower, left, right, optimum, reference in cases:
        result = solve(value, lower, left, right)
        assert result['certified'], name
        assert float(result['lower'])-1e-12 <= reference <= float(result['upper'])+1e-12, name
        assert all(lb > ub for a,b,lb,ub in result['exclusions'])
        if name == 'tied_minima':
            for minimizer in (Q(-1), Q(1)):
                assert any(a <= minimizer <= b for _,a,b in result['cells'])
                assert all(not a <= minimizer <= b for a,b,_,_ in result['exclusions'])
        # Compare with the same best-lower-bound search, without elimination,
        # at exactly the same objective-evaluation budget.
        baseline = solve(value, lower, left, right, tolerance=Q(1,10**12),
                         budget=result['evaluations'], prune=False)
        rows.append(dict(case=name, control=float(result['control']),
                         analytical_control=optimum, lower=float(result['lower']),
                         upper=float(result['upper']), gap=float(result['gap']),
                         evaluations=result['evaluations'], retained=len(result['cells']),
                         excluded=len(result['exclusions']),
                         no_prune_gap=float(baseline['gap']),
                         no_prune_cells=len(baseline['cells'])))
        certificates[name] = result
    # Resource exhaustion must never be reported as successful certification.
    value, lower = sis()
    assert not solve(value, lower, 0, 2, tolerance=Q(1,10**12), budget=3)['certified']
    # Independently sample bound validity using exact arithmetic on many cells.
    for _, value, lower, left, right, _, _ in cases:
        for j in range(32):
            a = left+(right-left)*Q(j,32)
            b = left+(right-left)*Q(j+1,32)
            assert all(lower(a,b) <= value(a+(b-a)*Q(k,8)) for k in range(9))
    with (ROOT/'results.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)
    (ROOT/'certificates.json').write_text(json.dumps(certificates,default=str,indent=2))
    print(json.dumps(rows,indent=2))
    print('PASS: 8 landscapes; tied-minimizer retention; strict exclusions; budget failure; sampled bound checks.')


if __name__ == '__main__':
    main()
