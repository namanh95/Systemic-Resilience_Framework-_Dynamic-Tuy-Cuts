"""Exact-rational, one-dimensional branch-and-bound research baseline.

Python standard library only. Bounds must be mathematically valid on each
closed interval. Strict pruning preserves every tied global minimizer.
"""
from fractions import Fraction as Q
import heapq


def solve(value, lower, left, right, tolerance=Q(1, 10000), budget=20000,
          prune=True):
    left, right = Q(left), Q(right)
    if left >= right or tolerance <= 0 or budget < 3:
        raise ValueError('Invalid domain, tolerance, or evaluation budget')
    cache = {}
    def evaluate(x):
        if x not in cache:
            cache[x] = value(x)
        return cache[x]
    for x in (left, right, (left + right) / 2):
        evaluate(x)
    incumbent = min(cache, key=cache.get)
    upper = cache[incumbent]
    cells = [(lower(left, right), left, right)]
    audit = []
    while True:
        if prune:
            kept = []
            for lb, a, b in cells:
                if lb > upper:
                    audit.append((a, b, lb, upper))
                else:
                    kept.append((lb, a, b))
            cells = kept
            heapq.heapify(cells)
        lb = cells[0][0]
        if upper - lb <= tolerance or len(cache) + 2 > budget:
            break
        _, a, b = heapq.heappop(cells)
        mid = (a + b) / 2
        for lo, hi in ((a, mid), (mid, b)):
            x = (lo + hi) / 2
            y = evaluate(x)
            if y < upper:
                incumbent, upper = x, y
            heapq.heappush(cells, (lower(lo, hi), lo, hi))
    return dict(control=incumbent, upper=upper, lower=lb,
                gap=upper-lb, certified=upper-lb <= tolerance,
                evaluations=len(cache), cells=cells, exclusions=audit)


def sis(a=Q(1), i=Q(1, 2), p=Q(1), K=Q(1), cost=Q(1, 10)):
    a, i, p, K, cost = map(Q, (a, i, p, K, cost))
    if a <= 0 or K <= 0 or cost <= 0 or not 0 <= i <= 1:
        raise ValueError('Invalid SIS parameters')
    s = a*i*p
    def value(u):
        return cost*u*u - s*u*u/(K*K+u*u)
    def lower(lo, hi):
        if lo < 0:
            raise ValueError('SIS controls must be nonnegative')
        # u^2/(K^2+u^2) is increasing on nonnegative controls.
        endpoint = hi if s >= 0 else lo
        return cost*lo*lo - s*endpoint*endpoint/(K*K+endpoint*endpoint)
    return value, lower


def square_bounds(a, b):
    return (Q(0) if a <= 0 <= b else min(a*a, b*b), max(a*a, b*b))


def double_well():
    def value(u):
        return (u*u-1)**2
    def lower(a, b):
        lo, hi = square_bounds(a, b)
        return square_bounds(lo-1, hi-1)[0]
    return value, lower
