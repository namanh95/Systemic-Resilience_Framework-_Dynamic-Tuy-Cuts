# Fixed-budget targeted sampling experiment

3 November 2026. Declared before new training or test results.

Compare baseline sampling with one fixed targeted-sampling intervention using
the original 8-32-32-1 Network (including its existing endpoint override).
No architecture or loss-weight change. Both arms have 40,000 samples, 200 epochs,
the same Adam schedule, feature normalization computed from baseline training,
paired initial weights (63,64,65), and batch orders (2963,2964,2965, as used by
the existing training helper). Validation and checkpoint rules are identical.

Generate baseline training with seed 3901. In the targeted arm, keep every state
coordinate and replace only the remaining times of 10,000 randomly selected
rows (selection seed 3906) by uniform [.1,.5) draws (3907); recompute labels.
The targeted interval therefore receives approximately 29.5% instead of 6% of
training points. This also reduces other-time coverage, which must be audited.
Use shared 6,000-point standard-mixture validation (3902). Checkpoint selection
uses the existing weighted log-value objective; no targeted validation tuning.

Freeze all six checkpoints and validation diagnostics before final tests:
6,000 standard-mixture points (3903), plus 4,000 targeted points (state seed
3904, time seed 3905). Do not reuse earlier tests. Each model must reach >=95%
within .02+.05*abs(reference value) overall, time<2, and targeted [.1,.5).
Require all three targeted-arm models to pass all components for stage success.
Report all individual outcomes and time bands, including potential deterioration
outside the targeted interval, paired error differences, and worst errors.

This is one sampling ablation, not a hyperparameter search. No post-test tuning,
seed selection, architecture selection, or new closed-loop claim. Raw data,
models, histories, hashes and failures are retained. Prior control results do
not validate these newly trained models. Separate fresh control tests are needed
before claiming improved intervention performance. Three seeds on one shared
dataset do not establish dataset robustness, biological efficacy or optimality.
