"""Certify frozen Hamiltonians using approximate reference-value derivatives.

These certificates do NOT bound value-function derivative error.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
import numpy as np
from reference_control import ROOT,INITIAL,TARGET,A1,A2
from validated_selector import select


def main():
    path=ROOT/'n101_u41_dt0.05.npz'
    data=np.load(path)
    grid=data['grid'];v=data['value0']
    results=[]
    for label,state in [('initial',INITIAL),('target',TARGET),('middle',np.array([.2,.2]))]:
        x,y=state
        i=int(np.clip(np.searchsorted(grid,x,side='right')-1,0,len(grid)-2))
        j=int(np.clip(np.searchsorted(grid,y,side='right')-1,0,len(grid)-2))
        a=(x-grid[i])/(grid[i+1]-grid[i])
        p=((1-a)*(v[i,j+1]-v[i,j])+a*(v[i+1,j+1]-v[i+1,j]))/(grid[j+1]-grid[j])/A2
        # Certify exact decimal representations of these approximate quantities.
        physical_x=str(float(x*A1));sensitivity=str(float(p))
        r=select(physical_x,sensitivity)
        assert r['certified']
        results.append(dict(label=label,x=physical_x,approximate_p=sensitivity,certificate=r))
        print(label,'p=',p,'control=',float(r['control']),'gap=',float(r['gap']))
    (ROOT/'reference_selection_certificates.json').write_text(json.dumps(results,default=str,indent=2))


if __name__=='__main__':
    main()
