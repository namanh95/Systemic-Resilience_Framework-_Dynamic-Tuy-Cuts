"""Aggregate predeclared numerical screens and Monte Carlo summaries."""
import csv
import json
import math
from stochastic_reference import ROOT,STATES


def wilson(k,n):
    z=1.96;p=k/n;den=1+z*z/n
    mid=(p+z*z/(2*n))/den
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [mid-half,mid+half]


def main():
    names=['deterministic','noise005','noise010','domain125','domain200','boundary400','space91','time005','quadrature3']
    data={name:json.loads((ROOT/('stochastic_'+name+'.json')).read_text()) for name in names}
    base=data['noise005']['initial_values'];screens={}
    for name in names[3:]:
        ref=data['domain125']['initial_values'] if name=='boundary400' else base
        tol=.01 if name in ('domain125','domain200','boundary400') else .02
        values=data[name]['initial_values']
        differences={s:abs(values[s]-ref[s]) for s in STATES}
        ratios={s:differences[s]/(tol+tol*abs(values[s])) for s in STATES}
        screens[name]=dict(max_absolute=max(differences.values()),max_tolerance_ratio=max(ratios.values()),
                           passed=max(ratios.values())<=1,by_state_absolute=differences)
    rows=[];discrepancies={}
    for name in names[:3]:
        discrepancies[name]={}
        for label,runs in data[name]['simulations'].items():
            for kind in ('feedback','zero','pulse'):
                r=runs[kind];ci=r['cost']['approx_95ci'];n=r['paths'];fraction=r['fraction_within_005']
                rows.append(dict(case=name,initial_state=label,policy=kind,paths=n,
                    mean_cost=r['cost']['mean'],ci_low=ci[0],ci_high=ci[1],
                    final_distance=r['final_target_distance']['mean'],fraction_within_005=fraction,
                    success_wilson95=wilson(round(fraction*n),n) if n>1 else None,
                    exited_paths=r['exited_paths'],mean_integral_z_squared=r['integral_z_squared']['mean']))
            f=runs['feedback']['cost'];value=data[name]['initial_values'][label]
            discrepancies[name][label]=dict(dp_value=value,mc_mean=f['mean'],difference=value-f['mean'],mc_se=f['se'])
    with (ROOT/'stochastic_comparison.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    out=dict(numerical_screens=screens,all_screens_passed=all(r['passed'] for r in screens.values()),
             value_mc_discrepancies=discrepancies,
             no_exits_upper95_for_256=1-.05**(1/256),
             uncertainty_scope='Approximate cost confidence intervals cover Monte Carlo sampling only; no model or discretization error.')
    (ROOT/'stochastic_assessment.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
