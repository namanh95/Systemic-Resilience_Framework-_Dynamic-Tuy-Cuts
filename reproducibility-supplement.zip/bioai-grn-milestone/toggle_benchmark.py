"""Deterministic reference checks, not an optimal controller or SDE solver.

Gardner2000 / BIOMD0000000507 parameterization. Standard library only.
Control z is inducer concentration divided by 2.9618e-5 (source scale).
"""
from pathlib import Path
import csv
import json
import math

A1, A2, BETA, GAMMA, ETA = 156.25, 15.6, 2.5, 1.0, 2.0015
INDUCER_SCALE = 2.9618e-5
ROOT = Path(__file__).resolve().parent


def drift(state, z=0.0):
    x, y = state
    if min(x, y, z) < 0:
        raise ValueError('States and inducer must be nonnegative')
    active_x = x/(1+z)**ETA
    return A1/(1+y**BETA)-x, A2/(1+active_x**GAMMA)-y


def equilibria():
    # At z=0 and gamma=1, y=A2/(1+x); reduce to a scalar equation.
    def f(x):
        return A1/(1+(A2/(1+x))**BETA)-x
    roots = []
    for j in range(10000):
        lo, hi = A1*j/10000, A1*(j+1)/10000
        if f(lo)*f(hi) < 0:
            for _ in range(60):
                mid = (lo+hi)/2
                if f(lo)*f(mid) <= 0:
                    hi = mid
                else:
                    lo = mid
            x = (lo+hi)/2
            y = A2/(1+x)
            off1 = -A1*BETA*y**(BETA-1)/(1+y**BETA)**2
            off2 = -A2/(1+x)**2
            eigenvalues = [-1-math.sqrt(off1*off2), -1+math.sqrt(off1*off2)]
            roots.append(dict(state=[x,y], eigenvalues=eigenvalues,
                              stable=max(eigenvalues)<0,
                              residual=max(map(abs,drift((x,y))))))
    return roots


def rk4(state, z, dt):
    def shift(k, scale):
        return tuple(state[j]+scale*k[j] for j in range(2))
    k1=drift(state,z); k2=drift(shift(k1,dt/2),z)
    k3=drift(shift(k2,dt/2),z); k4=drift(shift(k3,dt),z)
    result=tuple(state[j]+dt*(k1[j]+2*k2[j]+2*k3[j]+k4[j])/6 for j in range(2))
    if min(result)<0:
        raise ArithmeticError('Negative numerical state; reduce time step')
    return result


def simulate(initial, amplitude, dt, horizon=50.0, pulse_end=5.0):
    state=tuple(initial); rows=[]
    for k in range(round(horizon/dt)+1):
        t=k*dt
        z=amplitude if t<pulse_end else 0.0
        rows.append((t,*state,z))
        if k<round(horizon/dt):
            state=rk4(state,z,dt)
    return rows


def main():
    eq=equilibria()
    assert len(eq)==3 and [e['stable'] for e in eq]==[True,False,True]
    assert max(e['residual'] for e in eq)<1e-10
    # Check inward/tangent drift on the deterministic invariant rectangle.
    for k in range(101):
        z=10*k/100
        assert drift((0,A2),z)[0]>0 and drift((A1,0),z)[0]<=0
        assert drift((A1,0),z)[1]>0 and drift((0,A2),z)[1]<=0
    summary={'equilibria':eq,'parameters':dict(alpha1=A1,alpha2=A2,beta=BETA,
              gamma=GAMMA,eta=ETA,inducer_scale=INDUCER_SCALE),'runs':{}}
    for label,amp in [('uncontrolled',0.0),('pulse',10.0)]:
        fine=simulate(eq[-1]['state'],amp,.005)
        coarse=simulate(eq[-1]['state'],amp,.01)
        error=max(abs(fine[2*k][j]-row[j]) for k,row in enumerate(coarse) for j in (1,2))
        assert error<1e-5
        assert all(0<=r[1]<=A1+1e-10 and 0<=r[2]<=A2+1e-10 for r in fine)
        with (ROOT/(label+'.csv')).open('w',newline='') as stream:
            writer=csv.writer(stream);writer.writerow(['time','repressor_1','repressor_2','normalized_inducer']);writer.writerows(fine)
        final=fine[-1][1:3]
        summary['runs'][label]={'final_state':final,'step_halving_max_error':error,
            'distance_to_low_x_equilibrium':math.dist(final,eq[0]['state'])}
    assert summary['runs']['pulse']['distance_to_low_x_equilibrium']<.01
    assert math.dist(summary['runs']['uncontrolled']['final_state'],eq[-1]['state'])<1e-9
    (ROOT/'verification.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
    print('PASS: three equilibria, stability classification, boundaries, pulse switching, step halving.')


if __name__=='__main__':
    main()

