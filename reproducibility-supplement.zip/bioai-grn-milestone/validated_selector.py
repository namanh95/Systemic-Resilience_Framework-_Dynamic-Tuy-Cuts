"""Validated fractional-power enclosures; rational branch-and-bound interface."""
from decimal import Decimal as D, localcontext, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'bioai-baseline'))
from certified_selection import solve


@lru_cache(maxsize=50000)
def power_bounds(t, precision=40):
    """Enclose t^(4003/2000), for rational t>=1, as exact rationals.

    ln/exp are correctly rounded to nearest by Decimal. Adjacent representable
    numbers enclose their exact values. Intermediate products round outward.
    No use of Decimal's non-guaranteed correctly-rounded power operation.
    """
    t=Q(t)
    if t<1:
        raise ValueError('This enclosure supports t>=1')
    if t==1:
        return Q(1),Q(1)
    with localcontext() as ctx:
        ctx.prec=precision
        ctx.rounding=ROUND_FLOOR
        lo=D(t.numerator)/D(t.denominator)
        ctx.rounding=ROUND_CEILING
        hi=D(t.numerator)/D(t.denominator)
        loglo=lo.ln().next_minus()
        loghi=hi.ln().next_plus()
        ctx.rounding=ROUND_FLOOR
        elo=loglo*D('2.0015')
        ctx.rounding=ROUND_CEILING
        ehi=loghi*D('2.0015')
        plo=elo.exp().next_minus()
        phi=ehi.exp().next_plus()
        if not plo.is_finite() or not phi.is_finite():
            raise ArithmeticError('Nonfinite power enclosure')
        return Q(plo),Q(phi)


def objective_bounds(x,p,z):
    x,p,z=map(Q,(x,p,z))
    if x<0 or z<0:
        raise ValueError('Nonnegative state and control required')
    lo,hi=power_bounds(1+z)
    gl=Q('15.6')*lo/(lo+x)
    gh=Q('15.6')*hi/(hi+x)
    base=Q('.01')*z*z
    return (base+p*gl,base+p*gh) if p>=0 else (base+p*gh,base+p*gl)


def select(x,p,tolerance=Q(1,10000),budget=20000):
    x,p=Q(x),Q(p)
    def upper(z):
        return objective_bounds(x,p,z)[1]
    def lower(a,b):
        endpoint=a if p>=0 else b
        return objective_bounds(x,p,endpoint)[0]-Q('.01')*endpoint**2+Q('.01')*a*a
    return solve(upper,lower,0,10,tolerance=tolerance,budget=budget)


def verify():
    import json
    # Independent exact-integer oracle for the fractional power enclosure.
    # Positive q bounds t^(4003/2000) iff q^2000 bounds t^4003.
    for t in (Q(1),Q(11,10),Q(3,2),Q(7),Q(11)):
        lo,hi=power_bounds(t)
        assert lo**2000 <= t**4003 <= hi**2000
    results={}
    for x,p in [('0','-1'),('.33241859','-1'),('1.31654607','-.1'),
                ('155.76340774','-1'),('155.76340774','-.01'),
                ('155.76340774','0'),('155.76340774','1')]:
        r=select(x,p)
        assert r['certified']
        assert all(lb>ub for a,b,lb,ub in r['exclusions'])
        # A dense sampled feasible minimum provides an independent upper bound,
        # not a continuous-global certificate.
        sampled=min(objective_bounds(x,p,Q(j,100))[1] for j in range(1001))
        assert r['lower']<=sampled
        assert r['upper']<=sampled+Q(1,10000)
        if Q(p)>=0 or Q(x)==0:
            assert r['control']==0
        results[f'x={x},p={p}']=r
    assert not select('155','-1',budget=3)['certified']
    Path(__file__).with_name('grn_certificates.json').write_text(json.dumps(results,default=str,indent=2))
    print(json.dumps({k:{s:float(v[s]) for s in ['control','gap','evaluations']} for k,v in results.items()},indent=2))
    print('PASS: exact integer power checks, seven selector cases, budget exhaustion.')


if __name__=='__main__':
    verify()
