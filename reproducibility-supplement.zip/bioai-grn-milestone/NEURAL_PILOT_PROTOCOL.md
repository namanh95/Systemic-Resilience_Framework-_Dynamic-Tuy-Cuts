# First neural pilot protocol

2 November 2026. No results were inspected when setting this protocol.

Train one small supervised value network against the frozen sigma=.05 reference.
This is not yet a physics-informed network or a new control theorem. Use two
32-unit tanh hidden layers, Adam, and validation-only checkpoint selection.
Training, validation, and test samples use separate fixed seeds; test labels
are not used to choose architecture, epochs, or checkpoint. Model features may
include the known terminal cost and nonlinear state/time transforms.

Use 40,000 training, 6,000 validation, and 6,000 test points, sampled in normalized
states [0,1.2]^2 with extra density near the target and low-x transition region.
Sample remaining times throughout [0,50], with extra coverage near the terminal
time. Labels interpolate the frozen reference in state and time. Enforce the
known terminal value exactly at remaining time zero. Compare predictions on
held-out points to tolerance .02+.05*abs(reference value); an exploratory pilot
screen requires at least 95% within that tolerance. This is a practical target,
not a theorem and not the reference's stricter numerical validation tolerance.

Evaluate neural and reference policies on 256 paired fresh noisy trajectories
from high-x, target, saddle, and mixed states. Use the same 61 control candidates,
decision interval .1, quadrature rule, model, and cost. Neural control uses
one-step Bellman lookahead, not unvalidated neural derivatives. Outside the
training box, use zero control and count fallback events. Do not silently use
the teacher to rescue a failing neural policy.

For a rollout screen, require the upper approximate 95% confidence endpoint of
paired neural-minus-reference cost to be <= .01+.05*reference mean cost for
each starting state. Record failures without tuning on these test paths.
The simulation step is .025 and noise intensity .05. Approximate confidence
intervals cover sampling error only. Record runtime rather than assuming speedup.

No new biological validity, derivative accuracy, certified control gap, or
near-optimality claim follows from passing this pilot. Preserve failures and
keep the frozen reference manifest unchanged; record training in a new manifest.
