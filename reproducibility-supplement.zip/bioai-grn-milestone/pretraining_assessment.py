"""Assess fixed pretraining gates, paired simulations, and exploratory holdouts."""
import json
import numpy as np
from stochastic_reference import ROOT,STATES,setup,interpolate,summary


def read(name):return json.loads((ROOT/(name+'.json')).read_text())


def main():
    old=read('stochastic_local0p5');baseline=read('pretraining_baseline')
    cases={k:read('pretraining_'+k) for k in ('time','control','quadrature','higher_noise','higher_noise_coarser')}
    screens={}
    for case in ('time','control','quadrature','higher_noise'):
        base=cases['higher_noise_coarser'] if case=='higher_noise' else old
        refined=cases[case]
        diffs={s:abs(refined['initial_values'][s]-base['initial_values'][s]) for s in STATES}
        ratios={s:diffs[s]/(.005+.01*abs(refined['initial_values'][s])) for s in STATES}
        screens[case]=dict(passed=max(ratios.values())<=1,max_absolute=max(diffs.values()),
                           max_tolerance_ratio=max(ratios.values()),absolute_by_state=diffs)
    agreement={};paired={}
    for case,data in [('baseline',{**old,'simulations':baseline['simulations']}),*cases.items()]:
        if 'simulations' not in data:continue
        agreement[case]={}
        for state,r in data['simulations'].items():
            m=r['cost']['mean'];se=r['cost']['se'];v=data['initial_values'][state]
            threshold=.005+.01*abs(m)+1.96*se
            agreement[case][state]=dict(dp_value=v,mc_mean=m,mc_se=se,difference=v-m,
                                       threshold=threshold,passed=abs(v-m)<=threshold)
            if case in ('time','control','quadrature'):
                a=np.load(ROOT/('pretraining_'+case+'_'+state+'_costs.npy'))
                b=np.load(ROOT/('pretraining_baseline_'+state+'_costs.npy'))
                paired.setdefault(case,{})[state]=summary(a-b)
    # Exploratory value-only comparison on new off-grid states and intermediate
    # times. Seed fixed here; these holdouts were not a prespecified gate.
    rng=np.random.default_rng(271828)
    broad=rng.uniform(.001,.999,(64,2))
    near=np.column_stack([rng.uniform(.001,.006,64),rng.uniform(.55,.95,64)])
    points=np.r_[broad,near];holdouts={}
    f=np.load(ROOT/'stochastic_local0p5_policy.npz')
    bg=(f['gridx'],f['gridy']);bv=f['values']
    times=[0.,10.,25.,40.,49.]
    for case in ('time','control','quadrature'):
        rf=np.load(ROOT/('pretraining_'+case+'_policy.npz'))
        rg=(rf['gridx'],rf['gridy']);rv=rf['values'];rp=json.loads(str(rf['parameters']))
        deltas=[];ratios=[]
        for t in times:
            a=interpolate(bv[round(t/.1)],setup(bg,points[:,0],points[:,1]))
            b=interpolate(rv[round(t/rp['dt'])],setup(rg,points[:,0],points[:,1]))
            deltas.extend(np.abs(a-b).tolist());ratios.extend((np.abs(a-b)/(.005+.01*np.abs(b))).tolist())
        holdouts[case]=dict(points=128,times=times,max_absolute=max(deltas),
                            max_scaled=max(ratios),exceedances=int(np.sum(np.array(ratios)>1)),comparisons=len(deltas))
        del rv;rf.close()
    result=dict(value_screens=screens,all_value_screens_passed=all(r['passed'] for r in screens.values()),
                value_mc_agreement=agreement,
                all_mc_agreement_passed=all(r['passed'] for states in agreement.values() for r in states.values()),
                paired_refinement_minus_baseline=paired,
                coupled_integration=baseline['integration_checks'],exploratory_holdouts=holdouts,
                scope='Empirical numerical checks only; no derivative-error, uniform-convergence, or optimality certificate.')
    (ROOT/'pretraining_assessment.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ('coupled_integration','paired_refinement_minus_baseline')},indent=2))


if __name__=='__main__':main()
