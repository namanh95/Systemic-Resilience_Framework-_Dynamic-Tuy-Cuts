"""Fresh coupled-path checks for the existing local reference."""
import json
import numpy as np
from stochastic_reference import ROOT,STATES,simulate,summary


if __name__=='__main__':
    f=np.load(ROOT/'stochastic_local0p5_policy.npz')
    grid=(f['gridx'],f['gridy']);u=f['controls'];v=f['values'];p=json.loads(str(f['parameters']))
    result={'parameters':p,'simulations':{}}
    for i,label in enumerate(('high_x','target','saddle')):
        coarse,c=simulate(grid,u,v,p,STATES[label],paths=256,seed=20262000+i,h=.025,coupling_h=.0125)
        fine,fc=simulate(grid,u,v,p,STATES[label],paths=256,seed=20262000+i,h=.0125,coupling_h=.0125)
        np.save(ROOT/('pretraining_baseline_'+label+'_costs.npy'),c)
        result['simulations'][label]=coarse
        result.setdefault('integration_checks',{})[label]={
            'fine':fine,'paired_fine_minus_coarse':summary(fc-c)}
        (ROOT/'pretraining_baseline.json').write_text(json.dumps(result,indent=2))
        print(label,coarse['cost'],result['integration_checks'][label]['paired_fine_minus_coarse'],flush=True)
