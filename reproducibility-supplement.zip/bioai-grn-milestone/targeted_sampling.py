"""Single prespecified sampling ablation; original network and fixed budget."""
import json
import numpy as np
import matched_architecture as matched
from neural_pilot import Network, features, samples, teacher, gradient_test
from stochastic_reference import ROOT, summary
from matched_architecture import labels, audit, stats, sha

OUT=ROOT/'targeted_sampling'
SEEDS=(63,64,65)
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2))
def modelpath(arm,seed):return OUT/arm/f'original_{seed}.npz'

def main():
    OUT.mkdir(exist_ok=True);gradient_test()
    grid,u,values,params=teacher()
    bp,bv=samples(3901,40000,grid,values);vp,vv=samples(3902,6000,grid,values)
    tp=bp.copy();ix=np.random.default_rng(3906).choice(len(bp),10000,replace=False)
    tp[ix,2]=np.random.default_rng(3907).uniform(.1,.5,len(ix));tv=labels(tp,grid,values)
    assert np.array_equal(tp[:,:2],bp[:,:2])
    other=np.ones(len(bp),bool);other[ix]=False
    assert np.array_equal(tp[other],bp[other]) and np.max(np.abs(tv[other]-bv[other]))<1e-12
    f=features(bp);mean=f.mean(0);scale=np.maximum(f.std(0),1e-6)
    np.savez_compressed(OUT/'data.npz',baseline_points=bp,baseline_values=bv,
        targeted_points=tp,targeted_values=tv,replaced_rows=ix,validation_points=vp,validation_values=vv)
    arms={'baseline':(bp,bv),'targeted':(tp,tv)};training={};validation={};predictions={}
    for seed in SEEDS:
        for arm,(p,y) in arms.items():
            matched.OUT=OUT/arm;matched.OUT.mkdir(exist_ok=True)
            name=f'{arm}_{seed}'
            training[name]=matched.train_one('original',seed,p,y,vp,vv,mean,scale)
            model=Network.load(modelpath(arm,seed));predictions[name]=model.predict(*vp.T)
            validation[name]=audit(vp,vv,predictions[name]);save('training.json',training)
    save('validation.json',validation)
    np.savez_compressed(OUT/'validation_predictions.npz',**predictions)
    save('pretest_freeze.json',dict(models={f'{a}_{s}':sha(modelpath(a,s)) for a in arms for s in SEEDS},
        data_sha256=sha(OUT/'data.npz'),validation_sha256=sha(OUT/'validation.json'),
        protocol_sha256=sha(ROOT/'TARGETED_SAMPLING_PROTOCOL.md'),
        training_focus_fraction={a:float(np.mean((p[:,2]>=.1)&(p[:,2]<.5))) for a,(p,y) in arms.items()}))
    p,y=samples(3903,6000,grid,values);fp,_=samples(3904,4000,grid,values)
    fp[:,2]=np.random.default_rng(3905).uniform(.1,.5,len(fp));fy=labels(fp,grid,values)
    arrays=dict(points=p,reference=y,focus_points=fp,focus_reference=fy);results={};paired={}
    for seed in SEEDS:
        for arm in arms:
            name=f'{arm}_{seed}';model=Network.load(modelpath(arm,seed))
            z=model.predict(*p.T);fz=model.predict(*fp.T)
            arrays[name]=z;arrays['focus_'+name]=fz
            normal=audit(p,y,z);focus=stats(fy,fz)
            results[name]=dict(standard=normal,focused=focus,
                passed=all(v>=.95 for v in [normal['all']['fraction'],normal['time_lt2']['fraction'],focus['fraction']]))
        paired[str(seed)]={}
        for prefix,ref in [('',y),('focus_',fy)]:
            old=arrays[f'{prefix}baseline_{seed}'];new=arrays[f'{prefix}targeted_{seed}']
            paired[str(seed)][prefix or 'standard']=dict(absolute_error_difference=summary(np.abs(new-ref)-np.abs(old-ref)),
                tolerance_fraction_difference=float(np.mean(np.abs(new-ref)<=.02+.05*ref)-np.mean(np.abs(old-ref)<=.02+.05*ref)))
    np.savez_compressed(OUT/'heldout.npz',**arrays)
    save('test_results.json',dict(models=results,paired=paired,
        targeted_all_seeds_passed=all(results[f'targeted_{s}']['passed'] for s in SEEDS)))
    print(json.dumps({n:dict(overall=r['standard']['all']['fraction'],near=r['standard']['time_lt2']['fraction'],focused=r['focused']['fraction'],passed=r['passed']) for n,r in results.items()}),flush=True)

if __name__=='__main__':main()
