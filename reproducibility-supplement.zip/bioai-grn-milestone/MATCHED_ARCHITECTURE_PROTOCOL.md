# Matched architecture comparison and near-terminal diagnosis

3 November 2026. Written before generating new results.

This milestone isolates value approximation; it does not repeat closed-loop
control evaluation or establish improved control. Compare the existing original
Network and continuous TerminalNetwork implementations without tuning either.
Their output clipping rules are part of the compared implementations.

Train both with identical 40,000 training points (2901), 6,000 validation points
(2902), features, normalization, initial parameter arrays for each paired seed
(53,54,55), minibatch order (2953,2954,2955), Adam and learning-rate schedule.
Use 200 epochs for every run, with checkpoint selection every five epochs on
the same weighted log-value validation objective. Fixed budgets avoid differing
early-stop update counts. Checkpoints may differ in selected epoch.

Before opening tests, save validation diagnostics by time band and state region,
loss contribution, residual quantiles, and terminal teacher interpolation error.
Inspect the known blend gate's squared multiplier in the training loss. These
are descriptive diagnostics, not proof of a causal failure mechanism. Do not
alter architecture or loss in response during this experiment.

After all six checkpoints and diagnostics are frozen, generate 6,000 standard
mixture test points (2903) and a separate 4,000-point targeted test (state sample
2904, time seed 2905) with the same state mixture and times uniform in [.1,.5).
Report these separately.
Use the same numerical reference interpolation as previous stages. Verify the
new general label evaluator against the existing sampler. Preserve all models.

Value criterion per model: >=95% within .02+.05*abs(reference value) on the
standard mixture, its time<2 subgroup, AND the targeted [.1,.5) test. Report
each component. A robust constrained-model pass requires all three constrained
seeds to meet every component. Compare paired absolute errors and tolerance
fractions for each matched seed, without declaring architecture superiority
from unadjusted intervals or three seeds. No test-based selection/retraining.

Record source/data/model hashes, raw predictions, validation diagnostics and
training histories. Shared datasets do not assess dataset variability. Reference
accuracy, biological validity, derivatives, policy cost and runtime advantage
are not certified by this value-only experiment. Subsequent method changes need
fresh held-out tests and separate control evaluation.
