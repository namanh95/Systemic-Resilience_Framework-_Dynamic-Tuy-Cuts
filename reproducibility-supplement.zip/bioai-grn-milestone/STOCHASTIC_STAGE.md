# Multiple initial states and stochastic reference: stage report

Completed 2 November 2026

## Outcome and scope

Implemented a stochastic dynamic-programming reference, evaluated six initial states, tested domain and exit-payoff sensitivity, and compared feedback with zero control and a preset pulse. This is a computational study of the proposed mathematical model, not experimental biological validation. The coarse stochastic value grid FAILED refinement screens. Local refinement substantially reduces its bias; the failed coarse results are preserved. A fully converged stochastic value function or globally optimal policy is not claimed.

The deterministic model and objective are unchanged from RESEARCH_SPEC.md: horizon 50, normalized squared state error, intervention penalty .01*z^2, terminal weight 10, and 0<=z<=10. Multiplicative independent environmental noise is a modeling assumption with sigma1=sigma2 in {0,.05,.10}; these intensities are not biologically calibrated.

## Initial states and evaluation design

| Label | Normalized x | Normalized y |
|---|---:|---:|
| high_x | 0.99688581 | 0.00637904 |
| target | 0.00212748 | 0.75051490 |
| saddle | 0.00842589 | 0.43167715 |
| low_both | 0.01000000 | 0.01000000 |
| mixed | 0.20000000 | 0.20000000 |
| high_both | 0.80000000 | 0.80000000 |

Each noisy state/scenario uses 256 independent Brownian realizations. The three policies share the same realizations for paired comparisons: 3,072 distinct primary noise paths, each evaluated under three policies. Additional checks use separate seeds or explicitly coupled paths. The pulse is z=10 until t=5 and zero afterward. Feedback is recomputed every .1 time units using discrete Bellman minimization.

## Numerical method and boundary handling

The simulator splits each step into half a deterministic RK4 flow, the exact positive multiplicative-noise subflow exp(-sigma^2*h/2+sigma*sqrt(h)*N), and another half deterministic flow. Running cost is integrated along the deterministic subflows. This is a numerical approximation of the full coupled SDE, not an exact SDE solution. No negative-state clipping is applied. The main simulation step is .025.

Dynamic programming uses the same split transition with two-node Gaussian quadrature per Brownian coordinate (four joint branches), bilinear interpolation, and 31 control candidates. A three-node-per-coordinate check uses nine branches. The base state grid has 61 squared-spaced nodes plus equilibrium anchors in [0,1] and .05-spaced outer nodes.

The numerical domain is [0,L]^2 with L=1.25,1.5,2. Interior nodes stay identical across domain tests. An end-of-step branch outside the domain receives exit_cost+10*target_error and no future continuation. This defines an artificial discrete stopped problem, not a reflecting boundary. Exit payoffs 100 and 400 are compared. Placeholder clipping used to index interpolation arrays is overridden by that exit payoff.

Monte Carlo trajectories are NOT stopped or reflected: full-horizon costs are recorded. Feedback defaults to zero if queried outside the domain. Exits are counted at subflow and step endpoints; continuous-time crossing events between them are not certified. Finite quadrature support can miss rare Gaussian tails, so domain agreement alone does not establish a bound for the unbounded-state problem.

## Primary policy comparisons

These are the original coarse-grid policies, kept separate from the local-refinement follow-up. Values below are simulated mean costs, not grid value estimates.

| Noise | Initial state | Feedback | Zero control | Pulse |
|---|---|---:|---:|---:|
| 0.00 | high_x | 2.463857 | 92.596939 | 6.215741 |
| 0.00 | target | 0.000000 | 0.000000 | 5.293407 |
| 0.00 | saddle | 0.058002 | 6.101831 | 5.259670 |
| 0.00 | low_both | 0.553904 | 90.925627 | 5.361571 |
| 0.00 | mixed | 0.595533 | 88.873924 | 5.276868 |
| 0.00 | high_both | 0.970260 | 87.115256 | 5.415783 |
| 0.05 | high_x | 2.518633 | 92.675446 | 6.297074 |
| 0.05 | target | 0.058096 | 0.078336 | 5.370198 |
| 0.05 | saddle | 0.116314 | 36.894597 | 5.343046 |
| 0.05 | low_both | 0.608152 | 91.083391 | 5.433738 |
| 0.05 | mixed | 0.648595 | 88.890726 | 5.356864 |
| 0.05 | high_both | 1.021666 | 87.140182 | 5.494389 |
| 0.10 | high_x | 2.664493 | 92.888437 | 7.267860 |
| 0.10 | target | 0.208756 | 0.350782 | 5.628938 |
| 0.10 | saddle | 0.266171 | 42.840592 | 5.817461 |
| 0.10 | low_both | 0.747060 | 91.379768 | 5.671482 |
| 0.10 | mixed | 0.792240 | 89.031867 | 5.608056 |
| 0.10 | high_both | 1.157268 | 87.299363 | 6.000164 |

At the deterministic target, zero control and feedback both have zero cost. In the noisy tests the feedback policies have lower sampled mean cost than the two simple comparators. This does not establish universal policy dominance or optimality. Endpoint proximity and intervention use are separate outcomes in stochastic_comparison.csv.

### Sampling uncertainty at the high-x starting state

| Noise | Feedback mean | Approximate 95% cost interval | Within target distance .05 | Exits |
|---|---:|---|---:|---:|
| 0.05 | 2.518633 | [2.508324, 2.528941] | 93.36% | 0/256 |
| 0.10 | 2.664493 | [2.640423, 2.688564] | 71.09% | 0/256 |

Cost intervals use mean +/-1.96 standard errors. They are approximate Monte Carlo intervals only: they exclude numerical bias, model error, parameter uncertainty, and multiple-comparison adjustments. The distance-.05 criterion is an illustrative endpoint tolerance, not a biological success or persistence guarantee. Wilson intervals for its fractions are in the CSV. With zero observed exits in 256 independent paths, the one-sided 95% binomial upper bound is 1.16%; zero counts do not prove zero exit probability.

## Numerical screens: retain the failures

Before the main runs, screens were specified as absolute value differences <= .01+.01*abs(refined value) for domain/boundary checks and .02+.02*abs(refined value) for spatial, temporal, and quadrature checks, over the six initial states. These are practical screening tolerances, not rigorous error bounds.

| Check | Maximum absolute change | Largest tolerance ratio (pass <=1) | Result |
|---|---:|---:|---|
| domain125 | 0 | 0.0000 | PASS |
| domain200 | 0 | 0.0000 | PASS |
| boundary400 | 0 | 0.0000 | PASS |
| space91 | 0.060594 | 2.6866 | FAIL |
| time005 | 0.0698468 | 2.7758 | FAIL |
| quadrature3 | 0.0336116 | 1.4554 | FAIL |

Domain and payoff checks apply to sigma=.05 only. They do not by themselves resolve state-grid or noise-quadrature bias, and were not repeated on every locally refined grid or at sigma=.10.

## Adaptive local refinement

The coarse target value (.188300 at sigma=.05) greatly exceeded its simulated cost (.058096 approximately), motivating a follow-up. Add nodes over normalized x in [.001,.006] and y in [.55,.95]. The first local spacings are .0001 and .005; the second halves both. Original nodes, controls, time step, and model are retained. This follow-up was chosen after observing the discrepancy, not presented as a preplanned trial.

| Grid | Initial state | DP value | MC feedback mean | MC approximate 95% interval |
|---|---|---:|---:|---|
| local1p0 | high_x | 2.519399 | 2.514185 | [2.503815, 2.524554] |
| local1p0 | target | 0.061225 | 0.054001 | [0.051188, 0.056815] |
| local1p0 | saddle | 0.115678 | 0.111188 | [0.108464, 0.113912] |
| local0p5 | high_x | 2.516613 | 2.514212 | [2.503837, 2.524587] |
| local0p5 | target | 0.057942 | 0.053993 | [0.051168, 0.056818] |
| local0p5 | saddle | 0.112610 | 0.111187 | [0.108451, 0.113922] |

Largest value change between the two local resolutions across six initial states: 0.00328266.

Local-refinement policy rollouts cover high-x, target, and saddle at sigma=.05. The other three local values are computed but their policies were not independently rolled out in this follow-up. The refined method still uses discrete controls; local time-step, control-grid, quadrature, and sigma=.10 refinements remain necessary before asserting a converged stochastic training reference.

## Coupled integration checks and value of noise-aware feedback

Fine Brownian increments are aggregated so .025 and .0125 simulations share the same Brownian paths. Deterministic and stochastic policies are then evaluated under the same noisy environment and fine increments, using 256 paths per comparison.

| Noise | State | Fine-minus-coarse mean cost | Stochastic-minus-deterministic mean cost | Paired 95% interval for latter |
|---|---|---:|---:|---|
| noise005 | high_x | 3.13774e-05 | -0.00274473 | [-0.00400981, -0.00147966] |
| noise005 | saddle | 6.14592e-06 | -0.00345212 | [-0.00482302, -0.00208122] |
| noise010 | high_x | 5.78689e-06 | -0.0217078 | [-0.0250941, -0.0183215] |
| noise010 | saddle | 9.04083e-05 | -0.0222558 | [-0.0256809, -0.0188308] |

Negative paired differences favor stochastic feedback in these simulations. These comparisons use the original coarse stochastic policies, not the locally refined follow-up. They concern numerical policies under the assumed model, not true optimal controls. Small integration differences cannot validate the separate DP grid.

## Readiness decision and next work

The multiple-initial-state and stochastic prototype stage is complete, with reproducible results and explicit failed diagnostics. The coarse stochastic value surfaces should NOT be treated as trustworthy neural training labels. Local refinement provides a better provisional reference at sigma=.05, but does not yet justify a general stochastic convergence or near-optimality claim.

Next numerical work: repeat time, quadrature, and control-grid checks on the local reference; refine the sigma=.10 case; test policy performance on additional initial states and seeds. Only then establish the stochastic reference tolerance for a neural comparison. The existing fixed-Hamiltonian certificates are separate and do not certify this stochastic dynamic-programming calculation.

## Reproduction

Python and NumPy are required. Run from this folder:

    python stochastic_reference.py
    python stochastic_checks.py
    python stochastic_local.py
    python stochastic_assessment.py
    python write_stochastic_report.py

Scripts import the existing local model and reference modules. Primary and local policy archives contain time-indexed value arrays for reproducible off-grid feedback. Per-case JSON files preserve means, uncertainty, domain exits, and numerical parameters. stochastic_comparison.csv provides the complete primary comparison table. stochastic_assessment.json preserves failed as well as passed screening results.
