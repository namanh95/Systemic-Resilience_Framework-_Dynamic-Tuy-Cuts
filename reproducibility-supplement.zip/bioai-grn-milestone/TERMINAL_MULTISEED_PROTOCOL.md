# Continuous terminal condition and training-seed replication

3 November 2026. Protocol written before training or inspecting new test results.

Keep the nominal frozen reference, features, 8-32-32-1 network, weighted
log-value loss, Adam schedule, and sample mixture from the first pilot.
Replace the endpoint override by the continuous log-value construction
L(x,y,tau) = exp(-tau)*log1p(terminal(x,y)) + (1-exp(-tau))*N(x,y,tau).
Return expm1(max(L,0)); do not upper-clip this new construction. It is continuous
at tau=0 and exactly matches the terminal cost. Nonnegative clipping may have
kinks elsewhere: this is not a derivative or smoothness certificate.

Train three initializations (43,44,45) on a shared fresh 40,000-point training
set (seed 1901), with shared 6,000-point validation (1902). Shuffle seeds are
1943,1944,1945. Sharing data isolates initialization/optimization variability;
this does not test uncertainty across training datasets. Use up to 200 epochs,
validation every five epochs, patience 40, same learning-rate schedule. Freeze
all three checkpoints before generating the 6,000-point final test (1903).
Evaluate the original frozen model on the same test for descriptive comparison.
No test-based model selection or retraining. Keep every failure.

Predeclared value screens for EACH new seed: >=95% within
.02+.05*abs(reference value) overall AND in the remaining-time [0,2) subgroup.
Report errors in [0,.1), [.1,.5), [.5,2), [2,10), [10,50] and near target.
Report exact terminal identity and convergence as tau approaches zero on
100 fixed state points. Check representative training gradients numerically.

For EACH new seed and the original model, evaluate high_x, target, saddle,
and mixed on 128 paired noisy paths per start, fresh seeds 20264000..20264003.
Reuse the same Brownian paths for all networks and the reference. Use original
61-action Bellman lookahead, dt=.1, simulation h=.025, sigma=.05, objective,
and outside-box zero-control fallback. 128 paths is a smaller exploratory
replication batch than the original pilot's 256; report uncertainty explicitly.
Each policy screen requires the upper approximate paired 95% interval for
new-minus-reference cost <= .01+.05*reference mean cost. Also report paired
new-minus-original cost without declaring equivalence or superiority based on
unadjusted multiple comparisons. No seed selected for deployment.

Stage success requires all three seeds to pass both value screens and all
twelve policy screens. Completion of the experiment is distinct from success.
Record runtime, fallback counts, raw predictions/costs, hashes, and limitations.
Preserve prior artifacts. No biology, continuous optimality, derivative accuracy,
speedup, or physics-informed-training claim is established by this experiment.
