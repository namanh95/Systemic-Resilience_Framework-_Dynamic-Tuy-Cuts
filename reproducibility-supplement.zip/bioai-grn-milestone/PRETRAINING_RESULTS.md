# Stochastic reference assessment before neural training

2 November 2026

## Decision

The nominal sigma=.05 reference passes the declared empirical checks and the additional sampled-value audit. It is suitable for a LIMITED numerical neural-approximation pilot, with independent policy simulation and comparison against these reference tolerances.

No neural training was performed. Passing here does not certify a continuous optimal policy, value derivatives, uniform convergence, or biological validity. The scope is the specified synthetic-noise model, finite horizon, tested states/times, and selected costs.

## Protocol and computational checks

PRETRAINING_PROTOCOL.md was written before the new results. For six existing initial states, a numerical change passes if it is at most .005+.01*abs(refined value). Value/Monte Carlo agreement is screened separately using .005+.01*abs(MC mean) +1.96*MC standard error. These are practical acceptance criteria, not error theorems.

A precomputed sparse-interpolation stencil accelerates the existing Bellman update without changing its method. Three full-history comparisons against the original solver give maximum difference below 2.2e-14. Finite and nonnegative transition guards reject invalid numerical transitions. All production decision steps are .1 or .05.

All nominal refinements retain local_scale=.5, the 178-by-238 grid, domain 1.5, exit payoff 100, and the same biological coefficients and objective. Baseline: 31 controls, decision step .1, two quadrature nodes per noise coordinate. Each comparison changes one parameter. Higher-noise spatial checks use sigma=.10.

## Prespecified numerical value checks

| Check | Maximum value change | Maximum tolerance ratio | Result |
|---|---:|---:|---|
| time | 0.0019078 | 0.1468 | PASS |
| control | 0.0021437 | 0.2640 | PASS |
| quadrature | 0.0002081 | 0.0373 | PASS |
| higher_noise | 0.0036418 | 0.5071 | PASS |

Time halves the decision step to .05; control doubles intervals from 30 to 60 (61 candidates); quadrature uses three nodes per coordinate instead of two. Higher-noise compares local spacings (.0001,.005) with (.00005,.0025).

| Configuration | High-x value | Target value | Saddle value |
|---|---:|---:|---:|
| existing nominal | 2.5166131 | 0.0579422 | 0.1126098 |
| time | 2.5185209 | 0.0587625 | 0.1134344 |
| control | 2.5144693 | 0.0568332 | 0.1109970 |
| quadrature | 2.5166875 | 0.0577341 | 0.1124980 |
| higher_noise | 2.6608683 | 0.2180862 | 0.2662735 |
| higher_noise_coarser | 2.6639796 | 0.2217280 | 0.2696995 |

## Fresh Monte Carlo checks

Each new policy is evaluated from high-x, target, and saddle on 256 fresh Brownian paths per state, with seeds distinct from the previous stage. Common fine increments are used for paired comparisons. Integration uses .025 steps; the existing local reference is also replayed with .0125 steps. Confidence intervals cover sampling uncertainty only, not numerical or model error.

| Configuration | State | Grid value | MC mean | Approximate 95% MC interval | Agreement |
|---|---|---:|---:|---|---|
| baseline | high_x | 2.516613 | 2.512915 | [2.503964, 2.521865] | PASS |
| baseline | target | 0.057942 | 0.057924 | [0.054786, 0.061062] | PASS |
| baseline | saddle | 0.112610 | 0.112951 | [0.109591, 0.116310] | PASS |
| time | high_x | 2.518521 | 2.511705 | [2.502751, 2.520659] | PASS |
| time | target | 0.058762 | 0.057383 | [0.054228, 0.060539] | PASS |
| time | saddle | 0.113434 | 0.112276 | [0.108896, 0.115656] | PASS |
| control | high_x | 2.514469 | 2.510914 | [2.501953, 2.519874] | PASS |
| control | target | 0.056833 | 0.057016 | [0.053835, 0.060196] | PASS |
| control | saddle | 0.110997 | 0.111277 | [0.107876, 0.114677] | PASS |
| quadrature | high_x | 2.516687 | 2.512852 | [2.503888, 2.521816] | PASS |
| quadrature | target | 0.057734 | 0.057904 | [0.054742, 0.061066] | PASS |
| quadrature | saddle | 0.112498 | 0.113008 | [0.109593, 0.116422] | PASS |
| higher_noise | high_x | 2.660868 | 2.654326 | [2.633990, 2.674662] | PASS |
| higher_noise | target | 0.218086 | 0.220973 | [0.208664, 0.233283] | PASS |
| higher_noise | saddle | 0.266273 | 0.270521 | [0.257389, 0.283653] | PASS |

The acceptance tolerance includes an explicit numerical allowance; PASS does not mean the grid value lies inside the Monte Carlo interval. The MC cost belongs to the implemented policy, not the unknown optimal policy.

### Paired policy-cost changes from the existing nominal reference

| Refinement | State | Mean cost difference | Approximate paired 95% interval |
|---|---|---:|---|
| time | high_x | -0.0012102 | [-0.0013223, -0.0010982] |
| time | target | -0.0005410 | [-0.0006674, -0.0004146] |
| time | saddle | -0.0006743 | [-0.0008083, -0.0005403] |
| control | high_x | -0.0020011 | [-0.0021765, -0.0018256] |
| control | target | -0.0009088 | [-0.0010826, -0.0007351] |
| control | saddle | -0.0016740 | [-0.0018456, -0.0015025] |
| quadrature | high_x | -0.0000631 | [-0.0001963, 0.0000701] |
| quadrature | target | -0.0000205 | [-0.0001482, 0.0001073] |
| quadrature | saddle | 0.0000570 | [-0.0000986, 0.0002125] |

These changes may be small but statistically detectable; do not equate numerical similarity with identical policies or treat small improvements as proof of global optimality.

### Coupled simulation-step check

| State | Mean fine-minus-coarse cost | Paired 95% interval |
|---|---:|---|
| high_x | -0.0000257 | [-0.0000920, 0.0000405] |
| target | -0.0000063 | [-0.0000259, 0.0000134] |
| saddle | -0.0000148 | [-0.0000494, 0.0000198] |

## Exploratory off-grid value audit

In addition to the protocol, compare 128 new states (64 spread over the unit square and 64 in the locally refined region) at times 0,10,25,40,49. Seed: 271828. This gives 640 value comparisons per numerical refinement. The .005+.01*abs(value) tolerance is reported descriptively; this was not a prespecified statistical test.

| Refinement | Maximum absolute difference | Maximum scaled difference | Exceedances |
|---|---:|---:|---:|
| time | 0.0084655 | 0.2565 | 0/640 |
| control | 0.0021716 | 0.2884 | 0/640 |
| quadrature | 0.0010461 | 0.0586 | 0/640 |

## Scope of the next learning experiment

If the nominal readiness criteria pass, use the 61-control nominal run as the candidate reference. Keep the other numerical resolutions as comparators. A first experiment should assess learned VALUE approximation and independently simulated policy performance. Do not assume that accurate values imply accurate gradients or that derivative labels have been validated.

The high-noise case has only a local spatial check and Monte Carlo agreement in this stage; it has not received the same time/control/quadrature suite. Full joint refinement (all three settings improved together), broader state/time coverage, derivative-error analysis, and stronger stochastic truncation guarantees remain outside the readiness claim. Existing certified Hamiltonian selection does not certify these PDE values.

No new clinical, experimental, or biological calibration evidence was introduced. All control and noise conclusions remain conditional on the stated mathematical model.

## Reproduction

Python and NumPy are required. The existing stochastic_local0p5_policy.npz is an input; regenerate it with stochastic_local.py if needed. Then run:

    python pretraining_validation.py test
    python pretraining_baseline.py
    python pretraining_validation.py time
    python pretraining_validation.py control
    python pretraining_validation.py quadrature
    python pretraining_validation.py higher_noise_coarser
    python pretraining_validation.py higher_noise
    python pretraining_assessment.py
    python write_pretraining_report.py

Large policy archives store complete value histories. Small .npy files contain paired path costs; JSON files contain parameters, means, intervals, and diagnostics. NEURAL_REFERENCE_MANIFEST.json records the readiness decision and candidate file hash. A passing decision supports a scoped empirical comparison, not a statement that any neural model has been trained or validated.
