"""Independent feasible open-loop comparison: bounded coordinate pattern search.

No value grid or value interpolation. Local optimization, not a lower bound.
"""
import json
import numpy as np
from refined_control import flow,ROOT,INITIAL,TARGET


def evaluate(schedules,dt=.1,segment=.5):
    schedules=np.atleast_2d(schedules)
    x=np.full(len(schedules),INITIAL[0]);y=np.full(len(schedules),INITIAL[1]);cost=np.zeros(len(schedules))
    for k in range(round(50/dt)):
        index=int((k*dt+1e-10)/segment)
        z=schedules[:,index] if index<schedules.shape[1] else np.zeros(len(schedules))
        x,y,c=flow(x,y,z,dt);cost+=c
    return cost+10*((x-TARGET[0])**2+(y-TARGET[1])**2)


def optimize(initial,max_iterations=120,segment=.5,dt=.1):
    schedule=np.array(initial);value=float(evaluate(schedule,dt,segment)[0]);history=[]
    step=1.; iterations=0
    while step>=.03125 and iterations<max_iterations:
        candidates=np.clip(np.concatenate([schedule[None,:]+step*np.eye(len(schedule)),
                                          schedule[None,:]-step*np.eye(len(schedule))]),0,10)
        costs=evaluate(candidates,dt,segment);j=int(np.argmin(costs))
        if costs[j]<value-1e-10:
            schedule=candidates[j];value=float(costs[j])
        else:
            step/=2
        iterations+=1;history.append(value)
    return schedule,dict(iterations=iterations,final_pattern_step=step,cost=value,history=history)


def main():
    # Fixed half-unit segments on [0,8); zero afterward. Start from prior feedback
    # and from the independent preset pulse to expose dependence on initialization.
    prior=np.loadtxt(ROOT/'n101_u41_dt0.05_trajectory.csv',delimiter=',',skiprows=1) if (ROOT/'n101_u41_dt0.05_trajectory.csv').exists() else np.loadtxt(ROOT/'n71_u41_dt0.05_trajectory.csv',delimiter=',',skiprows=1)
    seed=np.array([np.mean(prior[(prior[:,0]>=j*.5)&(prior[:,0]<(j+1)*.5),3]) for j in range(16)])
    results=[]
    for label,initial in [('prior_feedback',seed),('preset_pulse',np.r_[np.full(10,10.),np.zeros(6)])]:
        schedule,result=optimize(initial)
        fine=float(evaluate(schedule,.05)[0]);finer=float(evaluate(schedule,.025)[0])
        assert abs(fine-finer)<1e-4
        result.update(seed=label,schedule=schedule.tolist(),cost_dt005=fine,cost_dt0025=finer)
        results.append(result)
        (ROOT/'direct_shooting_results.json').write_text(json.dumps(results,indent=2))
        print(json.dumps({k:v for k,v in result.items() if k!='history'}),flush=True)


if __name__=='__main__':
    main()
