"""RK4-characteristic DP, equilibrium-aligned grid, Bellman-greedy rollout.

Numerical reference only. No continuous optimality certification is asserted.
"""
import json
import time
from pathlib import Path
import numpy as np
from reference_control import ROOT, TARGET, INITIAL, interp, interp_setup, A1,A2,ETA
from toggle_benchmark import equilibria


def flow(x,y,z,h):
    def rhs(x,y):
        return 1/(1+(A2*y)**2.5)-x, 1/(1+A1*x/(1+z)**ETA)-y
    a,b=rhs(x,y)
    c,d=rhs(x+h*a/2,y+h*b/2)
    e,f=rhs(x+h*c/2,y+h*d/2)
    g,j=rhs(x+h*e,y+h*f)
    nx=x+h*(a+2*c+2*e+g)/6
    ny=y+h*(b+2*d+2*f+j)/6
    # RK4 applied to the running-cost accumulator using the same stage states.
    def cost(x,y):
        return (x-TARGET[0])**2+(y-TARGET[1])**2+.01*z*z
    integral=h*(cost(x,y)+2*cost(x+h*a/2,y+h*b/2)+
                2*cost(x+h*c/2,y+h*d/2)+cost(x+h*e,y+h*f))/6
    return nx,ny,integral


def make_grid(n,aligned=True):
    grid=np.linspace(0,1,n)**2
    if aligned:
        # Include both coordinates of all equilibria; target/initial cannot then
        # accumulate artificial interpolation errors simply by staying still.
        anchors=np.array([e['state'] for e in equilibria()])/np.array([A1,A2])
        grid=np.unique(np.concatenate([grid,anchors.ravel()]))
    return grid


def run(n=71,nu=41,dt=.1,aligned=True):
    started=time.perf_counter()
    grid=make_grid(n,aligned); controls=np.linspace(0,10,nu)
    steps=round(50/dt);m=len(grid)
    x,y=np.meshgrid(grid,grid,indexing='ij')
    nx,ny,cost=flow(x[None,:,:],y[None,:,:],controls[:,None,None],dt)
    weights=interp_setup(grid,nx,ny)
    values=np.empty((steps+1,m,m),dtype=np.float64)
    values[-1]=10*((x-TARGET[0])**2+(y-TARGET[1])**2)
    for k in range(steps-1,-1,-1):
        values[k]=np.min(cost+interp(values[k+1],weights),axis=0)
    initial_value=float(interp(values[0],interp_setup(grid,*INITIAL)))
    # Select controls by minimizing the actual off-grid Bellman expression,
    # rather than interpolating argmin indices across discontinuous policies.
    state=INITIAL.copy(); total=0.;dose=0.;rows=[]
    for k in range(steps):
        nx,ny,c=flow(*state,controls,dt)
        q=c+interp(values[k+1],interp_setup(grid,nx,ny))
        z=float(controls[np.argmin(q)])
        # Roll out with two half-steps, independently of the DP full-step flow.
        for _ in range(2):
            sx,sy,inc=flow(*state,z,dt/2)
            state=np.array([sx,sy]);total+=float(inc)
        dose+=dt*z*z
        rows.append(((k+1)*dt,*state,z))
    total+=10*np.sum((state-TARGET)**2)
    name=f'rk4_n{n}_u{nu}_dt{dt}_aligned{int(aligned)}'
    np.savetxt(ROOT/(name+'.csv'),rows,delimiter=',',header='end_time,normalized_x,normalized_y,control',comments='')
    # Only retain V0; full value history is reproducibly regenerated, not archived.
    np.savez_compressed(ROOT/(name+'.npz'),grid=grid,value0=values[0],controls=controls,dt=dt)
    result=dict(name=name,grid_points=m,base_n=n,controls=nu,dt=dt,aligned=aligned,
                initial_value=initial_value,rollout_cost=float(total),
                value_rollout_difference=float(initial_value-total),
                integral_z_squared=float(dose),final_normalized_state=state.tolist(),
                target_distance=float(np.linalg.norm(state-TARGET)),seconds=time.perf_counter()-started)
    return result


def tests():
    # Equilibria must remain stationary under zero control, including target cost.
    for e in equilibria():
        state=np.array(e['state'])/np.array([A1,A2])
        x,y,c=flow(*state,0,.1)
        assert np.max(np.abs(np.array([x,y])-state))<1e-13
    assert abs(flow(*TARGET,0,.1)[2])<1e-25
    for h in [.1,.05]:
        x,y=np.meshgrid(np.linspace(0,1,31),np.linspace(0,1,31),indexing='ij')
        a,b,c=flow(x[None],y[None],np.linspace(0,10,21)[:,None,None],h)
        assert a.min()>=0 and b.min()>=0 and a.max()<=1 and b.max()<=1
        assert c.min()>=0
    # Bilinear interpolation must reproduce an affine function exactly.
    grid=make_grid(21);x,y=np.meshgrid(grid,grid,indexing='ij')
    assert abs(float(interp(2*x+3*y,interp_setup(grid,.13,.47)))-1.67)<1e-12


def main():
    tests()
    # Predeclared diagnostic gate, not a theorem: <=1% relative changes in V0
    # and rollout cost on separate refinements; <=1% value/rollout discrepancy.
    results=[]
    for config in [(71,41,.1,False),(71,41,.1,True),(101,41,.1,True),
                   (141,41,.1,True),(101,81,.1,True),(101,41,.05,True)]:
        result=run(*config);results.append(result)
        (ROOT/'improved_reference_results.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
