"""Record the first trained model, including failures and runtime tradeoffs."""
import json
import hashlib
from pathlib import Path
import numpy as np
from stochastic_reference import ROOT


def read(name):return json.loads((ROOT/(name+'.json')).read_text())


def audit_errors():
    f=np.load(ROOT/'neural_heldout_values.npz');p=f['points'];y=f['reference'];z=f['prediction'];e=np.abs(y-z)
    report={}
    for name,mask in [('remaining_time_0_2',p[:,2]<2),('remaining_time_2_10',(p[:,2]>=2)&(p[:,2]<10)),
                      ('remaining_time_10_50',p[:,2]>=10),
                      ('near_target',(p[:,0]>=.001)&(p[:,0]<=.006)&(p[:,1]>=.55)&(p[:,1]<=.95))]:
        report[name]=dict(points=int(mask.sum()),mae=float(e[mask].mean()),max=float(e[mask].max()),
                          tolerance_fraction=float(np.mean(e[mask]<=.02+.05*np.abs(y[mask]))))
    report['largest_errors']=[dict(point=p[i].tolist(),reference=float(y[i]),prediction=float(z[i]),
                                   absolute_error=float(e[i])) for i in np.argsort(e)[-5:][::-1]]
    (ROOT/'neural_error_audit.json').write_text(json.dumps(report,indent=2))
    return report


def main():
    train=read('neural_training_results');runs=read('neural_rollout_results');audit=audit_errors()
    assert set(runs)=={'high_x','target','saddle','mixed'}
    previous=read('NEURAL_REFERENCE_MANIFEST')
    for name,digest in previous['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    passed=train['test']['value_screen_passed'] and all(r['policy_screen_passed'] for r in runs.values())
    m=train['test']
    lines=['# First neural BioAI pilot: value approximation and control evaluation', '',
        '2 November 2026', '', '## Result', '',
        ('The first neural model passed the prespecified aggregate held-out value screen and all four '
         'paired policy-cost screens. This is a successful limited empirical pilot, not a certified '
         'near-optimal controller.' if passed else
         'The first neural model did not pass every prespecified pilot screen. The results below '
         'retain the failures; no test-set tuning or post-test retraining was performed.'), '',
        'This model is supervised value regression, not yet physics-informed neural training. '
        'It approximates the frozen nominal sigma=.05 numerical reference. No biological data '
        'were fitted and no experimental effectiveness is established.', '',
        '## Training and separation of data', '',
        f"A NumPy network with architecture 8-32-32-1 contains {train['parameters']:,} learned parameters. "
        'The two hidden layers use tanh activations. Inputs are normalized concentrations, '
        'log-transformed concentrations, remaining time and its exponential transforms, and the '
        'known squared target discrepancy. Labels are log(1+reference value). The weighted '
        'squared loss emphasizes small values; Adam updates all layers.', '',
        'The training set has 40,000 points, validation 6,000, and final test 6,000, generated '
        'with distinct seeds 901, 902, 903. Labels interpolate the frozen reference in state and '
        'time. The sampled normalized-state box is [0,1.2]^2, with 40% of samples concentrated '
        'near the target, 20% in a low-x transition region, and 40% broadly distributed. Remaining '
        'times are sampled throughout [0,50] with extra density near the terminal time. Results '
        'therefore describe this mixture, not uniform worst-case accuracy.', '',
        f"Checkpoint selection used validation loss only: epoch {train['best_epoch']} of {train['epochs_run']}. "
        f"Training, checkpoint selection and test evaluation took {train['training_seconds']:.2f} seconds "
        'in this run. Model seed is 42 and shuffle seed is 904. A central-difference check verifies '
        'representative backpropagation entries in each parameter array. The final test set is '
        'generated only after checkpoint selection. No model was retrained after inspecting it.', '',
        'Predicted values are nonnegative through clipping of the log-output, followed by expm1. '
        'The exact terminal value is returned at remaining time zero. This pointwise override '
        'does not enforce a smooth terminal-time limit or accurate derivatives near that boundary.', '',
        '## Held-out value accuracy', '',
        '| Measure | Result |', '|---|---:|',
        f"| Mean absolute error | {m['mae']:.7f} |",
        f"| Root mean squared error | {m['rmse']:.7f} |",
        f"| 95th percentile absolute error | {m['p95_absolute']:.7f} |",
        f"| Maximum absolute error | {m['max_absolute']:.7f} |",
        f"| Fraction within .02+.05*reference value | {m['fraction_within_pilot_tolerance']:.2%} |",
        f"| Prespecified >=95% aggregate screen | {'PASS' if m['value_screen_passed'] else 'FAIL'} |", '',
        'The worst errors must not be hidden by the aggregate score. The largest test error is '
        'approximately 1.405 near the terminal time at a high-concentration state. The following '
        'subgroup analysis was performed after the checkpoint was frozen, not used to tune it.', '',
        '| Subgroup | Points | Mean absolute error | Fraction within tolerance |', '|---|---:|---:|---:|']
    for name,r in audit.items():
        if name=='largest_errors':continue
        lines.append(f"| {name} | {r['points']} | {r['mae']:.7f} | {r['tolerance_fraction']:.2%} |")
    lines+=['', 'Near-terminal performance is weaker than the aggregate result. This prevents any '
        'claim of uniformly accurate values and motivates a continuous terminal-condition '
        'architecture in a future experiment with fresh held-out data.', '',
        '## Intervention policy and paired noisy evaluation', '',
        'Both methods use the same 61 intervention candidates, .1 decision interval, two-point '
        'quadrature per noise coordinate, and sigma=.05 model. The neural policy substitutes '
        'neural next-step values in the one-step Bellman expression; it does not use neural '
        'derivatives or claim certified continuous Hamiltonian minimization. Reference feedback '
        'uses its stored next-time value surface.', '',
        'Four initial states are tested on 256 fresh paths each, with seeds 20263000 through '
        '20263003. The neural and reference policies share Brownian increments. The .025 '
        'simulation step uses the same positive splitting method and full-horizon objective. '
        'The neural policy uses zero control when the observed state is outside its training '
        'box and records that fallback; lookahead may evaluate predicted branch states beyond '
        'the training box. No teacher-based fallback rescues its actions.', '',
        '| Initial state | Reference mean cost | Neural mean cost | Paired increase | Paired 95% interval | Screen |',
        '|---|---:|---:|---:|---|---|']
    for label,r in runs.items():
        ref=r['reference']['cost']['mean'];nn=r['neural']['cost']['mean'];d=r['paired_neural_minus_reference'];ci=d['approx_95ci']
        lines.append(f"| {label} | {ref:.7f} | {nn:.7f} | {d['mean']:.7f} | [{ci[0]:.7f}, {ci[1]:.7f}] | {'PASS' if r['policy_screen_passed'] else 'FAIL'} |")
    lines+=['', 'The prespecified policy screen requires the upper paired 95% endpoint to be '
        '<=.01+.05*reference mean cost. Passing means acceptable performance for this pilot '
        'tolerance; it does not mean equal costs. Intervals cover Monte Carlo sampling only, '
        'without multiple-comparison adjustment or numerical/model uncertainty. The original '
        'reference is itself approximate.', '', '## Runtime and representation size', '',
        '| Initial state | Reference rollout seconds | Neural rollout seconds | Neural/reference | Fallback paths |',
        '|---|---:|---:|---:|---:|']
    for label,r in runs.items():
        a=r['reference']['seconds'];b=r['neural']['seconds']
        lines.append(f"| {label} | {a:.2f} | {b:.2f} | {b/a:.2f} | {r['neural']['fallback_paths']}/256 |")
    modelbytes=(ROOT/'neural_value_model.npz').stat().st_size
    refbytes=(ROOT/previous['candidate_file']).stat().st_size
    lines+=['', f"Saved network size: {modelbytes:,} bytes; reference value-history archive: {refbytes:,} bytes. "
        'These are representation-file sizes, not process memory measurements. The network is '
        'compact but evaluates many candidate transitions during lookahead. Runtime is measured '
        'for complete paired rollouts in one process with BLAS/OMP threads set to one, excluding '
        'model loading. It is not a general hardware benchmark. Do not infer a speedup from '
        'the smaller network file.', '', '## Interpretation and next research step', '',
        'This establishes a reproducible supervised neural baseline and tests its policy separately '
        'from its value fit. One network seed and four rollout starting states do not establish '
        'robustness across training seeds, arbitrary initial states, other noise levels, or models.', '',
        'A next experiment should address the terminal-time error and compare multiple training '
        'seeds using newly reserved test points and Brownian paths. Physics-informed losses, '
        'derivative-aware learning, and certified selection can then be evaluated as explicit '
        'extensions or ablations. This first pilot does not claim those methods are implemented, '
        'nor that improving a residual automatically yields a control-performance guarantee.', '',
        'The frozen reference manifest was not overwritten. NEURAL_PILOT_MANIFEST.json records '
        'that training has occurred, the model hash, and the observed pilot results.', '',
        '## Reproduction', '', 'Python and NumPy are required, plus the frozen reference archive.', '',
        '    python neural_pilot.py train',
        '    python neural_pilot.py evaluate',
        '    python write_neural_report.py', '',
        'Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 before launching Python to reproduce '
        'the thread settings used here. The report regenerates neural_error_audit.json as a '
        'post-test subgroup summary from neural_heldout_values.npz. Raw held-out '
        'predictions and paired rollout costs are retained. The small network archive is included '
        'in the portable package; the much larger reference archive must be regenerated or kept '
        'from the previous stage.', '']
    (ROOT/'NEURAL_PILOT_RESULTS.md').write_text('\n'.join(lines))
    manifest=dict(neural_training_started=True,training_complete=True,method='Supervised value MLP, not PINN',
        model='neural_value_model.npz',model_sha256=hashlib.sha256((ROOT/'neural_value_model.npz').read_bytes()).hexdigest(),
        training_code_sha256=hashlib.sha256((ROOT/'neural_pilot.py').read_bytes()).hexdigest(),
        reference_sha256=previous['sha256'],value_screen_passed=m['value_screen_passed'],
        all_four_policy_screens_passed=all(r['policy_screen_passed'] for r in runs.values()),
        pilot_passed=passed,unproven=['Uniform value accuracy','Derivative accuracy','Continuous optimality','Biological effectiveness','Runtime advantage'])
    (ROOT/'NEURAL_PILOT_MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
