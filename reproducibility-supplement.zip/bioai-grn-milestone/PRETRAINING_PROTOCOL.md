# Stochastic reference checks before neural training

Protocol set on 2 November 2026, before the new refinement results.

No neural model will be trained in this stage. Compare the saved sigma=.05,
local_scale=.5 reference with isolated time-step (.1 to .05), control count
(31 to 61), and quadrature order (2 to 3 per noise coordinate) refinements.
Keep all other parameters fixed. Also build sigma=.10 local_scale=1 and .5
references to assess spatial sensitivity at the higher noise level.

For each of the six established initial states, screen numerical value changes
against .005 + .01*abs(refined value). This is a practical numerical tolerance,
not a rigorous error bound or an asymptotic convergence theorem. Failure at
any state prevents an unqualified readiness decision for that configuration.
Do not change these thresholds after seeing outcomes.

Evaluate new policies on 256 fresh paths from high-x, target, and saddle.
Reuse Brownian increments between numerical policies for paired comparisons.
Use mean +/-1.96 standard errors for approximate sampling intervals; these
do not include discretization or model uncertainty. Differences near threshold
will be described as unresolved rather than proof of equality.

Check value/Monte Carlo agreement separately: diagnostic acceptance is an
absolute discrepancy no larger than .005+.01*abs(MC mean)+1.96*MC standard error.
This is not a statistical test of optimality, and passing does not make the grid
value a certified bound. Retain all failures in the report.

A precomputed interpolation-stencil implementation may accelerate the same
Bellman update. Compare complete time-indexed values against the existing
implementation on small deterministic and stochastic test problems before use.

Readiness is scoped: passing checks permits a limited empirical neural comparison
for the tested model and states. It never licenses a guaranteed-policy or
biological-effectiveness claim. Missing joint refinement, derivative validation,
or broader state/time coverage must remain explicit.
