# Matched architecture comparison and near-terminal diagnosis

3 November 2026

Experiment complete. All-three-seed continuous-model accuracy criterion: **FAIL**.

All six models passed the overall and time<2 component screens but failed the targeted [.1,.5) screen. Original-model targeted tolerance fractions were 91.93–93.68%; continuous-model fractions were 86.78–91.90%. The continuous model had higher targeted mean absolute error in every matched pair. Thus this experiment does not support adopting terminal blending as a general accuracy improvement. These are findings for the specified data, seeds and training budget.

This comparison isolates the two existing value-network implementations under matched data and optimization settings. It does not establish improved closed-loop control. All six models and all failures are retained. No test-based tuning or model selection was performed.

## What was controlled

Each paired seed (53,54,55) uses identical initial parameter arrays, features, normalization, 40,000 training points, 6,000 validation points, minibatch orders, Adam settings and 200-epoch budget. Checkpoints are selected every five epochs by weighted log-value validation loss. Selected epochs can differ. The original and continuous constructions retain their existing output clipping rules; the comparison is between those complete implementations.

Training/validation seeds are 2901/2902; shuffle seeds 2953/2954/2955. All six checkpoints and validation diagnostics were hashed before test generation. The standard fresh test has 6,000 points (2903). The targeted test has 4,000 points (state seed 2904, time seed 2905), with the same state mixture but remaining time uniform in [.1,.5). Targeted results are not pooled with the standard mixture.

## Fresh held-out results

Each model must achieve >=95% within .02+.05*abs(reference value) overall, for remaining time <2 in the standard test, and in the targeted test.

| Model | Overall within tolerance | Time <2 within tolerance | Targeted .1–.5 within tolerance | All three criteria |
|---|---:|---:|---:|---|
| original_53 | 98.35% | 95.30% | 93.00% | FAIL |
| continuous_53 | 98.55% | 95.89% | 89.35% | FAIL |
| original_54 | 98.33% | 95.62% | 93.67% | FAIL |
| continuous_54 | 99.17% | 97.41% | 91.90% | FAIL |
| original_55 | 98.45% | 95.68% | 91.92% | FAIL |
| continuous_55 | 98.30% | 95.08% | 86.78% | FAIL |

| Model | Standard MAE | Targeted MAE | Targeted maximum error | Selected epoch | Training seconds |
|---|---:|---:|---:|---:|---:|
| original_53 | 0.010428 | 0.039677 | 1.064582 | 200 | 20.73 |
| continuous_53 | 0.011501 | 0.057855 | 2.139759 | 190 | 21.59 |
| original_54 | 0.011669 | 0.037288 | 1.337589 | 200 | 29.70 |
| continuous_54 | 0.009211 | 0.043355 | 1.714235 | 200 | 22.76 |
| original_55 | 0.012271 | 0.046591 | 1.738153 | 195 | 14.76 |
| continuous_55 | 0.011511 | 0.051081 | 2.238494 | 190 | 31.40 |

## Paired architecture differences

Negative absolute-error differences favor the continuous architecture. Intervals describe point-sampling variation conditional on each trained pair, not training or reference uncertainty. They are approximate and not adjusted for multiple comparisons. The same points are reused across seeds; three seeds are too few to establish general superiority.

| Seed | Test | Mean absolute-error difference (continuous − original) | Approximate 95% interval | Tolerance-fraction difference |
|---|---|---:|---|---:|
| 53 | standard | 0.001073 | [0.000163, 0.001983] | +0.20% |
| 53 | focus_ | 0.018178 | [0.014580, 0.021775] | -3.65% |
| 54 | standard | -0.002459 | [-0.003178, -0.001739] | +0.83% |
| 54 | focus_ | 0.006066 | [0.003736, 0.008397] | -1.77% |
| 55 | standard | -0.000760 | [-0.001565, 0.000045] | -0.15% |
| 55 | focus_ | 0.004490 | [0.002186, 0.006793] | -5.15% |

## Validation-only diagnosis

The following diagnostics were recorded before test generation. They were not used to change architectures, losses, training budgets or thresholds.

At zero remaining time, bilinear teacher interpolation differs from the analytic terminal cost: mean absolute difference 0.001030333, maximum 0.01229831 on the 6,000 validation states. This is a reference-label discrepancy, not neural error. Its terminal magnitude alone cannot explain errors at later times.

For the 2345 training samples in [.1,.5), the squared blend gate averages 0.0722 (range 0.0091–0.1548). In the algebraically equivalent residual-network loss this gate scales the squared residual. It changes sensitivity to raw network output near the boundary. It is a candidate optimization mechanism, not proof that reweighting would improve accuracy or control.

| Model | Validation time band | Points | MAE | Within tolerance | Share of total deployed log-loss |
|---|---|---:|---:|---:|---:|
| original_53 | time_0_0.1 | 80 | 0.106744 | 81.25% | 7.68% |
| original_53 | time_0.1_0.5 | 367 | 0.050523 | 94.01% | 14.06% |
| original_53 | time_0.5_2 | 1364 | 0.013270 | 96.70% | 42.95% |
| original_53 | time_0.1_0.5_low_x | 226 | 0.010833 | 96.02% | 9.82% |
| original_53 | time_0.1_0.5_high_x | 141 | 0.114141 | 90.78% | 4.24% |
| continuous_53 | time_0_0.1 | 80 | 0.053045 | 98.75% | 1.37% |
| continuous_53 | time_0.1_0.5 | 367 | 0.059359 | 92.10% | 22.43% |
| continuous_53 | time_0.5_2 | 1364 | 0.015711 | 97.36% | 44.82% |
| continuous_53 | time_0.1_0.5_low_x | 226 | 0.015679 | 93.36% | 16.21% |
| continuous_53 | time_0.1_0.5_high_x | 141 | 0.129372 | 90.07% | 6.22% |
| original_54 | time_0_0.1 | 80 | 0.098636 | 80.00% | 11.39% |
| original_54 | time_0.1_0.5 | 367 | 0.046353 | 93.46% | 13.96% |
| original_54 | time_0.5_2 | 1364 | 0.014308 | 96.99% | 40.56% |
| original_54 | time_0.1_0.5_low_x | 226 | 0.009643 | 96.46% | 7.81% |
| original_54 | time_0.1_0.5_high_x | 141 | 0.105194 | 88.65% | 6.14% |
| continuous_54 | time_0_0.1 | 80 | 0.032771 | 98.75% | 1.70% |
| continuous_54 | time_0.1_0.5 | 367 | 0.045694 | 94.01% | 25.29% |
| continuous_54 | time_0.5_2 | 1364 | 0.012621 | 98.31% | 45.61% |
| continuous_54 | time_0.1_0.5_low_x | 226 | 0.010817 | 95.13% | 18.05% |
| continuous_54 | time_0.1_0.5_high_x | 141 | 0.101595 | 92.20% | 7.25% |
| original_55 | time_0_0.1 | 80 | 0.110251 | 85.00% | 6.76% |
| original_55 | time_0.1_0.5 | 367 | 0.052817 | 93.19% | 16.49% |
| original_55 | time_0.5_2 | 1364 | 0.014883 | 97.29% | 40.28% |
| original_55 | time_0.1_0.5_low_x | 226 | 0.012423 | 96.02% | 10.49% |
| original_55 | time_0.1_0.5_high_x | 141 | 0.117563 | 88.65% | 6.00% |
| continuous_55 | time_0_0.1 | 80 | 0.036579 | 98.75% | 1.26% |
| continuous_55 | time_0.1_0.5 | 367 | 0.052365 | 88.56% | 22.98% |
| continuous_55 | time_0.5_2 | 1364 | 0.015518 | 96.33% | 42.78% |
| continuous_55 | time_0.1_0.5_low_x | 226 | 0.014627 | 89.38% | 17.25% |
| continuous_55 | time_0.1_0.5_high_x | 141 | 0.112853 | 87.23% | 5.73% |

Subgroups overlap; their loss shares must not be summed. Low/high x uses the normalized threshold .05. Deployed log-loss includes prediction clipping; checkpoint selection uses the unclipped log-output objective.

## Verification and limits

The general teacher evaluator matched the existing sampler to 1e-12. Representative finite-difference gradient checks passed for both constructions. Paired initial parameters and update counts were checked, and frozen model, data, diagnostic and protocol hashes were verified when writing this report. Original reference source files remain unchanged.

This is supervised regression against an approximate reference, not a PINN, a derivative certificate, biological validation, or a test of closed-loop policy improvement. No new control trajectories were run in this value-only milestone. Matching one dataset removes the earlier data mismatch, but does not assess variation across training datasets, different model widths, or other budgets.

The next candidate experiment should be chosen from training/validation evidence: test targeted near-terminal sampling or loss weighting as an explicit ablation while holding the architecture and sample budget fixed. Reserve fresh final tests and validate any resulting controller separately. This is a proposal, not a claim that either adjustment has been shown to work.

## Reproduction

With Python, NumPy and the frozen reference archive available, set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1, then run:

    python matched_architecture.py
    python write_matched_report.py

Raw training/validation points, validation predictions, held-out predictions, six model files, histories and hashes are in matched_architecture/. The portable package omits large teacher archives; retain the local reference or regenerate it using the earlier-stage scripts.
