"""Prespecified continuous-terminal architecture; retain every training seed."""
import argparse
import hashlib
import json
import time
import numpy as np
from neural_pilot import Network, features, samples, teacher, choose_neural
from stochastic_reference import ROOT, STATES, terminal, summary, simulate
from refined_control import flow

OUT = ROOT / 'terminal_multiseed'
SEEDS = (43, 44, 45)


class TerminalNetwork(Network):
    def predict(self, x, y, tau):
        x,y,tau=np.broadcast_arrays(x,y,tau)
        p=np.column_stack([x.ravel(),y.ravel(),tau.ravel()])
        raw,_=self.forward((features(p)-self.mean)/self.scale)
        gate=-np.expm1(-tau)
        logvalue=(1-gate)*np.log1p(terminal(x,y))+gate*raw.reshape(x.shape)
        return np.expm1(np.maximum(logvalue,0))


def write(name, data):
    (OUT/name).write_text(json.dumps(data,indent=2))


def check_gradient():
    net=TerminalNetwork(np.zeros(8),np.ones(8),43)
    rng=np.random.default_rng(1900)
    x=rng.normal(size=(9,8));tau=np.linspace(.0001,3,9)
    gate=-np.expm1(-tau);anchor=np.exp(-tau)*rng.uniform(0,2,9)
    target=rng.uniform(0,2,9);weight=1/(.1+target)
    _,grads=net.loss_gradient(x,(target-anchor)/gate,weight*gate**2)
    def direct():
        raw,_=net.forward(x)
        return np.mean(weight*(anchor+gate*raw-target)**2)
    errors=[]
    for p,g in zip(net.params,grads):
        ix=tuple(0 for _ in p.shape);old=p[ix];eps=1e-6
        p[ix]=old+eps;plus=direct();p[ix]=old-eps;minus=direct();p[ix]=old
        errors.append(float(abs((plus-minus)/(2*eps)-g[ix])))
    assert max(errors)<1e-6
    return errors


def metrics(points,reference,prediction):
    error=np.abs(prediction-reference)
    assert np.all(np.isfinite(prediction))
    def subset(mask):
        e=error[mask];y=reference[mask]
        return dict(n=int(mask.sum()),mae=float(e.mean()),rmse=float(np.sqrt(np.mean(e**2))),
                    max_absolute=float(e.max()),fraction=float(np.mean(e<=.02+.05*np.abs(y))))
    masks={'all':np.ones(len(points),bool),'terminal_0_2':points[:,2]<2}
    for a,b in [(0,.1),(.1,.5),(.5,2),(2,10),(10,50)]:
        masks[f'time_{a}_{b}']=(points[:,2]>=a)&(points[:,2]<b)
    masks['near_target']=(points[:,0]>=.001)&(points[:,0]<=.006)&(points[:,1]>=.55)&(points[:,1]<=.95)
    result={key:subset(mask) for key,mask in masks.items()}
    result['value_pass']=result['all']['fraction']>=.95 and result['terminal_0_2']['fraction']>=.95
    return result


def train():
    OUT.mkdir(exist_ok=True)
    checks=check_gradient();grid,u,values,p=teacher()
    tp,tv=samples(1901,40000,grid,values);vp,vv=samples(1902,6000,grid,values)
    f=features(tp);mean=f.mean(0);scale=np.maximum(f.std(0),1e-6)
    x=(f-mean)/scale;vx=(features(vp)-mean)/scale
    y=np.log1p(tv);vy=np.log1p(vv);weight=1/(.1+y);vw=1/(.1+vy)
    gate=-np.expm1(-tp[:,2]);anchor=np.exp(-tp[:,2])*np.log1p(terminal(*tp[:,:2].T))
    target=(y-anchor)/gate;weights=weight*gate**2
    vg=-np.expm1(-vp[:,2]);va=np.exp(-vp[:,2])*np.log1p(terminal(*vp[:,:2].T))
    records={}
    for seed in SEEDS:
        start=time.perf_counter();model=TerminalNetwork(mean,scale,seed)
        ms=[np.zeros_like(a) for a in model.params];vs=[np.zeros_like(a) for a in model.params]
        rng=np.random.default_rng(1900+seed);best=float('inf');best_epoch=0;step=0;history=[]
        for epoch in range(1,201):
            order=rng.permutation(len(x));lr=.001*(.4 if epoch>120 else 1)
            for begin in range(0,len(x),512):
                ix=order[begin:begin+512];_,grads=model.loss_gradient(x[ix],target[ix],weights[ix]);step+=1
                for k,(param,g) in enumerate(zip(model.params,grads)):
                    ms[k]=.9*ms[k]+.1*g;vs[k]=.999*vs[k]+.001*g*g
                    param-=lr*(ms[k]/(1-.9**step))/(np.sqrt(vs[k]/(1-.999**step))+1e-8)
            if epoch%5==0:
                raw,_=model.forward(vx);loss=float(np.mean(vw*(va+vg*raw-vy)**2))
                history.append(dict(epoch=epoch,validation_loss=loss))
                if loss<best:
                    best=loss;best_epoch=epoch;model.save(OUT/f'model_{seed}.npz')
                if epoch%40==0:print('seed',seed,'epoch',epoch,'validation',loss,flush=True)
                if epoch-best_epoch>=40:break
        records[str(seed)]=dict(best_epoch=best_epoch,epochs_run=epoch,validation_loss=best,
                              training_seconds=time.perf_counter()-start,history=history)
    # All checkpoints frozen before test generation.
    testp,testv=samples(1903,6000,grid,values)
    arrays=dict(points=testp,reference=testv)
    original=Network.load(ROOT/'neural_value_model.npz')
    arrays['original']=original.predict(*testp.T)
    results={'original':metrics(testp,testv,arrays['original'])}
    states=np.random.default_rng(1904).uniform(0,1.2,(100,2));boundary={}
    for seed in SEEDS:
        model=TerminalNetwork.load(OUT/f'model_{seed}.npz')
        arrays[f'seed_{seed}']=model.predict(*testp.T)
        results[str(seed)]=metrics(testp,testv,arrays[f'seed_{seed}'])
        exact=terminal(*states.T)
        errors={str(t):float(np.max(np.abs(model.predict(*states.T,t)-exact))) for t in [0,1e-2,1e-4,1e-6,1e-8]}
        assert errors['0']<1e-12 and errors['1e-08']<errors['0.0001']
        boundary[str(seed)]=errors
    np.savez_compressed(OUT/'heldout.npz',**arrays)
    write('training.json',dict(seeds=records,gradient_errors=checks,boundary=boundary,test=results))
    print(json.dumps(results),flush=True)


def rollout(model,u,p,initial,seed,paths=128):
    state=np.tile(initial,(paths,1));cost=np.zeros(paths);rng=np.random.default_rng(seed)
    fallback=np.zeros(paths,bool);start=time.perf_counter()
    for k in range(round(50/p['dt'])):
        z,outside=choose_neural(model,u,state,50-k*p['dt'],p);fallback|=outside
        for _ in range(4):
            x,y,ca=flow(state[:,0],state[:,1],z,.0125)
            normal=rng.standard_normal((1,paths,2)).sum(axis=0)
            fac=np.exp(-.5*p['sigma']**2*.025+p['sigma']*np.sqrt(.025)*normal)
            x,y,cb=flow(x*fac[:,0],y*fac[:,1],z,.0125)
            state=np.column_stack([x,y]);cost+=ca+cb
            assert np.all(np.isfinite(state)) and np.all(state>=0)
    cost+=terminal(*state.T)
    return dict(cost=summary(cost),fallback_paths=int(fallback.sum()),seconds=time.perf_counter()-start),cost


def evaluate():
    grid,u,v,p=teacher();results={}
    models={'original':Network.load(ROOT/'neural_value_model.npz')}
    models.update({str(s):TerminalNetwork.load(OUT/f'model_{s}.npz') for s in SEEDS})
    for i,label in enumerate(('high_x','target','saddle','mixed')):
        seed=20264000+i;start=time.perf_counter()
        ref,rc=simulate(grid,u,v,p,STATES[label],paths=128,seed=seed,h=.025)
        ref['seconds']=time.perf_counter()-start
        runs={};arrays={'reference':rc};limit=.01+.05*ref['cost']['mean']
        for name,model in models.items():
            r,c=rollout(model,u,p,STATES[label],seed);arrays[name]=c
            r['minus_reference']=summary(c-rc)
            r['policy_pass']=r['minus_reference']['approx_95ci'][1]<=limit
            if name!='original':r['minus_original']=summary(c-arrays['original'])
            runs[name]=r
            print(label,name,json.dumps(r),flush=True)
            results[label]=dict(reference=ref,models=runs,tolerance=limit,path_seed=seed)
            write('rollouts.json',results)
            np.savez_compressed(OUT/f'rollout_{label}.npz',**arrays)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['train','evaluate'])
    args=parser.parse_args()
    train() if args.mode=='train' else evaluate()
