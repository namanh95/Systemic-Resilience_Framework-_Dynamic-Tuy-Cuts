"""Summarize all prespecified seeds without selection or hidden failures."""
import hashlib
import json
import zipfile
from terminal_multiseed import OUT, ROOT, SEEDS


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    train=json.loads((OUT/'training.json').read_text())
    runs=json.loads((OUT/'rollouts.json').read_text())
    assert set(runs)=={'high_x','target','saddle','mixed'}
    for r in runs.values():assert set(r['models'])=={'original','43','44','45'}
    frozen=json.loads((ROOT/'NEURAL_REFERENCE_MANIFEST.json').read_text())
    for name,h in frozen['source_sha256'].items():assert digest(ROOT/name)==h
    prior=json.loads((ROOT/'NEURAL_PILOT_MANIFEST.json').read_text())
    assert digest(ROOT/'neural_value_model.npz')==prior['model_sha256']
    value_ok=all(train['test'][str(s)]['value_pass'] for s in SEEDS)
    policy_ok=all(r['models'][str(s)]['policy_pass'] for r in runs.values() for s in SEEDS)
    failed_values=[str(s) for s in SEEDS if not train['test'][str(s)]['value_pass']]
    failed_policies=[f'{label}/{s}' for label,r in runs.items() for s in SEEDS if not r['models'][str(s)]['policy_pass']]
    lines=['# Continuous terminal condition: three-seed replication','','3 November 2026','',
        f"Experiment complete. Prespecified overall stage outcome: **{'PASS' if value_ok and policy_ok else 'FAIL'}**.",
        f"All three value screens: {'PASS' if value_ok else 'FAIL'}. All twelve policy screens: {'PASS' if policy_ok else 'FAIL'}.",'',
        f"Failed value-screen seeds: {', '.join(failed_values) or 'none'}. Failed start/seed policy screens: {', '.join(failed_policies) or 'none'}.",'',
        'This is supervised regression against the same approximate numerical reference. It is not '
        'physics-informed training, a continuous optimality certificate, or biological validation. '
        'All three seeds are reported, with no test-driven retraining or best-seed selection.','',
        '## Construction and evaluation separation','',
        'The revised log-value blends the known terminal log-cost with the network output: '
        'L = exp(-tau) log(1+terminal) + (1-exp(-tau)) N. Prediction is expm1(max(L,0)). '
        'This construction continuously recovers the exact terminal value. Nonnegative clipping '
        'can introduce kinks; continuous terminal behavior does not prove derivative accuracy. '
        'The upper log-output clip used in the original model is removed.','',
        'All models use 1,377 learned parameters and the same original feature set. Three '
        'initializations (43,44,45) share fresh training/validation sets of 40,000/6,000 points '
        '(seeds 1901/1902). Shuffle seeds are 1943/1944/1945. All checkpoints were selected '
        'using validation loss before generating the 6,000-point test (1903). This isolates '
        'initialization/optimization variability, not variation across datasets. The original '
        'frozen model is reevaluated on the same new test. Because it used different training '
        'data, this comparison does not isolate architecture as the sole cause of differences.','',
        '## Held-out values','',
        'Each revised model must meet >=95% within .02+.05*abs(reference value), both overall '
        'and for remaining time below 2. Subgroups and thresholds were declared before training.','',
        '| Model | Overall MAE | Overall within tolerance | Time <2 MAE | Time <2 within tolerance | Screen |',
        '|---|---:|---:|---:|---:|---|']
    for name,m in train['test'].items():
        a=m['all'];b=m['terminal_0_2']
        lines.append(f"| {name} | {a['mae']:.6f} | {a['fraction']:.2%} | {b['mae']:.6f} | {b['fraction']:.2%} | {'PASS' if m['value_pass'] else 'FAIL'} |")
    lines+=['','The original model is assessed here against the new, stricter two-part screen '
            'for comparison; this does not retroactively change its original pilot result.','',
            'The closest-to-terminal [0,.1) subgroup contains only 75 points, so its improved '
            'tolerance fractions are descriptive, not evidence of uniform accuracy. The '
            '[.1,.5) subgroup remains weaker despite exact boundary matching.','',
            '| Model | Subgroup | Points | MAE | Maximum error | Within tolerance |',
            '|---|---|---:|---:|---:|---:|']
    for name,m in train['test'].items():
        for group,g in m.items():
            if group in ('all','terminal_0_2','value_pass'):continue
            lines.append(f"| {name} | {group} | {g['n']} | {g['mae']:.6f} | {g['max_absolute']:.6f} | {g['fraction']:.2%} |")
    lines+=['','## Training and terminal checks','',
            f"Maximum checked gradient discrepancy: {max(train['gradient_errors']):.3g}. Central differences "
            'check representative entries in every parameter array against the blended-output loss.', '',
            '| Seed | Selected epoch | Training seconds | Terminal error at zero | Error at tau=1e-8 |',
            '|---|---:|---:|---:|---:|']
    for seed,r in train['seeds'].items():
        b=train['boundary'][seed]
        lines.append(f"| {seed} | {r['best_epoch']} | {r['training_seconds']:.2f} | {b['0']:.3g} | {b['1e-08']:.3g} |")
    lines+=['','Terminal checks use 100 fixed states in [0,1.2]^2. Values at tau=0, '
            '1e-2,1e-4,1e-6,1e-8 are retained in training.json. Boundary matching is structural; '
            'accuracy away from that boundary remains empirical.','',
            '## Paired noisy control evaluation','',
            'Each start uses 128 fresh Brownian paths (seeds 20264000..20264003), shared across '
            'the reference, original model, and all three revised models. This is a smaller '
            'exploratory batch than the first pilot. The same 61 controls, .1 decision interval, '
            '.025 simulation step, sigma=.05, running/terminal costs and Bellman lookahead '
            'are used. Zero-control fallback applies outside the observed training box; '
            'lookahead branch states can still require extrapolation.','',
            '| Start | Model | Mean cost | Increase vs reference | Approximate paired 95% interval | Screen |',
            '|---|---|---:|---:|---|---|']
    for label,r in runs.items():
        lines.append(f"| {label} | reference | {r['reference']['cost']['mean']:.7f} | - | - | - |")
        for name,m in r['models'].items():
            d=m['minus_reference'];lo,hi=d['approx_95ci']
            lines.append(f"| {label} | {name} | {m['cost']['mean']:.7f} | {d['mean']:.7f} | [{lo:.7f}, {hi:.7f}] | {'PASS' if m['policy_pass'] else 'FAIL'} |")
    lines+=['','Each screen requires upper interval <= .01+.05*reference mean cost. Passing '
            'does not imply equal or improved performance. Intervals measure path sampling '
            'uncertainty only, are not adjusted for multiple comparisons, and exclude numerical '
            'reference/model error. Shared paths and data mean these tests are not independent '
            'replications of the biological system.','',
            '| Start | Seed | Paired difference vs original | Approximate 95% interval | Rollout seconds | Fallback paths |',
            '|---|---|---:|---|---:|---:|']
    for label,r in runs.items():
        for seed in SEEDS:
            m=r['models'][str(seed)];d=m['minus_original'];lo,hi=d['approx_95ci']
            lines.append(f"| {label} | {seed} | {d['mean']:.7f} | [{lo:.7f}, {hi:.7f}] | {m['seconds']:.2f} | {m['fallback_paths']}/128 |")
    lines+=['','Runtime is full rollout wall time with BLAS/OMP threads set to one, excluding '
            'loading. Original and reference runtimes are retained in rollouts.json. No speed '
            'advantage is assumed.','',
            '## Interpretation','',
            'The experiment separates architectural boundary matching, held-out value accuracy, '
            'and downstream control performance. The prespecified screen outcome above must '
            'be retained even if some metrics improve. Three seeds, one sampling mixture, four '
            'initial states and one noise level do not establish broad robustness. No biological '
            'data were fitted. Neural gradients and certified Hamiltonian selection remain untested.','',
            'A focused follow-up is to investigate the remaining-time .1 to .5 region using '
            'training/validation residuals, then compare the original and terminal-constrained '
            'architectures under matched training data and multiple initializations. The present '
            'comparison changes both architecture and training data, so it cannot isolate the '
            'architecture effect. Do not advance to a robustness claim by selecting only the '
            'seeds that passed this experiment.','',
            'Any follow-up tuning must use training/validation evidence and reserve new test '
            'points and paths. The results of this stage must not be reused as an untouched '
            'test set for a revised architecture.','',
            '## Reproduction and files','',
            'Run from the bioai-grn-milestone folder, with Python and NumPy plus the frozen '
            'pretraining_control_policy.npz reference archive available:', '',
            '    python terminal_multiseed.py train',
            '    python terminal_multiseed.py evaluate',
            '    python write_terminal_report.py','',
            'Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 first. The portable ZIP includes '
            'models, fresh held-out predictions, raw paired rollout costs, source, protocols '
            'and prior lightweight results. Large teacher archives are omitted and remain local.','']
    (ROOT/'TERMINAL_MULTISEED_RESULTS.md').write_text('\n'.join(lines))
    manifest=dict(experiment_complete=True,all_value_screens_passed=value_ok,
                  all_policy_screens_passed=policy_ok,stage_passed=value_ok and policy_ok,
                  reference_sha256=frozen['sha256'],original_model_sha256=prior['model_sha256'],
                  files={str(p.relative_to(ROOT)):digest(p) for p in sorted(OUT.glob('*')) if p.is_file()},
                  source_sha256={n:digest(ROOT/n) for n in ['terminal_multiseed.py','write_terminal_report.py','TERMINAL_MULTISEED_PROTOCOL.md']})
    writepath=ROOT/'TERMINAL_MULTISEED_MANIFEST.json'
    writepath.write_text(json.dumps(manifest,indent=2))
    package=ROOT.parent/'bioai-terminal-multiseed-package.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in [ROOT.parent/'bioai-baseline',ROOT]:
            for p in sorted(folder.rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.md','.json','.csv','.npy'} or (p.suffix=='.npz' and (p.name.startswith('neural_') or p.parent==OUT))):
                    z.write(p,p.relative_to(ROOT.parent))
        z.writestr('PACKAGE_README.md','Start at bioai-grn-milestone/TERMINAL_MULTISEED_RESULTS.md. Requires Python and NumPy. Large teacher archives are omitted; retain or regenerate the frozen reference before rerunning. Preserve sibling directory names. All seeds and failures are retained.\n')
    with zipfile.ZipFile(package) as z:assert z.testzip() is None
    print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
    print('Verified package:',package)


if __name__=='__main__':main()
