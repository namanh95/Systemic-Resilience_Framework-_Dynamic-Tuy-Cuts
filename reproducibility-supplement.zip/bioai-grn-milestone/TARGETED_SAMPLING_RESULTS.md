# Fixed-budget near-terminal sampling experiment

3 November 2026

Experiment complete. All-three-targeted-seed accuracy criterion: **PASS**.

Models missing one or more criteria: baseline_63, baseline_64, baseline_65.

Targeted-interval tolerance fractions changed from 87.35%–92.62% in baseline runs to 95.30%–97.67% in targeted runs.

This is not uniform accuracy: the separate time<.1 subgroup achieved only 77.08%–86.46% in targeted runs. That subgroup was audited but was not a separate prespecified acceptance criterion. Long-time (10–50) MAE increased in all three targeted runs; the time-band table preserves that tradeoff. Overall MAE did not improve consistently even though tolerance fractions improved.

This experiment changes training-time coverage while holding the original network, weighted log-value loss, total sample count and optimization budget fixed. It is a value-approximation experiment, not a new closed-loop control evaluation.

## Controlled comparison

Each matched pair uses the original 1,377-parameter network, shared initial weights (seeds 63,64,65), baseline-derived normalization, identical batch orders (2963,2964,2965), 40,000 training samples and 200 epochs. Training states are identical between arms. Only 10,000 randomly selected remaining times are replaced by uniform [.1,.5) draws in the targeted arm, and their reference labels recomputed. This shifts coverage away from other times; those errors are also reported.

Observed [.1,.5) training fractions: baseline 6.04%; targeted 29.56%.

Baseline training seed is 3901; replacement row/time seeds are 3906/3907. Both arms use the same 6,000-point standard-mixture validation set (3902) and checkpoint selection by weighted log-value loss every five epochs. No targeted validation objective or test-based checkpoint selection is used.

All six checkpoints, data and validation diagnostics were hashed before generating fresh final tests: 6,000 standard-mixture points (3903) and 4,000 targeted points (state/time seeds 3904/3905). Targeted tests retain the same state mixture but use times uniform in [.1,.5). The tests are reported separately, not pooled.

## Held-out accuracy

Each model must reach >=95% within .02+.05*abs(reference value) overall, in the standard test time<2 subgroup, and in the targeted test. Stage success requires every targeted-arm seed to pass all three components.

| Model | Overall | Time <2 | Targeted .1–.5 | All components |
|---|---:|---:|---:|---|
| baseline_63 | 98.25% | 94.77% | 92.62% | FAIL |
| targeted_63 | 98.80% | 96.86% | 97.67% | PASS |
| baseline_64 | 97.38% | 92.29% | 87.35% | FAIL |
| targeted_64 | 98.37% | 95.38% | 95.30% | PASS |
| baseline_65 | 97.65% | 92.96% | 89.72% | FAIL |
| targeted_65 | 98.37% | 95.71% | 96.08% | PASS |

| Model | Standard MAE | Targeted MAE | Targeted maximum error | Selected epoch | Training seconds |
|---|---:|---:|---:|---:|---:|
| baseline_63 | 0.011254 | 0.039599 | 1.925203 | 200 | 9.05 |
| targeted_63 | 0.011450 | 0.025134 | 0.929834 | 200 | 8.41 |
| baseline_64 | 0.012322 | 0.040873 | 2.320102 | 200 | 8.25 |
| targeted_64 | 0.011697 | 0.026790 | 1.613473 | 200 | 8.31 |
| baseline_65 | 0.012748 | 0.047341 | 1.723101 | 180 | 8.28 |
| targeted_65 | 0.012556 | 0.030573 | 2.274702 | 200 | 8.23 |

## Paired sampling effects

Negative error differences favor targeted sampling. Intervals describe approximate point-sampling uncertainty conditional on each trained pair; they exclude training-data, numerical-reference and model uncertainty. Shared test points make the seed comparisons dependent, and intervals are not multiplicity-adjusted.

| Seed | Test | MAE difference (targeted − baseline) | Approximate 95% interval | Tolerance-fraction difference |
|---|---|---:|---|---:|
| 63 | standard | 0.000196 | [-0.000508, 0.000899] | +0.55% |
| 63 | focus_ | -0.014465 | [-0.016577, -0.012353] | +5.05% |
| 64 | standard | -0.000625 | [-0.001241, -0.000008] | +0.98% |
| 64 | focus_ | -0.014083 | [-0.015869, -0.012297] | +7.95% |
| 65 | standard | -0.000193 | [-0.000890, 0.000504] | +0.72% |
| 65 | focus_ | -0.016768 | [-0.018942, -0.014594] | +6.35% |

## Time-band tradeoffs

| Model | Standard-test time band | Points | MAE | Within tolerance |
|---|---|---:|---:|---:|
| baseline_63 | time_0_0.1 | 96 | 0.093474 | 83.33% |
| baseline_63 | time_0.1_0.5 | 375 | 0.040086 | 91.73% |
| baseline_63 | time_0.5_2 | 1346 | 0.012911 | 96.43% |
| baseline_63 | time_2_10 | 1786 | 0.006987 | 99.50% |
| baseline_63 | time_10_50 | 2397 | 0.005700 | 99.96% |
| targeted_63 | time_0_0.1 | 96 | 0.082216 | 86.46% |
| targeted_63 | time_0.1_0.5 | 375 | 0.026962 | 98.67% |
| targeted_63 | time_0.5_2 | 1346 | 0.012962 | 97.10% |
| targeted_63 | time_2_10 | 1786 | 0.008806 | 99.27% |
| targeted_63 | time_10_50 | 2397 | 0.007310 | 99.92% |
| baseline_64 | time_0_0.1 | 96 | 0.104584 | 72.92% |
| baseline_64 | time_0.1_0.5 | 375 | 0.044378 | 89.33% |
| baseline_64 | time_0.5_2 | 1346 | 0.013720 | 94.50% |
| baseline_64 | time_2_10 | 1786 | 0.008173 | 99.22% |
| baseline_64 | time_10_50 | 2397 | 0.005918 | 99.87% |
| targeted_64 | time_0_0.1 | 96 | 0.079726 | 77.08% |
| targeted_64 | time_0.1_0.5 | 375 | 0.025344 | 96.27% |
| targeted_64 | time_0.5_2 | 1346 | 0.013533 | 96.43% |
| targeted_64 | time_2_10 | 1786 | 0.007724 | 99.50% |
| targeted_64 | time_10_50 | 2397 | 0.008768 | 99.79% |
| baseline_65 | time_0_0.1 | 96 | 0.092623 | 71.88% |
| baseline_65 | time_0.1_0.5 | 375 | 0.049144 | 89.60% |
| baseline_65 | time_0.5_2 | 1346 | 0.013595 | 95.39% |
| baseline_65 | time_2_10 | 1786 | 0.008442 | 99.50% |
| baseline_65 | time_10_50 | 2397 | 0.006589 | 99.83% |
| targeted_65 | time_0_0.1 | 96 | 0.079132 | 80.21% |
| targeted_65 | time_0.1_0.5 | 375 | 0.028464 | 97.07% |
| targeted_65 | time_0.5_2 | 1346 | 0.016729 | 96.43% |
| targeted_65 | time_2_10 | 1786 | 0.008173 | 99.38% |
| targeted_65 | time_10_50 | 2397 | 0.008323 | 99.62% |

## Verification and interpretation

Assertions verified unchanged training-state coordinates, unchanged non-replaced rows and labels, equal optimizer-update counts, model/data/validation/protocol hashes and unchanged frozen reference sources. The reused network gradient check passed. All models, validation predictions, held-out predictions, training histories and individual failures are retained.

The intervention changes the effective training distribution, including time-feature statistics, while normalization is deliberately fixed. No loss-weight or architecture change is included, so any observed difference belongs to this sampling intervention under these paired seeds and fixed settings. Three seeds on one dataset do not establish general robustness. Exact endpoint matching in the original network remains a pointwise override, not a continuous-boundary guarantee.

No newly trained model has been tested in closed-loop trajectories here. Earlier control results apply to earlier models only. Value-screen success would justify a separate fresh control evaluation, not a claim of improved intervention cost. If the stricter value screen fails, keep the failure and diagnose it using training/validation data before another prespecified ablation with fresh tests. No biological effectiveness, continuous optimality, derivative accuracy or runtime advantage is established.

## Reproduction

With Python/NumPy and the frozen reference archive, set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1, then run:

    python targeted_sampling.py
    python write_sampling_report.py

The portable package includes source, protocols, all models and raw evidence. Large teacher archives are omitted; retain the local reference or regenerate it using earlier-stage scripts. Preserve the two sibling source directories.
