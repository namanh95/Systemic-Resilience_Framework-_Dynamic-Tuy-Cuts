"""Coupled path integration and deterministic-policy comparisons."""
import json
import numpy as np
from stochastic_reference import ROOT,STATES,simulate,summary


def load(name):
    f=np.load(ROOT/('stochastic_'+name+'_policy.npz'))
    return f['grid'],f['controls'],f['values'],json.loads(str(f['parameters']))


def main():
    results={}
    det=load('deterministic')
    for name in ('noise005','noise010'):
        grid,u,v,p=load(name);runs={}
        for index,label in enumerate(('high_x','saddle')):
            initial=STATES[label];seed=20261200+index
            coarse,ca=simulate(grid,u,v,p,initial,paths=256,seed=seed,h=.025,coupling_h=.0125)
            fine,fa=simulate(grid,u,v,p,initial,paths=256,seed=seed,h=.0125,coupling_h=.0125)
            detrun,da=simulate(*det,initial,paths=256,seed=seed,h=.0125,coupling_h=.0125,simulation_sigma=p['sigma'])
            runs[label]=dict(coarse=coarse,fine=fine,
                             paired_fine_minus_coarse=summary(fa-ca),
                             deterministic_policy_under_noise=detrun,
                             paired_stochastic_minus_deterministic=summary(fa-da))
        results[name]=runs
        (ROOT/'stochastic_coupled_checks.json').write_text(json.dumps(results,indent=2))
        print(json.dumps({name:{s:{k:v for k,v in a.items() if k.startswith('paired')} for s,a in runs.items()}}),flush=True)


if __name__=='__main__':
    main()
