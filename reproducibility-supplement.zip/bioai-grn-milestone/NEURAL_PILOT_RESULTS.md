# First neural BioAI pilot: value approximation and control evaluation

2 November 2026

## Result

The first neural model passed the prespecified aggregate held-out value screen and all four paired policy-cost screens. This is a successful limited empirical pilot, not a certified near-optimal controller.

This model is supervised value regression, not yet physics-informed neural training. It approximates the frozen nominal sigma=.05 numerical reference. No biological data were fitted and no experimental effectiveness is established.

## Training and separation of data

A NumPy network with architecture 8-32-32-1 contains 1,377 learned parameters. The two hidden layers use tanh activations. Inputs are normalized concentrations, log-transformed concentrations, remaining time and its exponential transforms, and the known squared target discrepancy. Labels are log(1+reference value). The weighted squared loss emphasizes small values; Adam updates all layers.

The training set has 40,000 points, validation 6,000, and final test 6,000, generated with distinct seeds 901, 902, 903. Labels interpolate the frozen reference in state and time. The sampled normalized-state box is [0,1.2]^2, with 40% of samples concentrated near the target, 20% in a low-x transition region, and 40% broadly distributed. Remaining times are sampled throughout [0,50] with extra density near the terminal time. Results therefore describe this mixture, not uniform worst-case accuracy.

Checkpoint selection used validation loss only: epoch 190 of 200. Training, checkpoint selection and test evaluation took 29.45 seconds in this run. Model seed is 42 and shuffle seed is 904. A central-difference check verifies representative backpropagation entries in each parameter array. The final test set is generated only after checkpoint selection. No model was retrained after inspecting it.

Predicted values are nonnegative through clipping of the log-output, followed by expm1. The exact terminal value is returned at remaining time zero. This pointwise override does not enforce a smooth terminal-time limit or accurate derivatives near that boundary.

## Held-out value accuracy

| Measure | Result |
|---|---:|
| Mean absolute error | 0.0136540 |
| Root mean squared error | 0.0512646 |
| 95th percentile absolute error | 0.0404291 |
| Maximum absolute error | 1.4051315 |
| Fraction within .02+.05*reference value | 97.67% |
| Prespecified >=95% aggregate screen | PASS |

The worst errors must not be hidden by the aggregate score. The largest test error is approximately 1.405 near the terminal time at a high-concentration state. The following subgroup analysis was performed after the checkpoint was frozen, not used to tune it.

| Subgroup | Points | Mean absolute error | Fraction within tolerance |
|---|---:|---:|---:|
| remaining_time_0_2 | 1718 | 0.0303327 | 92.49% |
| remaining_time_2_10 | 1866 | 0.0069181 | 99.62% |
| remaining_time_10_50 | 2416 | 0.0069965 | 99.83% |
| near_target | 2412 | 0.0052258 | 96.56% |

Near-terminal performance is weaker than the aggregate result. This prevents any claim of uniformly accurate values and motivates a continuous terminal-condition architecture in a future experiment with fresh held-out data.

## Intervention policy and paired noisy evaluation

Both methods use the same 61 intervention candidates, .1 decision interval, two-point quadrature per noise coordinate, and sigma=.05 model. The neural policy substitutes neural next-step values in the one-step Bellman expression; it does not use neural derivatives or claim certified continuous Hamiltonian minimization. Reference feedback uses its stored next-time value surface.

Four initial states are tested on 256 fresh paths each, with seeds 20263000 through 20263003. The neural and reference policies share Brownian increments. The .025 simulation step uses the same positive splitting method and full-horizon objective. The neural policy uses zero control when the observed state is outside its training box and records that fallback; lookahead may evaluate predicted branch states beyond the training box. No teacher-based fallback rescues its actions.

| Initial state | Reference mean cost | Neural mean cost | Paired increase | Paired 95% interval | Screen |
|---|---:|---:|---:|---|---|
| high_x | 2.5076392 | 2.5147686 | 0.0071295 | [0.0065244, 0.0077345] | PASS |
| target | 0.0549880 | 0.0574205 | 0.0024325 | [0.0019034, 0.0029617] | PASS |
| saddle | 0.1080782 | 0.1104736 | 0.0023954 | [0.0018276, 0.0029632] | PASS |
| mixed | 0.6454738 | 0.6490335 | 0.0035597 | [0.0030178, 0.0041015] | PASS |

The prespecified policy screen requires the upper paired 95% endpoint to be <=.01+.05*reference mean cost. Passing means acceptable performance for this pilot tolerance; it does not mean equal costs. Intervals cover Monte Carlo sampling only, without multiple-comparison adjustment or numerical/model uncertainty. The original reference is itself approximate.

## Runtime and representation size

| Initial state | Reference rollout seconds | Neural rollout seconds | Neural/reference | Fallback paths |
|---|---:|---:|---:|---:|
| high_x | 16.71 | 109.72 | 6.57 | 0/256 |
| target | 16.68 | 104.91 | 6.29 | 0/256 |
| saddle | 14.64 | 104.53 | 7.14 | 0/256 |
| mixed | 16.85 | 116.49 | 6.91 | 0/256 |

Saved network size: 13,064 bytes; reference value-history archive: 156,568,299 bytes. These are representation-file sizes, not process memory measurements. The network is compact but evaluates many candidate transitions during lookahead. Runtime is measured for complete paired rollouts in one process with BLAS/OMP threads set to one, excluding model loading. It is not a general hardware benchmark. Do not infer a speedup from the smaller network file.

## Interpretation and next research step

This establishes a reproducible supervised neural baseline and tests its policy separately from its value fit. One network seed and four rollout starting states do not establish robustness across training seeds, arbitrary initial states, other noise levels, or models.

A next experiment should address the terminal-time error and compare multiple training seeds using newly reserved test points and Brownian paths. Physics-informed losses, derivative-aware learning, and certified selection can then be evaluated as explicit extensions or ablations. This first pilot does not claim those methods are implemented, nor that improving a residual automatically yields a control-performance guarantee.

The frozen reference manifest was not overwritten. NEURAL_PILOT_MANIFEST.json records that training has occurred, the model hash, and the observed pilot results.

## Reproduction

Python and NumPy are required, plus the frozen reference archive.

    python neural_pilot.py train
    python neural_pilot.py evaluate
    python write_neural_report.py

Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 before launching Python to reproduce the thread settings used here. The report regenerates neural_error_audit.json as a post-test subgroup summary from neural_heldout_values.npz. Raw held-out predictions and paired rollout costs are retained. The small network archive is included in the portable package; the much larger reference archive must be regenerated or kept from the previous stage.
