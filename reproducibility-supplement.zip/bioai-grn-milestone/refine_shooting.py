import json
import numpy as np
from direct_shooting import ROOT,optimize,evaluate


if __name__=='__main__':
    old=json.loads((ROOT/'direct_shooting_results.json').read_text())
    seed=np.repeat(min(old,key=lambda r:r['cost_dt0025'])['schedule'],2)
    # .05 divides the .25 control segment exactly; do not cross control jumps.
    schedule,result=optimize(seed,max_iterations=100,segment=.25,dt=.05)
    result.update(segment=.25,dt=.05,schedule=schedule.tolist(),
                  cost_dt0025=float(evaluate(schedule,.025,.25)[0]),
                  cost_dt00125=float(evaluate(schedule,.0125,.25)[0]))
    assert abs(result['cost_dt0025']-result['cost_dt00125'])<1e-5
    (ROOT/'refined_shooting_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ('schedule','history')}),flush=True)
