"""Matched-data paired architecture experiment; no test-driven tuning."""
import hashlib
import json
import time
import numpy as np
from neural_pilot import Network, features, samples, teacher, gradient_test
from terminal_multiseed import TerminalNetwork, check_gradient
from stochastic_reference import ROOT, setup, terminal, summary

OUT=ROOT/'matched_architecture'
SEEDS=(53,54,55)
CLASSES={'original':Network,'continuous':TerminalNetwork}

def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def labels(points,grid,values):
    tf=np.clip((50-points[:,2])/.1,0,500);k=np.minimum(tf.astype(int),499);a=tf-k
    i,j,b,c,out=setup(grid,*points[:,:2].T)
    assert not np.any(out)
    def at(kk):
        return ((1-b)*(1-c)*values[kk,i,j]+b*(1-c)*values[kk,i+1,j]
                +(1-b)*c*values[kk,i,j+1]+b*c*values[kk,i+1,j+1])
    return (1-a)*at(k)+a*at(k+1)

def stats(y,z):
    e=np.abs(z-y)
    assert np.all(np.isfinite(z))
    return dict(n=len(y),mae=float(e.mean()),rmse=float(np.sqrt(np.mean(e**2))),
                p95=float(np.quantile(e,.95)),maximum=float(e.max()),
                fraction=float(np.mean(e<=.02+.05*np.abs(y))))

def audit(points,y,z):
    masks={'all':np.ones(len(y),bool),'time_lt2':points[:,2]<2}
    for a,b in [(0,.1),(.1,.5),(.5,2),(2,10),(10,50)]:
        masks[f'time_{a}_{b}']=(points[:,2]>=a)&(points[:,2]<b)
    masks['time_0.1_0.5_low_x']=(points[:,2]>=.1)&(points[:,2]<.5)&(points[:,0]<=.05)
    masks['time_0.1_0.5_high_x']=(points[:,2]>=.1)&(points[:,2]<.5)&(points[:,0]>.05)
    loss=(np.log1p(z)-np.log1p(y))**2/(.1+np.log1p(y))
    return {name:dict(**stats(y[m],z[m]),mean_log_loss=float(loss[m].mean()),
                      share_total_log_loss=float(loss[m].sum()/max(loss.sum(),1e-30)))
            for name,m in masks.items() if np.any(m)}

def train_one(kind,seed,tp,tv,vp,vv,mean,scale):
    start=time.perf_counter();model=CLASSES[kind](mean,scale,seed)
    x=(features(tp)-mean)/scale;vx=(features(vp)-mean)/scale
    y=np.log1p(tv);vy=np.log1p(vv)
    if kind=='continuous':
        g=-np.expm1(-tp[:,2]);a=np.exp(-tp[:,2])*np.log1p(terminal(*tp[:,:2].T))
        vg=-np.expm1(-vp[:,2]);va=np.exp(-vp[:,2])*np.log1p(terminal(*vp[:,:2].T))
    else:g=np.ones(len(y));a=np.zeros(len(y));vg=np.ones(len(vy));va=np.zeros(len(vy))
    target=(y-a)/g;weight=g*g/(.1+y)
    ms=[np.zeros_like(p) for p in model.params];vs=[np.zeros_like(p) for p in model.params]
    rng=np.random.default_rng(2900+seed);step=0;best=np.inf;history=[]
    path=OUT/f'{kind}_{seed}.npz'
    for epoch in range(1,201):
        order=rng.permutation(len(y));lr=.001*(.4 if epoch>120 else 1)
        for begin in range(0,len(y),512):
            ix=order[begin:begin+512];_,grads=model.loss_gradient(x[ix],target[ix],weight[ix]);step+=1
            for k,(p,d) in enumerate(zip(model.params,grads)):
                ms[k]=.9*ms[k]+.1*d;vs[k]=.999*vs[k]+.001*d*d
                p-=lr*(ms[k]/(1-.9**step))/(np.sqrt(vs[k]/(1-.999**step))+1e-8)
        if epoch%5==0:
            raw,_=model.forward(vx);loss=float(np.mean((va+vg*raw-vy)**2/(.1+vy)))
            history.append(dict(epoch=epoch,validation_loss=loss))
            if loss<best:best=loss;selected=epoch;model.save(path)
        if epoch%100==0:print(kind,seed,epoch,'validation',loss,flush=True)
    return dict(selected_epoch=selected,validation_loss=best,epochs=200,updates=step,
                seconds=time.perf_counter()-start,history=history,sha256=sha(path))

def main():
    OUT.mkdir(exist_ok=True);gradient_test();checks=check_gradient()
    grid,u,values,params=teacher()
    tp,tv=samples(2901,40000,grid,values);vp,vv=samples(2902,6000,grid,values)
    assert np.max(np.abs(labels(vp,grid,values)-vv))<1e-12
    f=features(tp);mean=f.mean(0);scale=np.maximum(f.std(0),1e-6)
    for seed in SEEDS:
        a=Network(mean,scale,seed);b=TerminalNetwork(mean,scale,seed)
        assert all(np.array_equal(x,y) for x,y in zip(a.params,b.params))
    np.savez_compressed(OUT/'training_validation.npz',train_points=tp,train_values=tv,
                        validation_points=vp,validation_values=vv)
    training={};diagnostics={};validation_arrays={}
    for seed in SEEDS:
        for kind in CLASSES:
            name=f'{kind}_{seed}'
            training[name]=train_one(kind,seed,tp,tv,vp,vv,mean,scale)
            model=CLASSES[kind].load(OUT/f'{name}.npz');pred=model.predict(*vp.T)
            diagnostics[name]=audit(vp,vv,pred);validation_arrays[name]=pred
            save('training.json',training)
    terminal_points=vp.copy();terminal_points[:,2]=0
    terminal_bias=labels(terminal_points,grid,values)-terminal(*vp[:,:2].T)
    gate=-np.expm1(-tp[:,2]);near=(tp[:,2]>=.1)&(tp[:,2]<.5)
    diagnosis=dict(models=diagnostics,gradient_check_errors=checks,
        terminal_interpolation_bias=stats(np.zeros(len(vp)),terminal_bias),
        terminal_bias_nonnegative_fraction=float(np.mean(terminal_bias>=-1e-12)),
        training_gate_squared_time_0_1_0_5=dict(n=int(near.sum()),mean=float(np.mean(gate[near]**2)),
            minimum=float(np.min(gate[near]**2)),maximum=float(np.max(gate[near]**2))))
    save('validation_diagnostics.json',diagnosis)
    np.savez_compressed(OUT/'validation_predictions.npz',**validation_arrays,terminal_interpolation_bias=terminal_bias)
    # Freeze evidence before generating either final test.
    save('pretest_freeze.json',dict(models={n:r['sha256'] for n,r in training.items()},
        training_data_sha256=sha(OUT/'training_validation.npz'),
        validation_diagnostics_sha256=sha(OUT/'validation_diagnostics.json'),
        protocol_sha256=sha(ROOT/'MATCHED_ARCHITECTURE_PROTOCOL.md')))
    testp,testv=samples(2903,6000,grid,values)
    focusp,_=samples(2904,4000,grid,values)
    focusp[:,2]=np.random.default_rng(2905).uniform(.1,.5,len(focusp))
    focusv=labels(focusp,grid,values)
    arrays=dict(points=testp,reference=testv,focus_points=focusp,focus_reference=focusv)
    results={};paired={}
    for name in training:
        kind=name.rsplit('_',1)[0];model=CLASSES[kind].load(OUT/f'{name}.npz')
        pred=model.predict(*testp.T);fpred=model.predict(*focusp.T)
        arrays[name]=pred;arrays['focus_'+name]=fpred
        normal=audit(testp,testv,pred);focus=stats(focusv,fpred)
        results[name]=dict(standard=normal,focused=focus,
            passed=normal['all']['fraction']>=.95 and normal['time_lt2']['fraction']>=.95 and focus['fraction']>=.95)
    for seed in SEEDS:
        paired[str(seed)]={}
        for prefix,y in [('',testv),('focus_',focusv)]:
            old=arrays[f'{prefix}original_{seed}'];new=arrays[f'{prefix}continuous_{seed}']
            paired[str(seed)][prefix or 'standard']=dict(absolute_error_difference=summary(np.abs(new-y)-np.abs(old-y)),
                tolerance_fraction_difference=float(np.mean(np.abs(new-y)<=.02+.05*y)-np.mean(np.abs(old-y)<=.02+.05*y)))
    np.savez_compressed(OUT/'heldout_predictions.npz',**arrays)
    save('test_results.json',dict(models=results,paired=paired,
        continuous_all_seeds_passed=all(results[f'continuous_{s}']['passed'] for s in SEEDS)))
    print(json.dumps({n:dict(overall=r['standard']['all']['fraction'],near=r['standard']['time_lt2']['fraction'],focused=r['focused']['fraction'],passed=r['passed']) for n,r in results.items()}),flush=True)

if __name__=='__main__':main()
