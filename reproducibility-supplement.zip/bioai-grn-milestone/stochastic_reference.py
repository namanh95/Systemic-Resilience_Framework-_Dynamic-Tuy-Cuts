"""Stochastic semi-Lagrangian reference and multi-initial-state evaluation.

Strang splitting: half deterministic RK4, exact multiplicative-noise subflow,
half deterministic RK4. Gaussian quadrature in DP; Gaussian increments in MC.
Artificial domain exit payoff is explicit and varied. No state reflection.
"""
import json
import math
import time
from pathlib import Path
import numpy as np
from refined_control import flow,make_grid
from reference_control import ROOT,INITIAL,TARGET,A1,A2
from toggle_benchmark import equilibria

STATES={'high_x':INITIAL,'target':TARGET,
        'saddle':np.array(equilibria()[1]['state'])/np.array([A1,A2]),
        'low_both':np.array([.01,.01]),'mixed':np.array([.2,.2]),
        'high_both':np.array([.8,.8])}


def setup(grid,x,y):
    """Interpolation placeholders clipped only for out-of-domain queries.

    The out mask overrides these placeholders with an exit payoff; it never
    changes propagated states or reflects trajectories.
    """
    gx,gy=grid if isinstance(grid,tuple) else (grid,grid)
    out=(x>gx[-1])|(y>gy[-1])|(x<0)|(y<0)
    xx=np.clip(x,0,gx[-1]);yy=np.clip(y,0,gy[-1])
    i=np.clip(np.searchsorted(gx,xx,side='right')-1,0,len(gx)-2)
    j=np.clip(np.searchsorted(gy,yy,side='right')-1,0,len(gy)-2)
    return i,j,(xx-gx[i])/(gx[i+1]-gx[i]),(yy-gy[j])/(gy[j+1]-gy[j]),out


def interpolate(v,w):
    i,j,a,b,_=w
    return (1-a)*(1-b)*v[i,j]+a*(1-b)*v[i+1,j]+(1-a)*b*v[i,j+1]+a*b*v[i+1,j+1]


def terminal(x,y):
    return 10*((x-TARGET[0])**2+(y-TARGET[1])**2)


def branches(x,y,z,h,sigma,order):
    ax,ay,ca=flow(x,y,z,h/2)
    if sigma==0:
        bx,by,cb=flow(ax,ay,z,h/2)
        return [(bx,by,ca+cb,1.)]
    nodes,weights=np.polynomial.hermite.hermgauss(order)
    factors=np.exp(-.5*sigma*sigma*h+sigma*np.sqrt(2*h)*nodes)
    weights=weights/np.sqrt(np.pi)
    result=[]
    for i,f in enumerate(factors):
        for j,g in enumerate(factors):
            bx,by,cb=flow(ax*f,ay*g,z,h/2)
            result.append((bx,by,ca+cb,float(weights[i]*weights[j])))
    return result


def expected(v,grid,branch,exit_cost):
    total=0.
    for x,y,c,w in branch:
        info=setup(grid,x,y)
        continuation=np.where(info[-1],exit_cost+terminal(x,y),interpolate(v,info))
        total=total+w*(c+continuation)
    return total


def solve(name,sigma=.05,n=61,nu=31,dt=.1,domain=1.5,exit_cost=100.,order=2,local_scale=None):
    started=time.perf_counter()
    core=make_grid(n,True)
    # Identical interior nodes across domain comparisons; only outer cells added.
    outer=np.arange(1.05,domain+1e-9,.05)
    grid=np.unique(np.r_[core,outer]);u=np.linspace(0,10,nu)
    gx=gy=grid
    if local_scale is not None:
        gx=np.unique(np.r_[grid,np.arange(.001,.006+1e-10,.0001*local_scale)])
        gy=np.unique(np.r_[grid,np.arange(.55,.95+1e-10,.005*local_scale)])
        grid=(gx,gy)
    x,y=np.meshgrid(gx,gy,indexing='ij')
    pre=[]
    for nx,ny,c,w in branches(x[None],y[None],u[:,None,None],dt,sigma,order):
        pre.append((setup(grid,nx,ny),c,exit_cost+terminal(nx,ny),w))
    steps=round(50/dt)
    values=np.empty((steps+1,len(gx),len(gy)),dtype=float)
    values[-1]=terminal(x,y)
    for k in range(steps-1,-1,-1):
        q=0.
        for info,c,boundary,w in pre:
            q=q+w*(c+np.where(info[-1],boundary,interpolate(values[k+1],info)))
        values[k]=np.min(q,axis=0)
    params=dict(name=name,sigma=sigma,n=n,actual_grid=[len(gx),len(gy)],nu=nu,dt=dt,
                domain=domain,exit_cost=exit_cost,order=order,local_scale=local_scale)
    result=dict(parameters=params,solve_seconds=time.perf_counter()-started,
                initial_values={s:float(interpolate(values[0],setup(grid,*v))) for s,v in STATES.items()})
    return grid,u,values,result


def choose(grid,u,next_value,state,params):
    x,y=state[:,0],state[:,1]
    b=branches(x[None],y[None],u[:,None],params['dt'],params['sigma'],params['order'])
    q=expected(next_value,grid,b,params['exit_cost'])
    z=u[np.argmin(q,axis=0)]
    outside=(x>params['domain'])|(y>params['domain'])
    return np.where(outside,0.,z)


def summary(values):
    n=len(values);mean=float(np.mean(values));se=float(np.std(values,ddof=1)/np.sqrt(n)) if n>1 else 0.
    return dict(mean=mean,se=se,approx_95ci=[mean-1.96*se,mean+1.96*se])


def simulate(grid,u,values,params,initial,kind='feedback',paths=256,seed=20261102,h=.025,
             coupling_h=None,simulation_sigma=None):
    dt=params['dt'];substeps=round(dt/h)
    assert abs(substeps*h-dt)<1e-12
    rng=np.random.default_rng(seed)
    sigma=params['sigma'] if simulation_sigma is None else simulation_sigma
    bridge=1 if coupling_h is None else round(h/coupling_h)
    assert bridge>=1 and (coupling_h is None or abs(bridge*coupling_h-h)<1e-12)
    state=np.tile(initial,(paths,1));cost=np.zeros(paths);dose=np.zeros(paths)
    exited=np.zeros(paths,dtype=bool);peak=np.max(state,axis=1)
    for k in range(len(values)-1):
        z=choose(grid,u,values[k+1],state,params) if kind=='feedback' else np.full(paths,10. if kind=='pulse' and k*dt<5 else 0.)
        dose+=dt*z*z
        for _ in range(substeps):
            x,y,ca=flow(state[:,0],state[:,1],z,h/2)
            normal=rng.standard_normal((bridge,paths,2)).sum(axis=0)/np.sqrt(bridge)
            factors=np.exp(-.5*sigma**2*h+sigma*np.sqrt(h)*normal)
            # Count exits at intermediate noise subflow as well as step endpoints.
            exited|=(x*factors[:,0]>params['domain'])|(y*factors[:,1]>params['domain'])
            x,y,cb=flow(x*factors[:,0],y*factors[:,1],z,h/2)
            state=np.column_stack([x,y]);cost+=ca+cb
            assert np.all(state>=0) and np.all(np.isfinite(state))
            peak=np.maximum(peak,np.max(state,axis=1))
            exited|=np.max(state,axis=1)>params['domain']
    cost+=terminal(state[:,0],state[:,1])
    distances=np.linalg.norm(state-TARGET,axis=1)
    result=dict(cost=summary(cost),integral_z_squared=summary(dose),
                final_target_distance=summary(distances),
                fraction_within_005=float(np.mean(distances<=.05)),
                paths=paths,exited_paths=int(exited.sum()),max_normalized_state=float(peak.max()),
                seed=seed,simulation_step=h,simulation_sigma=sigma)
    return result,cost


def tests():
    grid=np.array([0.,.5,1.,1.5]);x,y=np.meshgrid(grid,grid,indexing='ij')
    assert abs(float(interpolate(2*x+3*y,setup(grid,.2,.4)))-1.6)<1e-12
    # Exit branch returns declared payoff, never reflected interpolation.
    b=[(np.array([2.]),np.array([.5]),np.array([0.]),1.)]
    assert float(expected(np.zeros((4,4)),grid,b,100)[0])==float(100+terminal(2.,.5))
    for sigma in [0,.05,.1]:
        b=branches(.5,.5,np.array([0.,10.]),.1,sigma,2)
        assert abs(sum(t[3] for t in b)-1)<1e-12
        assert all(np.all(t[0]>=0) and np.all(t[1]>=0) for t in b)
    x,y,c,_=branches(*TARGET,0,.1,0,2)[0]
    assert np.linalg.norm(np.array([x,y])-TARGET)<1e-13 and abs(c)<1e-25
    # Verify quadrature lognormal moments against their exact analytic values.
    nodes,w=np.polynomial.hermite.hermgauss(2);w=w/np.sqrt(np.pi)
    f=np.exp(-.5*.1**2*.1+.1*np.sqrt(.2)*nodes)
    assert abs(np.dot(w,f)-1)<1e-6
    assert abs(np.dot(w,f*f)-np.exp(.1**2*.1))<2e-6


def main():
    tests()
    # Pragmatic, pre-run stochastic screening gates (not mathematical bounds):
    # domain/boundary changes <= .01+.01*|V|; refinements <= .02+.02*|V|.
    configs=[dict(name='deterministic',sigma=0),dict(name='noise005'),
             dict(name='noise010',sigma=.1),
             dict(name='domain125',domain=1.25),dict(name='domain200',domain=2.),
             dict(name='boundary400',domain=1.25,exit_cost=400.),
             dict(name='space91',n=91),dict(name='time005',dt=.05),
             dict(name='quadrature3',order=3)]
    for config in configs:
        grid,u,values,result=solve(**config);p=result['parameters'];name=p['name']
        np.savez_compressed(ROOT/('stochastic_'+name+'_v0.npz'),grid=grid,value0=values[0])
        if name in ('deterministic','noise005','noise010'):
            np.savez_compressed(ROOT/('stochastic_'+name+'_policy.npz'),grid=grid,controls=u,values=values,parameters=json.dumps(p))
            result['simulations']={}
            for index,(label,initial) in enumerate(STATES.items()):
                runs={};costs={}
                for kind in ('feedback','zero','pulse'):
                    runs[kind],costs[kind]=simulate(grid,u,values,p,initial,kind,paths=256 if p['sigma'] else 1,seed=20261102+index)
                runs['paired_feedback_minus_zero']=summary(costs['feedback']-costs['zero'])
                runs['paired_feedback_minus_pulse']=summary(costs['feedback']-costs['pulse'])
                result['simulations'][label]=runs
        # Persist each independent run as soon as complete.
        (ROOT/('stochastic_'+name+'.json')).write_text(json.dumps(result,indent=2))
        print(json.dumps(dict(name=name,solve_seconds=result['solve_seconds'],initial_values=result['initial_values'],
                             high_x_feedback=result.get('simulations',{}).get('high_x',{}).get('feedback',{}))),flush=True)


if __name__=='__main__':
    main()
