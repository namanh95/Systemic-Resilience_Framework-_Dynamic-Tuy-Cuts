"""Report paired architecture evidence, including all failed screens."""
import json
import zipfile
from matched_architecture import ROOT, OUT, SEEDS, sha

def read(name):return json.loads((OUT/name).read_text())

def main():
    training=read('training.json');validation=read('validation_diagnostics.json')
    result=read('test_results.json');freeze=read('pretest_freeze.json')
    assert len(training)==6 and set(training)==set(result['models'])
    for name,h in freeze['models'].items():assert sha(OUT/f'{name}.npz')==h
    assert sha(OUT/'validation_diagnostics.json')==freeze['validation_diagnostics_sha256']
    assert sha(OUT/'training_validation.npz')==freeze['training_data_sha256']
    assert sha(ROOT/'MATCHED_ARCHITECTURE_PROTOCOL.md')==freeze['protocol_sha256']
    for seed in SEEDS:
        assert training[f'original_{seed}']['updates']==training[f'continuous_{seed}']['updates']
    prior=json.loads((ROOT/'NEURAL_REFERENCE_MANIFEST.json').read_text())
    for name,h in prior['source_sha256'].items():assert sha(ROOT/name)==h
    passed=result['continuous_all_seeds_passed']
    lines=['# Matched architecture comparison and near-terminal diagnosis','','3 November 2026','',
        f"Experiment complete. All-three-seed continuous-model accuracy criterion: **{'PASS' if passed else 'FAIL'}**.",'',
        'All six models passed the overall and time<2 component screens but failed the '
        'targeted [.1,.5) screen. Original-model targeted tolerance fractions were '
        '91.93–93.68%; continuous-model fractions were 86.78–91.90%. The continuous '
        'model had higher targeted mean absolute error in every matched pair. Thus this '
        'experiment does not support adopting terminal blending as a general accuracy '
        'improvement. These are findings for the specified data, seeds and training budget.','',
        'This comparison isolates the two existing value-network implementations under matched '
        'data and optimization settings. It does not establish improved closed-loop control. '
        'All six models and all failures are retained. No test-based tuning or model selection '
        'was performed.','',
        '## What was controlled','',
        'Each paired seed (53,54,55) uses identical initial parameter arrays, features, '
        'normalization, 40,000 training points, 6,000 validation points, minibatch orders, '
        'Adam settings and 200-epoch budget. Checkpoints are selected every five epochs '
        'by weighted log-value validation loss. Selected epochs can differ. The original '
        'and continuous constructions retain their existing output clipping rules; the '
        'comparison is between those complete implementations.','',
        'Training/validation seeds are 2901/2902; shuffle seeds 2953/2954/2955. All six '
        'checkpoints and validation diagnostics were hashed before test generation. The '
        'standard fresh test has 6,000 points (2903). The targeted test has 4,000 points '
        '(state seed 2904, time seed 2905), with the same state mixture but remaining time '
        'uniform in [.1,.5). Targeted results are not pooled with the standard mixture.','',
        '## Fresh held-out results','',
        'Each model must achieve >=95% within .02+.05*abs(reference value) overall, '
        'for remaining time <2 in the standard test, and in the targeted test.','',
        '| Model | Overall within tolerance | Time <2 within tolerance | Targeted .1–.5 within tolerance | All three criteria |',
        '|---|---:|---:|---:|---|']
    for name,r in result['models'].items():
        lines.append(f"| {name} | {r['standard']['all']['fraction']:.2%} | {r['standard']['time_lt2']['fraction']:.2%} | {r['focused']['fraction']:.2%} | {'PASS' if r['passed'] else 'FAIL'} |")
    lines+=['','| Model | Standard MAE | Targeted MAE | Targeted maximum error | Selected epoch | Training seconds |',
            '|---|---:|---:|---:|---:|---:|']
    for name,r in result['models'].items():
        t=training[name]
        lines.append(f"| {name} | {r['standard']['all']['mae']:.6f} | {r['focused']['mae']:.6f} | {r['focused']['maximum']:.6f} | {t['selected_epoch']} | {t['seconds']:.2f} |")
    lines+=['','## Paired architecture differences','',
            'Negative absolute-error differences favor the continuous architecture. Intervals '
            'describe point-sampling variation conditional on each trained pair, not training '
            'or reference uncertainty. They are approximate and not adjusted for multiple '
            'comparisons. The same points are reused across seeds; three seeds are too few '
            'to establish general superiority.','',
            '| Seed | Test | Mean absolute-error difference (continuous − original) | Approximate 95% interval | Tolerance-fraction difference |',
            '|---|---|---:|---|---:|']
    for seed,groups in result['paired'].items():
        for group,r in groups.items():
            d=r['absolute_error_difference'];lo,hi=d['approx_95ci']
            lines.append(f"| {seed} | {group} | {d['mean']:.6f} | [{lo:.6f}, {hi:.6f}] | {r['tolerance_fraction_difference']:+.2%} |")
    bias=validation['terminal_interpolation_bias'];gate=validation['training_gate_squared_time_0_1_0_5']
    lines+=['','## Validation-only diagnosis','',
            'The following diagnostics were recorded before test generation. They were not '
            'used to change architectures, losses, training budgets or thresholds.','',
            f"At zero remaining time, bilinear teacher interpolation differs from the analytic "
            f"terminal cost: mean absolute difference {bias['mae']:.7g}, maximum {bias['maximum']:.7g} "
            f"on the 6,000 validation states. This is a reference-label discrepancy, not neural "
            'error. Its terminal magnitude alone cannot explain errors at later times.','',
            f"For the {gate['n']} training samples in [.1,.5), the squared blend gate averages "
            f"{gate['mean']:.4f} (range {gate['minimum']:.4f}–{gate['maximum']:.4f}). "
            'In the algebraically equivalent residual-network loss this gate scales the '
            'squared residual. It changes sensitivity to raw network output near the '
            'boundary. It is a candidate optimization mechanism, not proof that reweighting '
            'would improve accuracy or control.','',
            '| Model | Validation time band | Points | MAE | Within tolerance | Share of total deployed log-loss |',
            '|---|---|---:|---:|---:|---:|']
    for name,groups in validation['models'].items():
        for group in ['time_0_0.1','time_0.1_0.5','time_0.5_2','time_0.1_0.5_low_x','time_0.1_0.5_high_x']:
            r=groups[group]
            lines.append(f"| {name} | {group} | {r['n']} | {r['mae']:.6f} | {r['fraction']:.2%} | {r['share_total_log_loss']:.2%} |")
    lines+=['','Subgroups overlap; their loss shares must not be summed. Low/high x uses '
            'the normalized threshold .05. Deployed log-loss includes prediction clipping; '
            'checkpoint selection uses the unclipped log-output objective.','',
            '## Verification and limits','',
            'The general teacher evaluator matched the existing sampler to 1e-12. '
            'Representative finite-difference gradient checks passed for both constructions. '
            'Paired initial parameters and update counts were checked, and frozen model, '
            'data, diagnostic and protocol hashes were verified when writing this report. '
            'Original reference source files remain unchanged.','',
            'This is supervised regression against an approximate reference, not a PINN, '
            'a derivative certificate, biological validation, or a test of closed-loop policy '
            'improvement. No new control trajectories were run in this value-only milestone. '
            'Matching one dataset removes the earlier data mismatch, but does not assess '
            'variation across training datasets, different model widths, or other budgets.','',
            'The next candidate experiment should be chosen from training/validation evidence: '
            'test targeted near-terminal sampling or loss weighting as an explicit ablation '
            'while holding the architecture and sample budget fixed. Reserve fresh final tests '
            'and validate any resulting controller separately. This is a proposal, not a claim '
            'that either adjustment has been shown to work.','',
            '## Reproduction','',
            'With Python, NumPy and the frozen reference archive available, set '
            'OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1, then run:', '',
            '    python matched_architecture.py',
            '    python write_matched_report.py','',
            'Raw training/validation points, validation predictions, held-out predictions, '
            'six model files, histories and hashes are in matched_architecture/. The portable '
            'package omits large teacher archives; retain the local reference or regenerate '
            'it using the earlier-stage scripts.','']
    (ROOT/'MATCHED_ARCHITECTURE_RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    manifest=dict(experiment_complete=True,continuous_all_seeds_passed=passed,
        reference_sha256=prior['sha256'],files={str(p.relative_to(ROOT)):sha(p) for p in sorted(OUT.glob('*')) if p.is_file()},
        source_sha256={name:sha(ROOT/name) for name in ['matched_architecture.py','write_matched_report.py','neural_pilot.py','terminal_multiseed.py','MATCHED_ARCHITECTURE_PROTOCOL.md']})
    (ROOT/'MATCHED_ARCHITECTURE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    package=ROOT.parent/'bioai-matched-architecture-package.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in [ROOT.parent/'bioai-baseline',ROOT]:
            for p in sorted(folder.rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.md','.json','.csv','.npy'} or (p.suffix=='.npz' and (p.name.startswith('neural_') or p.parent.name in {'terminal_multiseed','matched_architecture'}))):
                    z.write(p,p.relative_to(ROOT.parent))
        z.writestr('PACKAGE_README.md','Start with bioai-grn-milestone/MATCHED_ARCHITECTURE_RESULTS.md. Includes all six models and raw paired evidence. Python/NumPy required. Large teacher archives omitted; preserve sibling folder names. This milestone evaluates values only, not new control rollouts.\n')
    with zipfile.ZipFile(package) as z:assert z.testzip() is None
    print('Experiment complete; continuous all-seed criterion:',passed)
    print('Verified package:',package)

if __name__=='__main__':main()
