"""Separate spatial, control, and temporal sensitivity checks."""
import json
from reference_control import ROOT,compute,rollout


def main():
    results=[]
    for n,nu,dt in [(101,41,.05),(71,81,.05),(71,41,.025)]:
        name,grid,u,policy,estimate,seconds=compute(n,nu,dt)
        feedback,_=rollout(grid,u,policy,dt)
        results.append(dict(name=name,dp_value=estimate,seconds=seconds,feedback=feedback))
        (ROOT/'refinement_results.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(results[-1]),flush=True)


if __name__=='__main__':
    main()
