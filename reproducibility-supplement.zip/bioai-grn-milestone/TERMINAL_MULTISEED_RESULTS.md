# Continuous terminal condition: three-seed replication

3 November 2026

Experiment complete. Prespecified overall stage outcome: **FAIL**.
All three value screens: FAIL. All twelve policy screens: PASS.

Failed value-screen seeds: 43. Failed start/seed policy screens: none.

This is supervised regression against the same approximate numerical reference. It is not physics-informed training, a continuous optimality certificate, or biological validation. All three seeds are reported, with no test-driven retraining or best-seed selection.

## Construction and evaluation separation

The revised log-value blends the known terminal log-cost with the network output: L = exp(-tau) log(1+terminal) + (1-exp(-tau)) N. Prediction is expm1(max(L,0)). This construction continuously recovers the exact terminal value. Nonnegative clipping can introduce kinks; continuous terminal behavior does not prove derivative accuracy. The upper log-output clip used in the original model is removed.

All models use 1,377 learned parameters and the same original feature set. Three initializations (43,44,45) share fresh training/validation sets of 40,000/6,000 points (seeds 1901/1902). Shuffle seeds are 1943/1944/1945. All checkpoints were selected using validation loss before generating the 6,000-point test (1903). This isolates initialization/optimization variability, not variation across datasets. The original frozen model is reevaluated on the same new test. Because it used different training data, this comparison does not isolate architecture as the sole cause of differences.

## Held-out values

Each revised model must meet >=95% within .02+.05*abs(reference value), both overall and for remaining time below 2. Subgroups and thresholds were declared before training.

| Model | Overall MAE | Overall within tolerance | Time <2 MAE | Time <2 within tolerance | Screen |
|---|---:|---:|---:|---:|---|
| original | 0.013799 | 97.33% | 0.029222 | 91.93% | FAIL |
| 43 | 0.013775 | 98.00% | 0.027241 | 94.11% | FAIL |
| 44 | 0.011894 | 98.60% | 0.024447 | 95.75% | PASS |
| 45 | 0.012307 | 98.85% | 0.025220 | 96.40% | PASS |

The original model is assessed here against the new, stricter two-part screen for comparison; this does not retroactively change its original pilot result.

The closest-to-terminal [0,.1) subgroup contains only 75 points, so its improved tolerance fractions are descriptive, not evidence of uniform accuracy. The [.1,.5) subgroup remains weaker despite exact boundary matching.

| Model | Subgroup | Points | MAE | Maximum error | Within tolerance |
|---|---|---:|---:|---:|---:|
| original | time_0_0.1 | 75 | 0.133322 | 1.436707 | 57.33% |
| original | time_0.1_0.5 | 371 | 0.055897 | 1.090243 | 86.79% |
| original | time_0.5_2 | 1389 | 0.016477 | 1.043200 | 95.18% |
| original | time_2_10 | 1789 | 0.006970 | 0.085582 | 99.55% |
| original | time_10_50 | 2376 | 0.007030 | 0.100447 | 99.83% |
| original | near_target | 2436 | 0.004933 | 0.100999 | 96.72% |
| 43 | time_0_0.1 | 75 | 0.052933 | 0.493175 | 96.00% |
| 43 | time_0.1_0.5 | 371 | 0.057696 | 0.687005 | 89.22% |
| 43 | time_0.5_2 | 1389 | 0.017719 | 1.030531 | 95.32% |
| 43 | time_2_10 | 1789 | 0.008062 | 0.156660 | 99.55% |
| 43 | time_10_50 | 2376 | 0.007676 | 0.094400 | 99.83% |
| 43 | near_target | 2436 | 0.004382 | 0.134902 | 97.58% |
| 44 | time_0_0.1 | 75 | 0.039834 | 0.449353 | 97.33% |
| 44 | time_0.1_0.5 | 371 | 0.048928 | 0.583009 | 91.37% |
| 44 | time_0.5_2 | 1389 | 0.017077 | 0.880378 | 96.83% |
| 44 | time_2_10 | 1789 | 0.006737 | 0.095158 | 99.89% |
| 44 | time_10_50 | 2376 | 0.006083 | 0.107198 | 99.83% |
| 44 | near_target | 2436 | 0.003950 | 0.126144 | 98.28% |
| 45 | time_0_0.1 | 75 | 0.051848 | 0.585102 | 98.67% |
| 45 | time_0.1_0.5 | 371 | 0.055770 | 0.895560 | 90.84% |
| 45 | time_0.5_2 | 1389 | 0.015622 | 1.132852 | 97.77% |
| 45 | time_2_10 | 1789 | 0.007207 | 0.162962 | 99.94% |
| 45 | time_10_50 | 2376 | 0.006175 | 0.092585 | 99.92% |
| 45 | near_target | 2436 | 0.003548 | 0.114258 | 98.56% |

## Training and terminal checks

Maximum checked gradient discrepancy: 1.42e-10. Central differences check representative entries in every parameter array against the blended-output loss.

| Seed | Selected epoch | Training seconds | Terminal error at zero | Error at tau=1e-8 |
|---|---:|---:|---:|---:|
| 43 | 200 | 21.04 | 3.55e-15 | 4.24e-07 |
| 44 | 200 | 18.72 | 3.55e-15 | 4.12e-07 |
| 45 | 200 | 30.93 | 3.55e-15 | 4.42e-07 |

Terminal checks use 100 fixed states in [0,1.2]^2. Values at tau=0, 1e-2,1e-4,1e-6,1e-8 are retained in training.json. Boundary matching is structural; accuracy away from that boundary remains empirical.

## Paired noisy control evaluation

Each start uses 128 fresh Brownian paths (seeds 20264000..20264003), shared across the reference, original model, and all three revised models. This is a smaller exploratory batch than the first pilot. The same 61 controls, .1 decision interval, .025 simulation step, sigma=.05, running/terminal costs and Bellman lookahead are used. Zero-control fallback applies outside the observed training box; lookahead branch states can still require extrapolation.

| Start | Model | Mean cost | Increase vs reference | Approximate paired 95% interval | Screen |
|---|---|---:|---:|---|---|
| high_x | reference | 2.5132078 | - | - | - |
| high_x | original | 2.5199853 | 0.0067775 | [0.0058977, 0.0076573] | PASS |
| high_x | 43 | 2.5196275 | 0.0064197 | [0.0059395, 0.0068998] | PASS |
| high_x | 44 | 2.5203002 | 0.0070924 | [0.0062769, 0.0079080] | PASS |
| high_x | 45 | 2.5211275 | 0.0079197 | [0.0074077, 0.0084317] | PASS |
| target | reference | 0.0538414 | - | - | - |
| target | original | 0.0569171 | 0.0030758 | [0.0022513, 0.0039003] | PASS |
| target | 43 | 0.0552694 | 0.0014281 | [0.0009871, 0.0018691] | PASS |
| target | 44 | 0.0562273 | 0.0023859 | [0.0016918, 0.0030800] | PASS |
| target | 45 | 0.0553052 | 0.0014639 | [0.0008912, 0.0020365] | PASS |
| saddle | reference | 0.1094994 | - | - | - |
| saddle | original | 0.1120982 | 0.0025988 | [0.0018249, 0.0033726] | PASS |
| saddle | 43 | 0.1108739 | 0.0013745 | [0.0008792, 0.0018699] | PASS |
| saddle | 44 | 0.1135626 | 0.0040631 | [0.0033046, 0.0048216] | PASS |
| saddle | 45 | 0.1123209 | 0.0028214 | [0.0021868, 0.0034560] | PASS |
| mixed | reference | 0.6375606 | - | - | - |
| mixed | original | 0.6423267 | 0.0047662 | [0.0038552, 0.0056772] | PASS |
| mixed | 43 | 0.6423268 | 0.0047662 | [0.0042615, 0.0052710] | PASS |
| mixed | 44 | 0.6433690 | 0.0058085 | [0.0049099, 0.0067070] | PASS |
| mixed | 45 | 0.6418908 | 0.0043303 | [0.0037051, 0.0049554] | PASS |

Each screen requires upper interval <= .01+.05*reference mean cost. Passing does not imply equal or improved performance. Intervals measure path sampling uncertainty only, are not adjusted for multiple comparisons, and exclude numerical reference/model error. Shared paths and data mean these tests are not independent replications of the biological system.

| Start | Seed | Paired difference vs original | Approximate 95% interval | Rollout seconds | Fallback paths |
|---|---|---:|---|---:|---:|
| high_x | 43 | -0.0003578 | [-0.0008725, 0.0001568] | 38.97 | 0/128 |
| high_x | 44 | 0.0003149 | [-0.0003833, 0.0010132] | 45.11 | 0/128 |
| high_x | 45 | 0.0011422 | [0.0003572, 0.0019271] | 56.69 | 0/128 |
| target | 43 | -0.0016477 | [-0.0021352, -0.0011602] | 44.28 | 0/128 |
| target | 44 | -0.0006898 | [-0.0013778, -0.0000019] | 26.26 | 0/128 |
| target | 45 | -0.0016119 | [-0.0025141, -0.0007098] | 54.90 | 0/128 |
| saddle | 43 | -0.0012243 | [-0.0016322, -0.0008164] | 35.90 | 0/128 |
| saddle | 44 | 0.0014643 | [0.0008166, 0.0021120] | 50.27 | 0/128 |
| saddle | 45 | 0.0002227 | [-0.0005156, 0.0009609] | 59.22 | 0/128 |
| mixed | 43 | 0.0000000 | [-0.0005239, 0.0005239] | 58.42 | 0/128 |
| mixed | 44 | 0.0010423 | [0.0002895, 0.0017951] | 23.64 | 0/128 |
| mixed | 45 | -0.0004359 | [-0.0013373, 0.0004655] | 19.29 | 0/128 |

Runtime is full rollout wall time with BLAS/OMP threads set to one, excluding loading. Original and reference runtimes are retained in rollouts.json. No speed advantage is assumed.

## Interpretation

The experiment separates architectural boundary matching, held-out value accuracy, and downstream control performance. The prespecified screen outcome above must be retained even if some metrics improve. Three seeds, one sampling mixture, four initial states and one noise level do not establish broad robustness. No biological data were fitted. Neural gradients and certified Hamiltonian selection remain untested.

A focused follow-up is to investigate the remaining-time .1 to .5 region using training/validation residuals, then compare the original and terminal-constrained architectures under matched training data and multiple initializations. The present comparison changes both architecture and training data, so it cannot isolate the architecture effect. Do not advance to a robustness claim by selecting only the seeds that passed this experiment.

Any follow-up tuning must use training/validation evidence and reserve new test points and paths. The results of this stage must not be reused as an untouched test set for a revised architecture.

## Reproduction and files

Run from the bioai-grn-milestone folder, with Python and NumPy plus the frozen pretraining_control_policy.npz reference archive available:

    python terminal_multiseed.py train
    python terminal_multiseed.py evaluate
    python write_terminal_report.py

Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 first. The portable ZIP includes models, fresh held-out predictions, raw paired rollout costs, source, protocols and prior lightweight results. Large teacher archives are omitted and remain local.
