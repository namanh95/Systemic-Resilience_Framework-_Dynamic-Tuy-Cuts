# Validated selection and deterministic reference control

2 November 2026

## Completed work

Implemented outward-enclosed fractional powers without changing the published
exponent 2.0015. Transferred the earlier strict-pruning branch-and-bound solver
to the toggle Hamiltonian. Computed conventional finite-horizon deterministic
feedback policies and separate spatial, temporal, and control-grid refinements.
Stochastic control and neural training are not part of this milestone.

## What is certified

For rational t>=1, enclose t^(4003/2000) through exp(2.0015 ln(t)). Decimal ln
and exp are correctly rounded to nearest; adjacent representable numbers bound
their exact values. Conversion and multiplication round outward. The final
decimal bounds become exact fractions for all subsequent comparisons.
This avoids relying on Decimal.power's weaker rounding guarantee. See
[Python Decimal documentation](https://docs.python.org/3/library/decimal.html).
The argument relies on the documented arithmetic implementation, not a formal
verification of the Python runtime. Nonfinite results are rejected.

Independently checked five power enclosures using exact integer/rational
comparisons: lower^2000 <= t^4003 <= upper^2000. Seven test landscapes passed,
including zero state, both sensitivity signs, interior and boundary controls.
Budget exhaustion correctly returns uncertified. Dense sampled values supplement
the tests but are not used to justify continuous-domain lower bounds.

Incumbent values are upper enclosures, while region bounds are lower enclosures.
Strict exclusion therefore still preserves all global minimizers, including ties.
The original generic solver accepts these upper oracles unchanged; its returned
upper field is now an enclosure rather than an exact point value.

All seven tests reached objective gap <=1e-4. Full rational bounds and exclusions
are in grn_certificates.json. These apply only to fixed specified state and
sensitivity inputs, not to their biological or approximation accuracy.

## Reference-control method

The specification in RESEARCH_SPEC.md is used with sigma=0, horizon 50,
intervention penalty .01*z^2 and terminal weight 10. Normalized states are in
[0,1]^2, with squared-coordinate graded grids. Backward dynamic programming
uses Euler transitions, bilinear value interpolation, and sampled controls.
Euler steps with dt<=1 preserve the rectangle here, as each updated coordinate
is a convex combination of its current value and normalized production in [0,1].
Transition domains are checked; no artificial reflecting boundary is introduced.

For rollout, interpolate the stored minimizing controls in state, hold control
over each decision step, integrate dynamics using RK4, and integrate cost using
the trapezoidal rule. This executable interpolated feedback differs from the
grid policy used in the discrete Bellman recursion. Both are approximations;
neither is a certified optimum of the continuous-time HJB problem.

The initial condition is the high-x equilibrium. The preset-pulse comparator
uses z=10 until time 5, then zero. The zero-control comparator stays at the
undesired equilibrium. All use the same cost functional.

## Initial refinement results

| State grid | Controls | dt | Discrete initial value | RK4 feedback cost |
|---|---:|---:|---:|---:|
| 31 x 31 | 21 | .10 | 2.993015 | 2.468652 |
| 51 x 51 | 41 | .10 | 2.661793 | 2.471350 |
| 71 x 71 | 41 | .05 | 2.547817 | 2.464121 |
| 101 x 101 | 41 | .05 | 2.564455 | 2.462461 |
| 71 x 71 | 81 | .05 | 2.547234 | 2.468740 |
| 71 x 71 | 41 | .025 | 2.529953 | 2.463973 |

At dt=.05 the pulse costs 6.215787 and zero control costs 92.596939.
The 101 x 101 policy uses integral z^2 = 86.9062, versus 500 for the pulse.
Its final normalized target distance is .00467005; the pulse ends closer to
the exact target (approximately .00002885). The controller's lower cost does
not mean that it wins on every biological outcome: the objective trades state
error against intervention burden.

For the three initial runs, halving RK4 substeps changes feedback cost by less
than 3.1e-6. This tests rollout integration, not the HJB discretization.
The spatial value estimates are nonmonotone, and the value/rollout discrepancy
persists. Policy performance is encouraging; continuous optimality or numerical
convergence is not established. reference_results.json and refinement_results.json
record the complete results, including the isolated dt=.025 run.

## Connection to computed value sensitivities

At time zero, took the local bilinear y derivative of the 101 x 101 reference
value and converted it to a derivative in the original repressor coordinate.
Then certified the frozen Hamiltonian at three states:

| State | Approximate V_y | Certified candidate z | Gap upper bound |
|---|---:|---:|---:|
| Initial equilibrium | -.37114755 | 10 | .0000990910 |
| Target equilibrium | .00187451 | 0 | 0 |
| Normalized state (.2,.2) | -.06814391 | 4.68048096 | .0000998583 |

Certificates treat the decimal representations of these approximate inputs as
exact. They do NOT bound derivative error. The dynamic-programming computation
uses sampled controls, not this certified selector at every node. This is a
tested interface between the two components, not end-to-end certified feedback.

## Reproduction and outputs

From this folder, with Python and NumPy installed:

    python validated_selector.py
    python reference_control.py
    python refine_reference.py
    python check_reference_selection.py

The selector additionally imports the sibling bioai-baseline module. Each .npz
contains its grid, controls, full time-indexed policy, dt, and initial value
surface. JSON files contain results and certificates; CSVs contain initial-run
feedback rollouts. The scripts regenerate these files. No original manuscript
files were modified.

## Next research gate

Before neural approximation, investigate remaining value discretization error,
including higher-order characteristic integration and targeted spatial refinement
near the switching region. Obtain an independent reference comparison and
define a quantitative convergence criterion. Stochastic reference computation
then requires an expanded domain and truncation-error investigation; the
deterministic invariant rectangle is not invariant for multiplicative noise.
No experimental biological effectiveness or novelty claim follows from this study.
