"""Adaptive follow-up after coarse-grid value/MC disagreement was observed."""
import json
import numpy as np
from stochastic_reference import ROOT,STATES,solve,simulate,summary


def main():
    for scale in (1.,.5):
        name='local'+str(scale).replace('.','p')
        grid,u,v,result=solve(name=name,local_scale=scale)
        p=result['parameters'];gx,gy=grid
        np.savez_compressed(ROOT/('stochastic_'+name+'_v0.npz'),gridx=gx,gridy=gy,value0=v[0])
        if scale==.5:
            np.savez_compressed(ROOT/('stochastic_'+name+'_policy.npz'),gridx=gx,gridy=gy,controls=u,values=v,parameters=json.dumps(p))
        result['simulations']={}
        for i,label in enumerate(('high_x','target','saddle')):
            r,c=simulate(grid,u,v,p,STATES[label],paths=256,seed=20261102+list(STATES).index(label))
            result['simulations'][label]={'feedback':r}
        (ROOT/('stochastic_'+name+'.json')).write_text(json.dumps(result,indent=2))
        print(json.dumps(dict(name=name,solve_seconds=result['solve_seconds'],initial_values=result['initial_values'],
                             feedback_means={k:t['feedback']['cost']['mean'] for k,t in result['simulations'].items()})),flush=True)


if __name__=='__main__':
    main()
