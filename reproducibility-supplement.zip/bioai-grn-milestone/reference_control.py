"""Conventional deterministic semi-Lagrangian reference. NOT a PDE certificate.

Backward dynamic programming, Euler transitions, bilinear interpolation on
graded state grids, and discrete intervention candidates. NumPy only.
"""
from pathlib import Path
import json
import time
import numpy as np
from toggle_benchmark import equilibria, rk4, A1,A2,ETA

ROOT=Path(__file__).resolve().parent
TARGET=np.array(equilibria()[0]['state'])/np.array([A1,A2])
INITIAL=np.array(equilibria()[-1]['state'])/np.array([A1,A2])


def interp_setup(grid,x,y):
    if np.min(x)<-1e-12 or np.max(x)>1+1e-12 or np.min(y)<-1e-12 or np.max(y)>1+1e-12:
        raise ValueError('Transition outside deterministic domain')
    i=np.clip(np.searchsorted(grid,x,side='right')-1,0,len(grid)-2)
    j=np.clip(np.searchsorted(grid,y,side='right')-1,0,len(grid)-2)
    return i,j,(x-grid[i])/(grid[i+1]-grid[i]),(y-grid[j])/(grid[j+1]-grid[j])


def interp(v,weights):
    i,j,a,b=weights
    return (1-a)*(1-b)*v[i,j]+a*(1-b)*v[i+1,j]+(1-a)*b*v[i,j+1]+a*b*v[i+1,j+1]


def compute(n,nu,dt,T=50):
    started=time.perf_counter()
    grid=np.linspace(0,1,n)**2
    x,y=np.meshgrid(grid,grid,indexing='ij')
    controls=np.linspace(0,10,nu)
    d=(x-TARGET[0])**2+(y-TARGET[1])**2
    nx=x+dt*(1/(1+(A2*y)**2.5)-x)
    ny=y[None,:,:]+dt*(1/(1+A1*x[None,:,:]/(1+controls[:,None,None])**ETA)-y[None,:,:])
    weights=interp_setup(grid,np.broadcast_to(nx,ny.shape),ny)
    running=dt*(d[None,:,:]+.01*controls[:,None,None]**2)
    steps=round(T/dt)
    policy=np.empty((steps,n,n),dtype=np.uint8)
    v=10*d
    for k in range(steps-1,-1,-1):
        q=running+interp(v,weights)
        policy[k]=np.argmin(q,axis=0)
        v=np.min(q,axis=0)
    estimate=float(interp(v,interp_setup(grid,*INITIAL)))
    name=f'n{n}_u{nu}_dt{dt}'
    np.savez_compressed(ROOT/(name+'.npz'),grid=grid,controls=controls,policy=policy,dt=dt,value0=v)
    return name,grid,controls,policy,estimate,time.perf_counter()-started


def rollout(grid,controls,policy,dt,kind='feedback',substeps=2):
    state=INITIAL*np.array([A1,A2]); cost=0.; dose=0.; rows=[]
    for k in range(len(policy)):
        z=(float(interp(controls[policy[k]],interp_setup(grid,*(state/np.array([A1,A2])))))
           if kind=='feedback' else (10. if kind=='pulse' and k*dt<5 else 0.))
        h=dt/substeps
        for _ in range(substeps):
            old=np.sum((state/np.array([A1,A2])-TARGET)**2)+.01*z*z
            new=np.array(rk4(state,z,h))
            newcost=np.sum((new/np.array([A1,A2])-TARGET)**2)+.01*z*z
            cost+=h*(old+newcost)/2
            state=new
        dose+=dt*z*z
        rows.append((k*dt,*state,z))
    cost+=10*np.sum((state/np.array([A1,A2])-TARGET)**2)
    return dict(cost=float(cost),integral_z_squared=dose,final_state=state.tolist(),
                target_distance=float(np.linalg.norm(state/np.array([A1,A2])-TARGET))),rows


def main():
    results=[]
    for n,nu,dt in [(31,21,.1),(51,41,.1),(71,41,.05)]:
        name,grid,u,policy,estimate,seconds=compute(n,nu,dt)
        result=dict(name=name,n=n,control_points=nu,dt=dt,dp_value=estimate,seconds=seconds)
        for kind in ['feedback','uncontrolled','pulse']:
            result[kind],rows=rollout(grid,u,policy,dt,kind)
            if kind=='feedback':
                np.savetxt(ROOT/(name+'_trajectory.csv'),rows,delimiter=',',header='step_start_time,end_x,end_y,control',comments='')
        fine,_=rollout(grid,u,policy,dt,substeps=4)
        result['rollout_step_halving_cost_change']=abs(fine['cost']-result['feedback']['cost'])
        assert result['rollout_step_halving_cost_change']<.001
        results.append(result)
        (ROOT/'reference_results.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(result),flush=True)
    print('Reference computations completed; inspect refinement before claiming convergence.',flush=True)


if __name__=='__main__':
    main()
