"""Local-grid stochastic validation before any neural-training labels are released.

Precomputed sparse interpolation stencils accelerate the existing Bellman rule.
This is the same numerical method, not a new PDE discretization.
"""
import argparse
import json
import time
import numpy as np
from stochastic_reference import ROOT,STATES,branches,setup,terminal,interpolate,simulate
from refined_control import make_grid

CONFIGS={
    'time':dict(dt=.05),
    'control':dict(nu=61),
    'quadrature':dict(order=3),
    'higher_noise':dict(sigma=.1),
    'higher_noise_coarser':dict(sigma=.1,local_scale=1.),
}


def solve_fast(name,sigma=.05,n=61,nu=31,dt=.1,domain=1.5,exit_cost=100.,order=2,local_scale=.5):
    start=time.perf_counter()
    core=np.unique(np.r_[make_grid(n,True),np.arange(1.05,domain+1e-9,.05)])
    gx=gy=core
    if local_scale is not None:
        gx=np.unique(np.r_[core,np.arange(.001,.006+1e-10,.0001*local_scale)])
        gy=np.unique(np.r_[core,np.arange(.55,.95+1e-10,.005*local_scale)])
    grid=(gx,gy);u=np.linspace(0,10,nu)
    x,y=np.meshgrid(gx,gy,indexing='ij');nygrid=len(gy)
    stencil=[];fixed=np.zeros((nu,len(gx),len(gy)))
    for bx,by,c,w in branches(x[None],y[None],u[:,None,None],dt,sigma,order):
        if not (np.all(np.isfinite(bx)) and np.all(np.isfinite(by)) and np.all(np.isfinite(c))):
            raise ArithmeticError('Nonfinite transition; reduce the decision step')
        if np.any(bx<0) or np.any(by<0):
            raise ArithmeticError('Negative transition; reduce the decision step')
        i,j,a,b,out=setup(grid,bx,by)
        fixed+=w*(c+np.where(out,exit_cost+terminal(bx,by),0.))
        for di,dj,factor in [(0,0,(1-a)*(1-b)),(1,0,a*(1-b)),(0,1,(1-a)*b),(1,1,a*b)]:
            idx=((i+di)*nygrid+j+dj).astype(np.int32)
            weight=np.where(out,0.,w*factor)
            stencil.append((idx,weight))
    steps=round(50/dt)
    values=np.empty((steps+1,len(gx),len(gy)),dtype=np.float64)
    values[-1]=terminal(x,y)
    for k in range(steps-1,-1,-1):
        q=fixed.copy();flat=values[k+1].ravel()
        for idx,weight in stencil:
            q+=weight*flat[idx]
        values[k]=q.min(axis=0)
    params=dict(name=name,sigma=sigma,n=n,actual_grid=[len(gx),len(gy)],nu=nu,dt=dt,
                domain=domain,exit_cost=exit_cost,order=order,local_scale=local_scale)
    result=dict(parameters=params,solve_seconds=time.perf_counter()-start,
                initial_values={label:float(interpolate(values[0],setup(grid,*state))) for label,state in STATES.items()})
    return grid,u,values,result


def test_equivalence():
    from stochastic_reference import solve
    results=[]
    for order,sigma in [(2,0.),(2,.05),(3,.1)]:
        kw=dict(name='equivalence',n=11,nu=5,dt=.1,domain=1.25,order=order,sigma=sigma,local_scale=None)
        grid,u,v,r=solve(**kw)
        fastgrid,fu,fv,fr=solve_fast(**kw)
        diff=float(np.max(np.abs(v-fv)))
        assert diff<1e-10
        results.append(dict(order=order,sigma=sigma,max_full_history_error=diff))
    (ROOT/'pretraining_solver_equivalence.json').write_text(json.dumps(results,indent=2))
    print('Equivalent Bellman solver:',results,flush=True)


def run(case):
    config=CONFIGS[case]
    g,u,v,r=solve_fast(name='pretraining_'+case,**config)
    gx,gy=g
    # Full histories enable independent policy checks and future audit. Labels
    # are not released for training merely because a file has been generated.
    np.savez_compressed(ROOT/('pretraining_'+case+'_policy.npz'),gridx=gx,gridy=gy,
                        controls=u,values=v,parameters=json.dumps(r['parameters']))
    print(json.dumps(dict(case=case,solve_seconds=r['solve_seconds'],initial_values=r['initial_values'])),flush=True)
    if case!='higher_noise_coarser':
        r['simulations']={}
        for index,label in enumerate(('high_x','target','saddle')):
            # Fresh seeds, independent of the previous-stage Monte Carlo checks.
            s,c=simulate(g,u,v,r['parameters'],STATES[label],paths=256,seed=20262000+index,
                         h=.025,coupling_h=.0125)
            r['simulations'][label]=s
            np.save(ROOT/('pretraining_'+case+'_'+label+'_costs.npy'),c)
    (ROOT/('pretraining_'+case+'.json')).write_text(json.dumps(r,indent=2))
    print('Completed',case,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('case',choices=['test',*CONFIGS])
    args=parser.parse_args()
    if args.case=='test':test_equivalence()
    else:run(args.case)
