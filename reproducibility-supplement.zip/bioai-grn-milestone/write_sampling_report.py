"""Preserve all outcomes of the fixed-budget sampling ablation."""
import json
import zipfile
from targeted_sampling import ROOT,OUT,SEEDS,modelpath,sha

def read(n):return json.loads((OUT/n).read_text())

def main():
    train=read('training.json');freeze=read('pretest_freeze.json');result=read('test_results.json')
    assert len(train)==6 and set(train)==set(result['models'])
    assert sha(OUT/'data.npz')==freeze['data_sha256']
    assert sha(OUT/'validation.json')==freeze['validation_sha256']
    assert sha(ROOT/'TARGETED_SAMPLING_PROTOCOL.md')==freeze['protocol_sha256']
    for seed in SEEDS:
        for arm in ['baseline','targeted']:
            assert sha(modelpath(arm,seed))==freeze['models'][f'{arm}_{seed}']
        assert train[f'baseline_{seed}']['updates']==train[f'targeted_{seed}']['updates']
    prior=json.loads((ROOT/'NEURAL_REFERENCE_MANIFEST.json').read_text())
    for name,h in prior['source_sha256'].items():assert sha(ROOT/name)==h
    passed=result['targeted_all_seeds_passed']
    failures=[n for n,r in result['models'].items() if not r['passed']]
    base_focus=[result['models'][f'baseline_{s}']['focused']['fraction'] for s in SEEDS]
    target_focus=[result['models'][f'targeted_{s}']['focused']['fraction'] for s in SEEDS]
    edge=[result['models'][f'targeted_{s}']['standard']['time_0_0.1']['fraction'] for s in SEEDS]
    lines=['# Fixed-budget near-terminal sampling experiment','','3 November 2026','',
        f"Experiment complete. All-three-targeted-seed accuracy criterion: **{'PASS' if passed else 'FAIL'}**.",'',
        'Models missing one or more criteria: '+(', '.join(failures) or 'none')+'.','',
        f"Targeted-interval tolerance fractions changed from {min(base_focus):.2%}–{max(base_focus):.2%} "
        f"in baseline runs to {min(target_focus):.2%}–{max(target_focus):.2%} in targeted runs.",'',
        f"This is not uniform accuracy: the separate time<.1 subgroup achieved only "
        f"{min(edge):.2%}–{max(edge):.2%} in targeted runs. That subgroup was audited but "
        'was not a separate prespecified acceptance criterion. Long-time (10–50) MAE '
        'increased in all three targeted runs; the time-band table preserves that tradeoff. '
        'Overall MAE did not improve consistently even though tolerance fractions improved.','',
        'This experiment changes training-time coverage while holding the original network, '
        'weighted log-value loss, total sample count and optimization budget fixed. It is a '
        'value-approximation experiment, not a new closed-loop control evaluation.','',
        '## Controlled comparison','',
        'Each matched pair uses the original 1,377-parameter network, shared initial weights '
        '(seeds 63,64,65), baseline-derived normalization, identical batch orders '
        '(2963,2964,2965), 40,000 training samples and 200 epochs. Training states are '
        'identical between arms. Only 10,000 randomly selected remaining times are replaced '
        'by uniform [.1,.5) draws in the targeted arm, and their reference labels recomputed. '
        'This shifts coverage away from other times; those errors are also reported.','',
        f"Observed [.1,.5) training fractions: baseline {freeze['training_focus_fraction']['baseline']:.2%}; "
        f"targeted {freeze['training_focus_fraction']['targeted']:.2%}.",'',
        'Baseline training seed is 3901; replacement row/time seeds are 3906/3907. '
        'Both arms use the same 6,000-point standard-mixture validation set (3902) and '
        'checkpoint selection by weighted log-value loss every five epochs. No targeted '
        'validation objective or test-based checkpoint selection is used.','',
        'All six checkpoints, data and validation diagnostics were hashed before generating '
        'fresh final tests: 6,000 standard-mixture points (3903) and 4,000 targeted points '
        '(state/time seeds 3904/3905). Targeted tests retain the same state mixture but use '
        'times uniform in [.1,.5). The tests are reported separately, not pooled.','',
        '## Held-out accuracy','',
        'Each model must reach >=95% within .02+.05*abs(reference value) overall, in '
        'the standard test time<2 subgroup, and in the targeted test. Stage success '
        'requires every targeted-arm seed to pass all three components.','',
        '| Model | Overall | Time <2 | Targeted .1–.5 | All components |',
        '|---|---:|---:|---:|---|']
    for n,r in result['models'].items():
        lines.append(f"| {n} | {r['standard']['all']['fraction']:.2%} | {r['standard']['time_lt2']['fraction']:.2%} | {r['focused']['fraction']:.2%} | {'PASS' if r['passed'] else 'FAIL'} |")
    lines+=['','| Model | Standard MAE | Targeted MAE | Targeted maximum error | Selected epoch | Training seconds |',
            '|---|---:|---:|---:|---:|---:|']
    for n,r in result['models'].items():
        t=train[n]
        lines.append(f"| {n} | {r['standard']['all']['mae']:.6f} | {r['focused']['mae']:.6f} | {r['focused']['maximum']:.6f} | {t['selected_epoch']} | {t['seconds']:.2f} |")
    lines+=['','## Paired sampling effects','',
            'Negative error differences favor targeted sampling. Intervals describe approximate '
            'point-sampling uncertainty conditional on each trained pair; they exclude '
            'training-data, numerical-reference and model uncertainty. Shared test points '
            'make the seed comparisons dependent, and intervals are not multiplicity-adjusted.','',
            '| Seed | Test | MAE difference (targeted − baseline) | Approximate 95% interval | Tolerance-fraction difference |',
            '|---|---|---:|---|---:|']
    for seed,groups in result['paired'].items():
        for group,r in groups.items():
            d=r['absolute_error_difference'];lo,hi=d['approx_95ci']
            lines.append(f"| {seed} | {group} | {d['mean']:.6f} | [{lo:.6f}, {hi:.6f}] | {r['tolerance_fraction_difference']:+.2%} |")
    lines+=['','## Time-band tradeoffs','',
            '| Model | Standard-test time band | Points | MAE | Within tolerance |',
            '|---|---|---:|---:|---:|']
    for n,r in result['models'].items():
        for group in ['time_0_0.1','time_0.1_0.5','time_0.5_2','time_2_10','time_10_50']:
            g=r['standard'][group]
            lines.append(f"| {n} | {group} | {g['n']} | {g['mae']:.6f} | {g['fraction']:.2%} |")
    lines+=['','## Verification and interpretation','',
            'Assertions verified unchanged training-state coordinates, unchanged non-replaced '
            'rows and labels, equal optimizer-update counts, model/data/validation/protocol '
            'hashes and unchanged frozen reference sources. The reused network gradient '
            'check passed. All models, validation predictions, held-out predictions, training '
            'histories and individual failures are retained.','',
            'The intervention changes the effective training distribution, including time-feature '
            'statistics, while normalization is deliberately fixed. No loss-weight or architecture '
            'change is included, so any observed difference belongs to this sampling intervention '
            'under these paired seeds and fixed settings. Three seeds on one dataset do not '
            'establish general robustness. Exact endpoint matching in the original network '
            'remains a pointwise override, not a continuous-boundary guarantee.','',
            'No newly trained model has been tested in closed-loop trajectories here. Earlier '
            'control results apply to earlier models only. Value-screen success would justify '
            'a separate fresh control evaluation, not a claim of improved intervention cost. '
            'If the stricter value screen fails, keep the failure and diagnose it using '
            'training/validation data before another prespecified ablation with fresh tests. '
            'No biological effectiveness, continuous optimality, derivative accuracy or '
            'runtime advantage is established.','',
            '## Reproduction','',
            'With Python/NumPy and the frozen reference archive, set OPENBLAS_NUM_THREADS=1 '
            'and OMP_NUM_THREADS=1, then run:', '',
            '    python targeted_sampling.py',
            '    python write_sampling_report.py','',
            'The portable package includes source, protocols, all models and raw evidence. '
            'Large teacher archives are omitted; retain the local reference or regenerate '
            'it using earlier-stage scripts. Preserve the two sibling source directories.','']
    (ROOT/'TARGETED_SAMPLING_RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    manifest=dict(experiment_complete=True,targeted_all_seeds_passed=passed,
        reference_sha256=prior['sha256'],files={str(p.relative_to(ROOT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()},
        source_sha256={n:sha(ROOT/n) for n in ['targeted_sampling.py','write_sampling_report.py','matched_architecture.py','neural_pilot.py','TARGETED_SAMPLING_PROTOCOL.md']})
    (ROOT/'TARGETED_SAMPLING_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    package=ROOT.parent/'bioai-targeted-sampling-package.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in [ROOT.parent/'bioai-baseline',ROOT]:
            for p in sorted(folder.rglob('*')):
                allowed_npz=p.name.startswith('neural_') or any(part in {'terminal_multiseed','matched_architecture','targeted_sampling'} for part in p.parts)
                if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.md','.json','.csv','.npy'} or (p.suffix=='.npz' and allowed_npz)):
                    z.write(p,p.relative_to(ROOT.parent))
        z.writestr('PACKAGE_README.md','Start at bioai-grn-milestone/TARGETED_SAMPLING_RESULTS.md. Includes six new models, raw data and predictions, source and prior lightweight evidence. Large teacher archives omitted. This milestone tests values only. Requires Python and NumPy; preserve sibling folder names.\n')
    with zipfile.ZipFile(package) as z:assert z.testzip() is None
    print('Complete. Targeted all-seed criterion:',passed)
    print('Verified package:',package)

if __name__=='__main__':main()
