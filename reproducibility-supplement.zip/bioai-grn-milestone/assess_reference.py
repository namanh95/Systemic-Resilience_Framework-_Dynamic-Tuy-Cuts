"""Evaluate the declared numerical consistency gate and independent replay."""
import json
import numpy as np
from reference_control import ROOT,TARGET,INITIAL,A1,A2,interp,interp_setup
from toggle_benchmark import rk4


def replay(name,dt):
    rows=np.loadtxt(ROOT/(name+'.csv'),delimiter=',',skiprows=1)
    state=INITIAL*np.array([A1,A2]);total=0.
    parts=round(dt/.005);h=dt/parts
    for row in rows:
        z=float(row[3])
        for _ in range(parts):
            before=float(np.sum((state/np.array([A1,A2])-TARGET)**2)+.01*z*z)
            state=np.array(rk4(state,z,h))
            after=float(np.sum((state/np.array([A1,A2])-TARGET)**2)+.01*z*z)
            total+=h*(before+after)/2
    return total+10*float(np.sum((state/np.array([A1,A2])-TARGET)**2))


def main():
    results=json.loads((ROOT/'improved_reference_results.json').read_text())
    assert len(results)==6
    base=results[2]
    diagnostics={}
    for label,index in [('space',3),('control',4),('time',5)]:
        r=results[index]
        diagnostics[label]={key:abs(r[key]-base[key])/abs(r[key]) for key in ['initial_value','rollout_cost']}
    discrepancies=[abs(r['value_rollout_difference'])/r['rollout_cost'] for r in results[1:]]
    passed=all(v<=.01 for d in diagnostics.values() for v in d.values()) and max(discrepancies)<=.01
    representative=results[3]
    independent_cost=replay(representative['name'],representative['dt'])
    replay_difference=abs(independent_cost-representative['rollout_cost'])
    assert replay_difference<1e-5
    direct=json.loads((ROOT/'refined_shooting_results.json').read_text())
    # Exploratory off-grid value comparison, additional to the initial-state gate.
    hx,hy=np.meshgrid(np.linspace(.01,.99,11),np.linspace(.01,.99,11),indexing='ij')
    base_file=np.load(ROOT/(base['name']+'.npz'))
    bv=interp(base_file['value0'],interp_setup(base_file['grid'],hx,hy))
    holdouts={}
    for label,index in [('space',3),('control',4),('time',5)]:
        f=np.load(ROOT/(results[index]['name']+'.npz'))
        fv=interp(f['value0'],interp_setup(f['grid'],hx,hy))
        differences=np.abs(fv-bv)
        holdouts[label]=dict(max_absolute=float(differences.max()),
                            max_scaled=float(np.max(differences/(.01+.01*np.abs(fv)))),
                            points_exceeding_scaled_tolerance=int(np.sum(differences>.01+.01*np.abs(fv))))
    report=dict(gate_threshold=.01,gate_passed=passed,relative_refinement_changes=diagnostics,
                max_aligned_value_rollout_relative_difference=max(discrepancies),
                replay_cost=independent_cost,replay_difference=replay_difference,
                direct_shooting_cost=direct['cost_dt00125'],
                exploratory_121_state_checks=holdouts,
                direct_vs_feedback_relative_difference=abs(direct['cost_dt00125']-independent_cost)/independent_cost,
                scope='Numerical consistency at the specified initial state; not an optimality certificate or uniform-state convergence.')
    (ROOT/'numerical_assessment.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
