# Gene-regulatory milestone: model selection and control specification

2 November 2026

## Decision and provenance

Select the two-state Gardner genetic toggle switch rather than the previously
suggested repressilator. A bistable switching objective and two-dimensional
state space make it a manageable first reference-control problem.

The published circuit uses mutual repression and induction to switch state:
[Gardner, Cantor and Collins, Nature (2000)](https://www.nature.com/articles/35002131).
Equations and numerical parameters below follow the public
[BIOMD0000000507 model export](https://www.imagwiki.nibib.nih.gov/sites/default/files/jsim/models/biomodels/BIOMD0000000507.mod).
This is a transcription of that parameterization, not a new experimental fit.
The source inducer is fixed at zero; making it a time-dependent control is our extension.

## Model and intervention

Let x,y be the source model's scaled repressor states. Let z=I/K denote
normalized inducer, with K=2.9618e-5 in the source concentration convention.
Use model time, without interpreting the generic export's unit labels as an
experimentally validated physical clock.

    dx/dt = 156.25/(1+y^2.5) - x = b1(x,y)
    dy/dt = 15.6/(1+x/(1+z)^2.0015) - y = b2(x,y,z)

The inducer reduces active repression by x. Initial state is the high-x stable
equilibrium; desired state is the low-x equilibrium. The proposed research
control bound 0<=z<=10 is an illustrative computational limit, not a measured
safe or feasible laboratory limit. Actuator dynamics and measurement delays
are omitted initially and must be addressed before experimental interpretation.

## Deterministic verification completed

At zero inducer, numerical equilibrium search gives:

| x | y | Classification |
|---:|---:|---|
| 0.33241859 | 11.70803240 | locally asymptotically stable |
| 1.31654607 | 6.73416350 | saddle |
| 155.76340774 | 0.09951302 | locally asymptotically stable |

Residuals are below 1e-10. Jacobian eigenvalues are in verification.json.
The equilibrium scan is numerical, not a formal enumeration proof.
The rectangle [0,156.25] x [0,15.6] is invariant for the ODE: production
is nonnegative and bounded by its synthesis maximum, so drift is inward or
tangent on each boundary. The drift is locally Lipschitz on this domain.

RK4 simulation from the high-x equilibrium used z=10 for 0<=t<5 and zero
afterward, through T=50. Endpoint: (0.33245900,11.70758232), within 0.000452
Euclidean distance of the low-x equilibrium. The uncontrolled trajectory remains
at its initial equilibrium. Halving dt from .01 to .005 changes the pulse
trajectory by at most 1.223e-6 in either coordinate at common sample times.
No state clipping is used. These are numerical checks, not interval enclosures.

An exploratory amplitude-4 pulse evaluated at T=20 did not meet the desired
endpoint test. Amplitude 10 and T=50 were selected as an illustrative successful
baseline; no minimum-amplitude or optimal-duration claim is made.

## Proposed stochastic extension and admissibility

For independent Brownian motions, propose

    dX = b1(X,Y) dt + sigma1 X dW1
    dY = b2(X,Y,z) dt + sigma2 Y dW2.

This introduces multiplicative environmental noise, not an experimentally fitted
intrinsic molecular-noise model. Start with sigma1=sigma2=0.05 and sensitivity
runs at 0 and 0.1; these values are research assumptions.

For progressively measurable bounded z, local Lipschitz coefficients and bounded
production terms give a nonexplosive strong solution. The integrating-factor
representation of each linear decay/multiplicative-noise equation, with positive
production forcing, preserves nonnegativity (strict positivity from positive
initial states). A linear-growth moment estimate gives finite second moments on
finite horizons. These are model-level arguments to expand into a formal lemma.
Unlike the ODE, this SDE is NOT confined to the deterministic rectangle.
Numerical SDE methods need their own positivity treatment; RK4 here is ODE-only.

## Finite-horizon control problem

Define normalized target discrepancy

    D(x,y) = ((x-x_target)/156.25)^2 + ((y-y_target)/15.6)^2.

For T=50 and r=0.01, propose

    J(z) = E[ integral_0^T (D(Xt,Yt) + r*z_t^2) dt + 10*D(XT,YT) ].

Targets are the uncontrolled low-x equilibrium. Weights, horizon, and control
limits are explicit design choices. Finite moments make this cost integrable.
This objective penalizes time away from the desired state and intervention use;
it does not guarantee switch persistence after the evaluation horizon.

The HJB target is

    -V_t = min_{0<=z<=10} {D + r*z^2 + b1 V_x + b2 V_y
              + (sigma1^2*x^2 V_xx + sigma2^2*y^2 V_yy)/2},
    V(T,x,y) = 10 D(x,y).

Use a viscosity formulation unless sufficient classical regularity is established.
No HJB solution, optimal feedback, or neural approximation is delivered here.

## Connection to certified selection

At a fixed state and derivative p=V_y, only

    f(z) = r*z^2 + p*g(z),
    g(z) = A2*(1+z)^eta / ((1+z)^eta+x)

depends on control. For x>=0, g is nondecreasing. Thus on [l,h],

    L = r*l^2 + p*g(l)  if p>=0,
    L = r*l^2 + p*g(h)  if p<0

is a valid real-arithmetic lower bound. If p>=0, zero is already a global
minimizer. For p<0, tradeoffs may require search. Specifically,

    g''(z) = A2*eta*x*(1+z)^(eta-2)
      *[(eta-1)*x-(eta+1)*(1+z)^eta]
      /[((1+z)^eta+x)^3].

Consequently f''=2r+p*g'' need not be nonnegative. This establishes possible
nonconvexity, not multiple local minima or nonconvexity along a solved policy.
Inspect stationary roots and boundaries before assuming branch-and-bound is
necessary. The fixed-state example x=155.7634,p=-1,z=0 has negative f''.

The previous exact-rational solver cannot directly certify fractional powers.
The next implementation must supply outward-rounded enclosures for these
powers and incumbent values. Do not replace 2.0015 by 2 solely for convenience,
or label ordinary floating-point evaluations certified. With an interval-valued
incumbent, use its upper endpoint for pruning and stopping.

## Next execution milestone and acceptance criteria

1. Implement validated power bounds and test this GRN Hamiltonian selector.
2. Solve the deterministic finite-horizon reference problem on successively finer
   grids, exploiting the invariant rectangle and appropriate state constraints.
3. Add stochastic reference computation with expanded domains and explicit
   truncation-boundary sensitivity checks; do not reuse the ODE rectangle as a
   reflecting SDE boundary.
4. Compare feedback to zero control and the recorded pulse, reporting cost,
   intervention use, switch success, uncertainty, and refinement errors.
5. Introduce neural approximation only after reference solutions are stable
   under refinement. Sampled residuals alone are not performance certificates.

## Files and reproduction

Run `python toggle_benchmark.py` using Python 3; no external packages required.
This regenerates uncontrolled.csv, pulse.csv, and verification.json. The script
checks equilibrium classifications, boundary signs, trajectory nonnegativity,
step halving, and the selected pulse endpoint. Results concern this mathematical
model; they are not a reproduction of measured experimental trajectories.

The milestone establishes a sourced model, explicit intervention and objective,
admissibility reasoning, and deterministic reference checks. It does not yet
establish optimal control, stochastic performance, or a novel research result.
