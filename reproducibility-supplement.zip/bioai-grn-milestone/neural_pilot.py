"""NumPy-only supervised value network and independent closed-loop test."""
import argparse
import hashlib
import json
import time
import numpy as np
from stochastic_reference import ROOT,STATES,setup,interpolate,terminal,branches,summary,simulate
from refined_control import flow


def teacher():
    manifest=json.loads((ROOT/'NEURAL_REFERENCE_MANIFEST.json').read_text())
    path=ROOT/manifest['candidate_file'];digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
    assert digest.hexdigest()==manifest['sha256']
    f=np.load(path)
    return (f['gridx'],f['gridy']),f['controls'],f['values'],json.loads(str(f['parameters']))


def features(points):
    x,y,tau=points.T
    return np.column_stack([x,y,np.log1p(156.25*x)/np.log(157.25),
        np.log1p(15.6*y)/np.log(16.6),tau/50,np.exp(-tau),np.exp(-tau/5),terminal(x,y)/10])


def samples(seed,n,grid,values):
    rng=np.random.default_rng(seed);p=rng.uniform(0,1.2,(n,3));q=rng.random(n)
    near=q<.4;transition=(q>=.4)&(q<.6)
    p[near,0]=rng.uniform(.001,.006,near.sum());p[near,1]=rng.uniform(.55,.95,near.sum())
    p[transition,0]=rng.uniform(0,.05,transition.sum());p[transition,1]=rng.uniform(0,1,transition.sum())
    q=rng.random(n);p[:,2]=np.where(q<.3,rng.uniform(0,2,n),np.where(q<.6,rng.uniform(2,10,n),rng.uniform(10,50,n)))
    tf=(50-p[:,2])/.1;k=np.minimum(tf.astype(int),499);a=tf-k
    i,j,b,c,_=setup(grid,p[:,0],p[:,1])
    def at(kk):
        return (1-b)*(1-c)*values[kk,i,j]+b*(1-c)*values[kk,i+1,j]+(1-b)*c*values[kk,i,j+1]+b*c*values[kk,i+1,j+1]
    return p,(1-a)*at(k)+a*at(k+1)


class Network:
    def __init__(self,mean,scale,seed=42):
        self.mean=mean;self.scale=scale;rng=np.random.default_rng(seed)
        self.params=[rng.normal(0,np.sqrt(2/(8+32)),(8,32)),np.zeros(32),
                     rng.normal(0,np.sqrt(1/32),(32,32)),np.zeros(32),
                     rng.normal(0,np.sqrt(1/32),(32,1)),np.zeros(1)]

    def forward(self,x):
        w,b,v,c,o,d=self.params
        h=np.tanh(x@w+b);g=np.tanh(h@v+c);out=(g@o+d).ravel()
        return out,(x,h,g)

    def loss_gradient(self,x,target,weight):
        out,(x,h,g)=self.forward(x);error=out-target
        loss=np.mean(weight*error*error);delta=(2*weight*error/len(x))[:,None]
        go=g.T@delta;gd=delta.sum(axis=0)
        dg=(delta@self.params[4].T)*(1-g*g)
        gv=h.T@dg;gc=dg.sum(axis=0)
        dh=(dg@self.params[2].T)*(1-h*h)
        return float(loss),[x.T@dh,dh.sum(axis=0),gv,gc,go,gd]

    def predict(self,x,y,tau):
        x,y,tau=np.broadcast_arrays(x,y,tau);shape=x.shape
        p=np.column_stack([x.ravel(),y.ravel(),tau.ravel()])
        raw,_=self.forward((features(p)-self.mean)/self.scale)
        pred=np.expm1(np.clip(raw,0,10)).reshape(shape)
        return np.where(tau<=1e-12,terminal(x,y),pred)

    def save(self,path):np.savez(path,mean=self.mean,scale=self.scale,**{f'p{i}':p for i,p in enumerate(self.params)})

    @classmethod
    def load(cls,path):
        f=np.load(path);model=cls(f['mean'],f['scale']);model.params=[f[f'p{i}'] for i in range(6)];return model


def gradient_test():
    model=Network(np.zeros(8),np.ones(8));rng=np.random.default_rng(91)
    x=rng.normal(size=(7,8));y=rng.normal(size=7);w=rng.uniform(.5,2,7)
    _,grads=model.loss_gradient(x,y,w)
    for p,g in zip(model.params,grads):
        index=tuple(0 for _ in p.shape);old=p[index];eps=1e-6
        p[index]=old+eps;plus=model.loss_gradient(x,y,w)[0]
        p[index]=old-eps;minus=model.loss_gradient(x,y,w)[0];p[index]=old
        assert abs((plus-minus)/(2*eps)-g[index])<1e-6


def train():
    gradient_test();grid,u,values,p=teacher();start=time.perf_counter()
    trainp,trainv=samples(901,40000,grid,values);valp,valv=samples(902,6000,grid,values)
    f=features(trainp);mean=f.mean(axis=0);scale=f.std(axis=0);scale=np.maximum(scale,1e-6)
    model=Network(mean,scale);x=(f-mean)/scale;y=np.log1p(trainv);weight=1/(.1+y)
    vx=(features(valp)-mean)/scale;vy=np.log1p(valv);vw=1/(.1+vy)
    ms=[np.zeros_like(a) for a in model.params];vs=[np.zeros_like(a) for a in model.params]
    rng=np.random.default_rng(904);best=float('inf');best_epoch=0;step=0;history=[]
    for epoch in range(1,201):
        order=rng.permutation(len(x));lr=.001*(.4 if epoch>120 else 1.)
        for begin in range(0,len(x),512):
            ix=order[begin:begin+512];loss,grads=model.loss_gradient(x[ix],y[ix],weight[ix]);step+=1
            for k,(param,g) in enumerate(zip(model.params,grads)):
                ms[k]=.9*ms[k]+.1*g;vs[k]=.999*vs[k]+.001*g*g
                param-=lr*(ms[k]/(1-.9**step))/(np.sqrt(vs[k]/(1-.999**step))+1e-8)
        if epoch%5==0:
            raw,_=model.forward(vx);loss=float(np.mean(vw*(raw-vy)**2))
            history.append(dict(epoch=epoch,validation_loss=loss))
            if loss<best:
                best=loss;best_epoch=epoch;model.save(ROOT/'neural_value_model.npz')
            if epoch%20==0:print('epoch',epoch,'validation',loss,'best',best,flush=True)
            if epoch-best_epoch>=40:break
    # Test set is generated/evaluated only after selecting the validation checkpoint.
    model=Network.load(ROOT/'neural_value_model.npz');testp,testv=samples(903,6000,grid,values)
    predictions=model.predict(*testp.T);error=np.abs(predictions-testv)
    metrics=dict(mae=float(error.mean()),rmse=float(np.sqrt(np.mean(error**2))),
        max_absolute=float(error.max()),p95_absolute=float(np.quantile(error,.95)),
        fraction_within_pilot_tolerance=float(np.mean(error<=.02+.05*np.abs(testv))))
    metrics['value_screen_passed']=metrics['fraction_within_pilot_tolerance']>=.95
    near=(testp[:,0]>=.001)&(testp[:,0]<=.006)&(testp[:,1]>=.55)&(testp[:,1]<=.95)
    metrics['near_target_mae']=float(error[near].mean())
    assert np.max(np.abs(model.predict(testp[:,0],testp[:,1],0)-terminal(testp[:,0],testp[:,1])))<1e-12
    np.savez_compressed(ROOT/'neural_heldout_values.npz',points=testp,reference=testv,prediction=predictions)
    result=dict(architecture=[8,32,32,1],parameters=sum(a.size for a in model.params),best_epoch=best_epoch,
                epochs_run=epoch,training_seconds=time.perf_counter()-start,history=history,test=metrics,
                training_seed=901,validation_seed=902,test_seed=903,
                reference_parameters=p,method='Supervised value regression; not physics-informed training')
    (ROOT/'neural_training_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(metrics),flush=True)


def choose_neural(model,u,state,tau,p):
    q=0.
    for x,y,c,w in branches(state[:,0][None],state[:,1][None],u[:,None],p['dt'],p['sigma'],p['order']):
        q=q+w*(c+model.predict(x,y,tau-p['dt']))
    z=u[np.argmin(q,axis=0)];outside=np.any((state<0)|(state>1.2),axis=1)
    return np.where(outside,0.,z),outside


def neural_rollout(model,u,p,initial,seed):
    paths=256;state=np.tile(initial,(paths,1));cost=np.zeros(paths);dose=np.zeros(paths)
    rng=np.random.default_rng(seed);fallback=np.zeros(paths,dtype=bool);steps=round(50/p['dt']);start=time.perf_counter()
    for k in range(steps):
        z,outside=choose_neural(model,u,state,50-k*p['dt'],p);fallback|=outside;dose+=p['dt']*z*z
        for _ in range(4):
            x,y,ca=flow(state[:,0],state[:,1],z,.0125)
            normal=rng.standard_normal((1,paths,2)).sum(axis=0)
            fac=np.exp(-.5*p['sigma']**2*.025+p['sigma']*np.sqrt(.025)*normal)
            x,y,cb=flow(x*fac[:,0],y*fac[:,1],z,.0125);state=np.column_stack([x,y]);cost+=ca+cb
            assert np.all(np.isfinite(state)) and np.all(state>=0)
    cost+=terminal(state[:,0],state[:,1])
    return dict(cost=summary(cost),integral_z_squared=summary(dose),fallback_paths=int(fallback.sum()),
                final_target_distance=summary(np.linalg.norm(state-np.asarray(STATES['target']),axis=1)),
                seconds=time.perf_counter()-start),cost


def evaluate():
    grid,u,v,p=teacher();model=Network.load(ROOT/'neural_value_model.npz');results={}
    for i,label in enumerate(('high_x','target','saddle','mixed')):
        seed=20263000+i;start=time.perf_counter()
        ref,rc=simulate(grid,u,v,p,STATES[label],paths=256,seed=seed,h=.025)
        ref['seconds']=time.perf_counter()-start
        nn,nc=neural_rollout(model,u,p,STATES[label],seed)
        paired=summary(nc-rc);limit=.01+.05*ref['cost']['mean']
        results[label]=dict(reference=ref,neural=nn,paired_neural_minus_reference=paired,
                            tolerance=limit,policy_screen_passed=paired['approx_95ci'][1]<=limit,seed=seed)
        np.savez(ROOT/('neural_rollout_'+label+'.npz'),reference=rc,neural=nc)
        (ROOT/'neural_rollout_results.json').write_text(json.dumps(results,indent=2))
        print(label,json.dumps(results[label]),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['train','evaluate']);args=parser.parse_args()
    train() if args.mode=='train' else evaluate()
