"""Publish readiness findings without turning empirical checks into guarantees."""
import hashlib
import json
import csv
from pretraining_assessment import read
from stochastic_reference import ROOT,STATES


def main():
    a=read('pretraining_assessment');old=read('stochastic_local0p5')
    cases={k:read('pretraining_'+k) for k in ('time','control','quadrature','higher_noise','higher_noise_coarser')}
    holdout_pass=all(r['exceedances']==0 for r in a['exploratory_holdouts'].values())
    nominal_values=all(a['value_screens'][k]['passed'] for k in ('time','control','quadrature'))
    nominal_mc=all(r['passed'] for k,d in a['value_mc_agreement'].items() if k!='higher_noise' for r in d.values())
    ready=nominal_values and nominal_mc and holdout_pass
    lines=['# Stochastic reference assessment before neural training', '', '2 November 2026', '',
           '## Decision', '',
           ('The nominal sigma=.05 reference passes the declared empirical checks and the additional '
            'sampled-value audit. It is suitable for a LIMITED numerical neural-approximation pilot, '
            'with independent policy simulation and comparison against these reference tolerances.' if ready else
            'The nominal sigma=.05 reference does not pass every required check. Do not release it '
            'as a validated neural-training reference; the failed conditions below need resolution.'), '',
           'No neural training was performed. Passing here does not certify a continuous optimal '
           'policy, value derivatives, uniform convergence, or biological validity. The scope is the '
           'specified synthetic-noise model, finite horizon, tested states/times, and selected costs.', '',
           '## Protocol and computational checks', '',
           'PRETRAINING_PROTOCOL.md was written before the new results. For six existing initial '
           'states, a numerical change passes if it is at most .005+.01*abs(refined value). '
           'Value/Monte Carlo agreement is screened separately using .005+.01*abs(MC mean) '
           '+1.96*MC standard error. These are practical acceptance criteria, not error theorems.', '',
           'A precomputed sparse-interpolation stencil accelerates the existing Bellman update '
           'without changing its method. Three full-history comparisons against the original solver '
           'give maximum difference below 2.2e-14. Finite and nonnegative transition guards reject '
           'invalid numerical transitions. All production decision steps are .1 or .05.', '',
           'All nominal refinements retain local_scale=.5, the 178-by-238 grid, domain 1.5, '
           'exit payoff 100, and the same biological coefficients and objective. Baseline: '
           '31 controls, decision step .1, two quadrature nodes per noise coordinate. '
           'Each comparison changes one parameter. Higher-noise spatial checks use sigma=.10.', '',
           '## Prespecified numerical value checks', '',
           '| Check | Maximum value change | Maximum tolerance ratio | Result |',
           '|---|---:|---:|---|']
    for k,r in a['value_screens'].items():
        lines.append(f"| {k} | {r['max_absolute']:.7f} | {r['max_tolerance_ratio']:.4f} | {'PASS' if r['passed'] else 'FAIL'} |")
    lines+=['', 'Time halves the decision step to .05; control doubles intervals from 30 to 60 '
            '(61 candidates); quadrature uses three nodes per coordinate instead of two. '
            'Higher-noise compares local spacings (.0001,.005) with (.00005,.0025).', '',
            '| Configuration | High-x value | Target value | Saddle value |', '|---|---:|---:|---:|']
    for label,r in [('existing nominal',old),*cases.items()]:
        v=r['initial_values'];lines.append(f"| {label} | {v['high_x']:.7f} | {v['target']:.7f} | {v['saddle']:.7f} |")
    lines+=['', '## Fresh Monte Carlo checks', '',
            'Each new policy is evaluated from high-x, target, and saddle on 256 fresh Brownian '
            'paths per state, with seeds distinct from the previous stage. Common fine increments '
            'are used for paired comparisons. Integration uses .025 steps; the existing local '
            'reference is also replayed with .0125 steps. Confidence intervals cover sampling '
            'uncertainty only, not numerical or model error.', '',
            '| Configuration | State | Grid value | MC mean | Approximate 95% MC interval | Agreement |',
            '|---|---|---:|---:|---|---|']
    for case,states in a['value_mc_agreement'].items():
        for label,r in states.items():
            lo=r['mc_mean']-1.96*r['mc_se'];hi=r['mc_mean']+1.96*r['mc_se']
            lines.append(f"| {case} | {label} | {r['dp_value']:.6f} | {r['mc_mean']:.6f} | [{lo:.6f}, {hi:.6f}] | {'PASS' if r['passed'] else 'FAIL'} |")
    lines+=['', 'The acceptance tolerance includes an explicit numerical allowance; PASS does not '
            'mean the grid value lies inside the Monte Carlo interval. The MC cost belongs to the '
            'implemented policy, not the unknown optimal policy.', '',
            '### Paired policy-cost changes from the existing nominal reference', '',
            '| Refinement | State | Mean cost difference | Approximate paired 95% interval |',
            '|---|---|---:|---|']
    for case,states in a['paired_refinement_minus_baseline'].items():
        for label,r in states.items():
            ci=r['approx_95ci'];lines.append(f"| {case} | {label} | {r['mean']:.7f} | [{ci[0]:.7f}, {ci[1]:.7f}] |")
    lines+=['', 'These changes may be small but statistically detectable; do not equate numerical '
            'similarity with identical policies or treat small improvements as proof of global optimality.', '',
            '### Coupled simulation-step check', '',
            '| State | Mean fine-minus-coarse cost | Paired 95% interval |', '|---|---:|---|']
    for label,r in a['coupled_integration'].items():
        s=r['paired_fine_minus_coarse'];ci=s['approx_95ci']
        lines.append(f"| {label} | {s['mean']:.7f} | [{ci[0]:.7f}, {ci[1]:.7f}] |")
    lines+=['', '## Exploratory off-grid value audit', '',
            'In addition to the protocol, compare 128 new states (64 spread over the unit square '
            'and 64 in the locally refined region) at times 0,10,25,40,49. Seed: 271828. '
            'This gives 640 value comparisons per numerical refinement. The .005+.01*abs(value) '
            'tolerance is reported descriptively; this was not a prespecified statistical test.', '',
            '| Refinement | Maximum absolute difference | Maximum scaled difference | Exceedances |',
            '|---|---:|---:|---:|']
    for k,r in a['exploratory_holdouts'].items():
        lines.append(f"| {k} | {r['max_absolute']:.7f} | {r['max_scaled']:.4f} | {r['exceedances']}/{r['comparisons']} |")
    lines+=['', '## Scope of the next learning experiment', '',
            'If the nominal readiness criteria pass, use the 61-control nominal run as the '
            'candidate reference. Keep the other numerical resolutions as comparators. A first '
            'experiment should assess learned VALUE approximation and independently simulated '
            'policy performance. Do not assume that accurate values imply accurate gradients or '
            'that derivative labels have been validated.', '',
            'The high-noise case has only a local spatial check and Monte Carlo agreement in this '
            'stage; it has not received the same time/control/quadrature suite. Full joint refinement '
            '(all three settings improved together), broader state/time coverage, derivative-error '
            'analysis, and stronger stochastic truncation guarantees remain outside the readiness '
            'claim. Existing certified Hamiltonian selection does not certify these PDE values.', '',
            'No new clinical, experimental, or biological calibration evidence was introduced. '
            'All control and noise conclusions remain conditional on the stated mathematical model.', '',
            '## Reproduction', '',
            'Python and NumPy are required. The existing stochastic_local0p5_policy.npz is an '
            'input; regenerate it with stochastic_local.py if needed. Then run:', '',
            '    python pretraining_validation.py test',
            '    python pretraining_baseline.py',
            '    python pretraining_validation.py time',
            '    python pretraining_validation.py control',
            '    python pretraining_validation.py quadrature',
            '    python pretraining_validation.py higher_noise_coarser',
            '    python pretraining_validation.py higher_noise',
            '    python pretraining_assessment.py',
            '    python write_pretraining_report.py', '',
            'Large policy archives store complete value histories. Small .npy files contain paired '
            'path costs; JSON files contain parameters, means, intervals, and diagnostics. '
            'NEURAL_REFERENCE_MANIFEST.json records the readiness decision and candidate file hash. '
            'A passing decision supports a scoped empirical comparison, not a statement '
            'that any neural model has been trained or validated.', '']
    (ROOT/'PRETRAINING_RESULTS.md').write_text('\n'.join(lines))
    path=ROOT/'pretraining_control_policy.npz';digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(8*1024*1024),b''):digest.update(chunk)
    manifest=dict(neural_training_started=False,nominal_pilot_ready=ready,
                  candidate_file=path.name,sha256=digest.hexdigest(),
                  source_sha256={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                                 ('toggle_benchmark.py','refined_control.py','stochastic_reference.py','pretraining_validation.py')},
                  parameters=cases['control']['parameters'],
                  approved_scope='Limited empirical value-approximation and policy-simulation pilot at sigma=.05 only' if ready else 'Not released; resolve failed checks',
                  unvalidated=['Value derivatives','Uniform convergence','Continuous global optimality','Joint refinement','Biological effectiveness'])
    (ROOT/'NEURAL_REFERENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
