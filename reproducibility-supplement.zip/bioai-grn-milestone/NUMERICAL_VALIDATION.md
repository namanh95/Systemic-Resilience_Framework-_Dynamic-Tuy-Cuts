# Deterministic reference: numerical uncertainty investigation

Completed 2 November 2026

## Outcome

The improved deterministic reference passes the declared numerical consistency
gate for the specified initial condition. Spatial, control-grid, and decision-time
refinements change both its initial value and executable policy cost by less than
0.04%. This supports its use as a computational benchmark. It does not establish
a rigorous error bound, continuous global optimality, or stochastic performance.

The physical model, horizon 50, target, intervention limits, and cost weights
remain those in RESEARCH_SPEC.md. No neural model was trained.

## Identified issue and changes

The earlier grids omitted the equilibria. At the target, the exact deterministic
value is zero: zero control keeps the state fixed, and all running and terminal
costs vanish. A 71-point unaligned grid with the new RK4 transitions instead
estimated the target value as 0.0426964. Adding equilibrium coordinates gives
zero at that target. Thus grid interpolation around fixed points was a material
source of numerical bias, not evidence of a biological control effect.

Three changes were implemented:

1. RK4 state transitions and RK4 integration of the running cost replace Euler
   transitions and left-endpoint cost integration.
2. Grids include both normalized coordinates of all three equilibria, including
   the saddle. The grid remains graded toward small concentrations.
3. At each simulated state, feedback minimizes the off-grid discrete Bellman
   expression using the next value surface. It no longer interpolates control
   argmins from surrounding grid nodes.

The numerical state space remains the deterministic invariant rectangle. The
transition checks pass without clipping states. These modifications are in
refined_control.py; the earlier experiments are preserved separately.

## Matched comparison and refinements

All runs below use RK4 transitions and Bellman-greedy feedback. “Base grid” is
the original point count per coordinate; aligned grids add six equilibrium
coordinates, giving actual counts 77, 107, and 147.

| Base grid | Aligned | Control candidates | Decision step | Initial DP value | Simulated policy cost |
|---:|:---:|---:|---:|---:|---:|
| 71 | No | 41 | .10 | 2.502640 | 2.464755 |
| 71 | Yes | 41 | .10 | 2.465900 | 2.463131 |
| 101 | Yes | 41 | .10 | 2.464621 | 2.463229 |
| 141 | Yes | 41 | .10 | 2.464046 | 2.463102 |
| 101 | Yes | 81 | .10 | 2.463902 | 2.462344 |
| 101 | Yes | 41 | .05 | 2.465330 | 2.462477 |

The matched 71-point comparison reduces the value/rollout discrepancy from
1.537% to 0.1124%. Because alignment also adds six nodes, this comparison is
not an equal-node-count runtime benchmark.

Before these runs, the script declared a diagnostic gate: relative differences
of at most 1% in initial value and rollout cost under separate refinements,
and at most 1% value-versus-rollout discrepancy. This is a practical numerical
criterion, not a theorem or a statistical confidence interval.

Using the aligned base-101, 41-control, .10-step run as the common reference:

| Separate refinement | Initial-value change | Policy-cost change |
|---|---:|---:|
| Spatial grid: base 101 to 141 | 0.02334% | 0.00517% |
| Controls: 41 to 81 | 0.02922% | 0.03594% |
| Decision step: .10 to .05 | 0.02875% | 0.03054% |

The largest value/rollout discrepancy among aligned runs is 0.1159%. All gate
conditions pass. Values are not monotone in time step; decreasing decision time
on a fixed spatial grid is not by itself a convergence proof.

## Additional checks

At 121 off-grid points on an 11-by-11 lattice in [.01,.99]^2, the maximum absolute
initial-value changes are .00066381 (space), .00071347 (controls), and .00233913
(time). None exceeds the exploratory threshold .01+.01*abs(refined value).
This additional threshold is exploratory, not the predeclared initial-state gate.
Finite sampled-state checks cannot establish uniform convergence over the domain
or accuracy at every time. Derivatives have not been validated by this check.

Replaying the base-141 policy's recorded schedule using the earlier physical-state
RK4 implementation with step .005 and trapezoidal cost integration gives
2.46309640, versus 2.46310158 from the new rollout. Difference: 5.181e-6.
The replay checks the integration and cost accounting for the same schedule;
it does not independently recompute the feedback decisions.

Other checks verify exact stationary behavior of the equilibria numerically,
zero cost at the target, nonnegative running costs, transitions within the
domain on a sampled grid, and reproduction of affine functions by interpolation.

## Comparison without a value grid

Implemented bounded coordinate pattern search over piecewise-constant open-loop
interventions on [0,8), followed by zero control until time 50. This uses forward
simulation only, without a value grid or value interpolation. It shares the
model and RK4 dynamics, so it is an independent optimization formulation rather
than an independent biological model or a completely separate software stack.

With half-unit control segments, initialization from the previous feedback and
from the preset pulse both gives costs near 2.49428. Refining the segments to .25
gives cost 2.46890545 after 58 pattern-search iterations. The search terminates
when its coordinate step falls below .03125. Halving integration step .025 to
.0125 changes cost by 2.50e-7.

This feasible schedule is within 0.2359% of the replayed feedback cost. It supports
the scale of the computed performance through a different optimization route.
It is only a local solution in a restricted schedule family, not a lower bound
and not a proof that the feedback is within 0.2359% of the true optimum.

## Recommended reference and limits

Use the aligned base-141 / 41-control / .10-step run as the primary spatially
refined reference, accompanied by the finer-control and finer-time runs above.
Do not cherry-pick the lowest rollout as a certified optimum. The reference is
ready for deterministic method comparisons and a carefully scoped learning pilot.
Any neural derivative or policy-performance claim still needs separate analysis.

The existing Hamiltonian-selection certificates remain fixed-landscape results.
This dynamic-programming solver uses sampled controls and is not certified by
those separate tests. No uncertainty interval for the continuous optimum has
been produced. Model uncertainty, actuator limitations, biological validation,
and the proposed stochastic extension remain outside this milestone.

Before describing a general BioAI control method, extend the evaluation to
multiple initial states and noisy trajectories, construct a stochastic reference
with explicit domain-truncation checks, and distinguish value error from derivative
error. These are subsequent research stages, not completed work here.

## Reproduction and files

Python with NumPy is required. From this folder run:

    python refined_control.py
    python direct_shooting.py
    python refine_shooting.py
    python assess_reference.py

The direct-shooting script uses the previously saved reference rollout as one
initialization; the preset pulse is its second initialization. The other local
modules and prior results remain in this package.

- improved_reference_results.json: all six improved reference runs.
- numerical_assessment.json: gate, replay, and sampled-state diagnostics.
- direct_shooting_results.json: two initializations, schedules, and cost histories.
- refined_shooting_results.json: finer schedule and integration checks.
- rk4_*.csv: time, normalized states, and applied controls from each rollout.
- rk4_*.npz: grids and time-zero value surfaces, with control and step metadata.

Full time-indexed value arrays are regenerated during computation and are not
stored. Saved trajectories suffice to replay the reported initial-state schedules;
new feedback trajectories require regenerating the time-indexed values.
