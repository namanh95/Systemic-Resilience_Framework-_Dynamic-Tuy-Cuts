"""Build the stage report from saved results, retaining failed diagnostics."""
import json
from stochastic_reference import ROOT,STATES


def read(name):
    return json.loads((ROOT/(name+'.json')).read_text())


def main():
    main_data={k:read('stochastic_'+k) for k in ('deterministic','noise005','noise010')}
    assessment=read('stochastic_assessment')
    coupled=read('stochastic_coupled_checks')
    local=[read('stochastic_local1p0'),read('stochastic_local0p5')]
    lines=['# Multiple initial states and stochastic reference: stage report',
           '', 'Completed 2 November 2026', '',
           '## Outcome and scope', '',
           'Implemented a stochastic dynamic-programming reference, evaluated six initial states, '
           'tested domain and exit-payoff sensitivity, and compared feedback with zero control and '
           'a preset pulse. This is a computational study of the proposed mathematical model, not '
           'experimental biological validation. The coarse stochastic value grid FAILED refinement '
           'screens. Local refinement substantially reduces its bias; the failed coarse results are '
           'preserved. A fully converged stochastic value function or globally optimal policy is not claimed.', '',
           'The deterministic model and objective are unchanged from RESEARCH_SPEC.md: horizon 50, '
           'normalized squared state error, intervention penalty .01*z^2, terminal weight 10, '
           'and 0<=z<=10. Multiplicative independent environmental noise is a modeling assumption '
           'with sigma1=sigma2 in {0,.05,.10}; these intensities are not biologically calibrated.', '',
           '## Initial states and evaluation design', '',
           '| Label | Normalized x | Normalized y |', '|---|---:|---:|']
    for label,state in STATES.items():
        lines.append(f'| {label} | {state[0]:.8f} | {state[1]:.8f} |')
    lines += ['', 'Each noisy state/scenario uses 256 independent Brownian realizations. The three '
              'policies share the same realizations for paired comparisons: 3,072 distinct primary '
              'noise paths, each evaluated under three policies. Additional checks use separate seeds '
              'or explicitly coupled paths. The pulse is z=10 until t=5 and zero afterward. '
              'Feedback is recomputed every .1 time units using discrete Bellman minimization.', '',
              '## Numerical method and boundary handling', '',
              'The simulator splits each step into half a deterministic RK4 flow, the exact positive '
              'multiplicative-noise subflow exp(-sigma^2*h/2+sigma*sqrt(h)*N), and another half '
              'deterministic flow. Running cost is integrated along the deterministic subflows. '
              'This is a numerical approximation of the full coupled SDE, not an exact SDE solution. '
              'No negative-state clipping is applied. The main simulation step is .025.', '',
              'Dynamic programming uses the same split transition with two-node Gaussian quadrature '
              'per Brownian coordinate (four joint branches), bilinear interpolation, and 31 control '
              'candidates. A three-node-per-coordinate check uses nine branches. The base state grid '
              'has 61 squared-spaced nodes plus equilibrium anchors in [0,1] and .05-spaced outer nodes.', '',
              'The numerical domain is [0,L]^2 with L=1.25,1.5,2. Interior nodes stay identical across '
              'domain tests. An end-of-step branch outside the domain receives exit_cost+10*target_error '
              'and no future continuation. This defines an artificial discrete stopped problem, '
              'not a reflecting boundary. Exit payoffs 100 and 400 are compared. Placeholder clipping '
              'used to index interpolation arrays is overridden by that exit payoff.', '',
              'Monte Carlo trajectories are NOT stopped or reflected: full-horizon costs are recorded. '
              'Feedback defaults to zero if queried outside the domain. Exits are counted at subflow '
              'and step endpoints; continuous-time crossing events between them are not certified. '
              'Finite quadrature support can miss rare Gaussian tails, so domain agreement alone '
              'does not establish a bound for the unbounded-state problem.', '',
              '## Primary policy comparisons', '',
              'These are the original coarse-grid policies, kept separate from the local-refinement '
              'follow-up. Values below are simulated mean costs, not grid value estimates.', '',
              '| Noise | Initial state | Feedback | Zero control | Pulse |',
              '|---|---|---:|---:|---:|']
    for name,data in main_data.items():
        for label,r in data['simulations'].items():
            lines.append(f"| {data['parameters']['sigma']:.2f} | {label} | {r['feedback']['cost']['mean']:.6f} | {r['zero']['cost']['mean']:.6f} | {r['pulse']['cost']['mean']:.6f} |")
    lines += ['', 'At the deterministic target, zero control and feedback both have zero cost. '
              'In the noisy tests the feedback policies have lower sampled mean cost than the two '
              'simple comparators. This does not establish universal policy dominance or optimality. '
              'Endpoint proximity and intervention use are separate outcomes in stochastic_comparison.csv.', '',
              '### Sampling uncertainty at the high-x starting state', '',
              '| Noise | Feedback mean | Approximate 95% cost interval | Within target distance .05 | Exits |',
              '|---|---:|---|---:|---:|']
    for name in ('noise005','noise010'):
        r=main_data[name]['simulations']['high_x']['feedback'];ci=r['cost']['approx_95ci']
        lines.append(f"| {main_data[name]['parameters']['sigma']:.2f} | {r['cost']['mean']:.6f} | [{ci[0]:.6f}, {ci[1]:.6f}] | {r['fraction_within_005']:.2%} | {r['exited_paths']}/{r['paths']} |")
    lines += ['', 'Cost intervals use mean +/-1.96 standard errors. They are approximate Monte Carlo '
              'intervals only: they exclude numerical bias, model error, parameter uncertainty, and '
              'multiple-comparison adjustments. The distance-.05 criterion is an illustrative endpoint '
              'tolerance, not a biological success or persistence guarantee. Wilson intervals for its '
              'fractions are in the CSV. With zero observed exits in 256 independent paths, the '
              f"one-sided 95% binomial upper bound is {assessment['no_exits_upper95_for_256']:.2%}; zero counts do not prove zero exit probability.", '',
              '## Numerical screens: retain the failures', '',
              'Before the main runs, screens were specified as absolute value differences <= '
              '.01+.01*abs(refined value) for domain/boundary checks and .02+.02*abs(refined value) '
              'for spatial, temporal, and quadrature checks, over the six initial states. '
              'These are practical screening tolerances, not rigorous error bounds.', '',
              '| Check | Maximum absolute change | Largest tolerance ratio (pass <=1) | Result |',
              '|---|---:|---:|---|']
    for label,r in assessment['numerical_screens'].items():
        lines.append(f"| {label} | {r['max_absolute']:.6g} | {r['max_tolerance_ratio']:.4f} | {'PASS' if r['passed'] else 'FAIL'} |")
    lines += ['', 'Domain and payoff checks apply to sigma=.05 only. They do not by themselves '
              'resolve state-grid or noise-quadrature bias, and were not repeated on every locally '
              'refined grid or at sigma=.10.', '',
              '## Adaptive local refinement', '',
              'The coarse target value (.188300 at sigma=.05) greatly exceeded its simulated cost '
              '(.058096 approximately), motivating a follow-up. Add nodes over normalized x in '
              '[.001,.006] and y in [.55,.95]. The first local spacings are .0001 and .005; '
              'the second halves both. Original nodes, controls, time step, and model are retained. '
              'This follow-up was chosen after observing the discrepancy, not presented as a preplanned trial.', '',
              '| Grid | Initial state | DP value | MC feedback mean | MC approximate 95% interval |',
              '|---|---|---:|---:|---|']
    for item in local:
        for label,runs in item['simulations'].items():
            r=runs['feedback']['cost'];ci=r['approx_95ci']
            lines.append(f"| {item['parameters']['name']} | {label} | {item['initial_values'][label]:.6f} | {r['mean']:.6f} | [{ci[0]:.6f}, {ci[1]:.6f}] |")
    changes={s:abs(local[1]['initial_values'][s]-local[0]['initial_values'][s]) for s in STATES}
    lines += ['', f"Largest value change between the two local resolutions across six initial states: {max(changes.values()):.6g}.", '',
              'Local-refinement policy rollouts cover high-x, target, and saddle at sigma=.05. '
              'The other three local values are computed but their policies were not independently '
              'rolled out in this follow-up. The refined method still uses discrete controls; '
              'local time-step, control-grid, quadrature, and sigma=.10 refinements remain necessary '
              'before asserting a converged stochastic training reference.', '',
              '## Coupled integration checks and value of noise-aware feedback', '',
              'Fine Brownian increments are aggregated so .025 and .0125 simulations share the '
              'same Brownian paths. Deterministic and stochastic policies are then evaluated under '
              'the same noisy environment and fine increments, using 256 paths per comparison.', '',
              '| Noise | State | Fine-minus-coarse mean cost | Stochastic-minus-deterministic mean cost | Paired 95% interval for latter |',
              '|---|---|---:|---:|---|']
    for name,runs in coupled.items():
        for label,r in runs.items():
            a=r['paired_fine_minus_coarse'];b=r['paired_stochastic_minus_deterministic'];ci=b['approx_95ci']
            lines.append(f"| {name} | {label} | {a['mean']:.6g} | {b['mean']:.6g} | [{ci[0]:.6g}, {ci[1]:.6g}] |")
    lines += ['', 'Negative paired differences favor stochastic feedback in these simulations. '
              'These comparisons use the original coarse stochastic policies, not the locally refined '
              'follow-up. They concern numerical policies under the assumed model, not true optimal '
              'controls. Small integration differences cannot validate the separate DP grid.', '',
              '## Readiness decision and next work', '',
              'The multiple-initial-state and stochastic prototype stage is complete, with reproducible '
              'results and explicit failed diagnostics. The coarse stochastic value surfaces should '
              'NOT be treated as trustworthy neural training labels. Local refinement provides a '
              'better provisional reference at sigma=.05, but does not yet justify a general '
              'stochastic convergence or near-optimality claim.', '',
              'Next numerical work: repeat time, quadrature, and control-grid checks on the local '
              'reference; refine the sigma=.10 case; test policy performance on additional initial '
              'states and seeds. Only then establish the stochastic reference tolerance for a neural '
              'comparison. The existing fixed-Hamiltonian certificates are separate and do not '
              'certify this stochastic dynamic-programming calculation.', '',
              '## Reproduction', '',
              'Python and NumPy are required. Run from this folder:', '',
              '    python stochastic_reference.py',
              '    python stochastic_checks.py',
              '    python stochastic_local.py',
              '    python stochastic_assessment.py',
              '    python write_stochastic_report.py', '',
              'Scripts import the existing local model and reference modules. Primary and local '
              'policy archives contain time-indexed value arrays for reproducible off-grid feedback. '
              'Per-case JSON files preserve means, uncertainty, domain exits, and numerical parameters. '
              'stochastic_comparison.csv provides the complete primary comparison table. '
              'stochastic_assessment.json preserves failed as well as passed screening results.', '']
    (ROOT/'STOCHASTIC_STAGE.md').write_text('\n'.join(lines))
    print('Wrote STOCHASTIC_STAGE.md from saved results.')


if __name__=='__main__':
    main()
